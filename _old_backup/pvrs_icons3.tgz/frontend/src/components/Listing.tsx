'use client';
import { E, T } from '@/components/Icon';
import { useEffect, useMemo, useState } from 'react';
import { api, useFetch, getCity, img } from '@/lib/api';
import BizCard from './BizCard';
import BizRow from './BizRow';

// Rotating sponsored banner shown at the top of a category page (Justdial style)
function CategoryBanner({ slug }: { slug: string }) {
  const { data } = useFetch<any[]>(slug ? `/ads/category?slug=${encodeURIComponent(slug)}` : null, []); const [i, setI] = useState(0); const n = data?.length || 0;
  useEffect(() => { if (n < 2) return; const t = setInterval(() => setI((x) => (x + 1) % n), 4000); return () => clearInterval(t); }, [n]);
  if (!n) return null; const a = data![i % n];
  const ext = /^https?:/.test(a.link || '');
  return (<div className="mb-3 relative"><a href={a.link || '#'} {...(ext ? { target: '_blank', rel: 'noopener sponsored' } : {})} className="flex items-center justify-between gap-3 rounded-xl overflow-hidden text-white min-h-[84px] md:min-h-[110px]" style={{ background: a.bg || 'linear-gradient(90deg,#0f766e,#14b8a6)' }}>
      {a.image && <img src={img(a.image)} alt="" className="absolute inset-0 w-full h-full object-cover opacity-40" />}
      <div className="relative p-3 md:p-5 min-w-0"><p className="font-bold text-sm md:text-xl line-clamp-2">{a.title}</p>{a.subtitle && <p className="text-xs md:text-sm opacity-90 line-clamp-1">{a.subtitle}</p>}</div>
      <span className="relative mr-3 md:mr-5 shrink-0 bg-yellow-400 text-black text-xs md:text-sm font-bold px-3 py-1.5 rounded-md"><E c="📞"/> {a.cta || 'Call'}</span></a>
    <span className="absolute top-1 right-2 text-[9px] bg-black/40 text-white px-1.5 rounded">Ad</span>
    {n > 1 && <div className="flex justify-center gap-1 mt-1.5">{data!.map((_, k) => <span key={k} className={`w-1.5 h-1.5 rounded-full ${k === i % n ? 'bg-brand' : 'bg-gray-300'}`} />)}</div>}</div>);
}
// "Get the list of top …" quick lead strip → small form → admin Category leads
function LeadStrip({ label }: { label: string }) {
  const [open, setOpen] = useState(false); const [f, setF] = useState({ name: '', phone: '' }); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const send = async (e: React.FormEvent) => { e.preventDefault(); setBusy(true); setMsg(''); try { const r = await api('/category-leads', { body: { ...f, topic: label, city: getCity() } }); setMsg(r.message); setF({ name: '', phone: '' }); } catch (er: any) { setMsg(er.message); } setBusy(false); };
  return (<><button onClick={() => { setOpen(true); setMsg(''); }} className="mb-3 w-full text-left flex items-center justify-between gap-3 rounded-xl border border-blue-100 bg-blue-50 p-3 md:p-4"><span className="min-w-0"><b className="block text-sm md:text-base text-gray-900">Get the list of Top {label}</b><span className="text-xs text-gray-500">We’ll send you verified details for free</span></span><span className="shrink-0 w-9 h-9 rounded-full bg-brand text-white flex items-center justify-center"><E c="➔"/></span></button>
    {open && <div className="fixed inset-0 z-50 bg-black/50 flex items-end md:items-center justify-center" onClick={() => setOpen(false)}><form onSubmit={send} onClick={(e) => e.stopPropagation()} className="bg-white w-full md:max-w-sm rounded-t-2xl md:rounded-2xl p-5 space-y-3 slideup">
      <div className="flex justify-between"><b>Top {label} — free list</b><button type="button" onClick={() => setOpen(false)}><E c="✕"/></button></div>
      <input required minLength={2} maxLength={60} className="input" placeholder="Your name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <input required inputMode="numeric" maxLength={10} className="input" placeholder="10-digit mobile" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value.replace(/\D/g, '') })} />
      {msg && <p className="text-sm text-brand">{msg}</p>}<button disabled={busy || f.phone.length !== 10} className="btn btn-brand w-full disabled:opacity-50">{busy ? 'Sending…' : 'Send me the list'}</button></form></div>}</>);
}

// Shared results grid with city / sort / filter controls
export default function Listing({ query, title, subs, sub, onSub }: { query: string; title: string; subs?: string[]; sub?: string; onSub?: (s: string) => void }) {
  const [city, setCity] = useState('');
  useEffect(() => { setCity(getCity()); const f = () => setCity(getCity()); window.addEventListener('pvrs-city', f); return () => window.removeEventListener('pvrs-city', f); }, []);
  const [allCities, setAll] = useState(false);
  const [sort, setSort] = useState('relevance');
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null); const [shown, setShown] = useState(20); const [geoErr, setGeoErr] = useState('');
  useEffect(() => { setShown(20); }, [query, sort, city, allCities]);
  const onSort = (v: string) => { setGeoErr(''); if (v === 'near' && !pos) { navigator.geolocation?.getCurrentPosition((p) => { setPos({ lat: p.coords.latitude, lng: p.coords.longitude }); setSort('near'); }, () => setGeoErr('Allow location access to sort by distance')); return; } setSort(v); };
  const [view, setView] = useState<'list' | 'grid'>('list');
  const [only, setOnly] = useState({ verified: false, premium: false, rated: false });
  const qs = query + (city && !allCities ? `&city=${city}` : '') + (pos ? `&lat=${pos.lat}&lng=${pos.lng}` : '') + (sort === 'near' ? '&sort=near' : '');
  const { data, loading } = useFetch<any[]>(city ? `/businesses?${qs}` : null, []);
  const list = useMemo(() => {
    let l = [...(data || [])];
    if (only.verified) l = l.filter((b) => b.verified);
    if (only.premium) l = l.filter((b) => b.plan === 'premium');
    if (only.rated) l = l.filter((b) => b.rating >= 4);
    if (sort === 'rating') l.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    if (sort === 'reviews') l.sort((a, b) => (b.reviews || 0) - (a.reviews || 0));
    if (sort === 'name') l.sort((a, b) => a.name.localeCompare(b.name));
    return l;
  }, [data, only, sort]);
  const chip = (on: boolean) => `shrink-0 rounded-full border px-3 py-1.5 text-xs font-medium transition ${on ? 'bg-brand text-white border-brand' : 'bg-white hover:border-brand'}`;

  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4 py-5">
      <div className="flex flex-wrap justify-between items-end gap-2 mb-3">
        <div><h1 className="text-xl md:text-2xl font-black"><T>{title}</T></h1><p className="text-xs text-gray-500">{loading ? 'Searching…' : `${list.length} result${list.length === 1 ? '' : 's'}`} {!allCities && city && `in ${city}`}</p></div>
        <div className="flex gap-2 items-center">
        <div className="hidden md:flex bg-white border rounded-lg p-0.5 text-xs font-semibold">{(['list', 'grid'] as const).map((v) => <button key={v} onClick={() => setView(v)} className={`px-3 py-1.5 rounded-md ${view === v ? 'bg-brand text-white' : 'text-gray-500'}`}>{v === 'list' ? '☰ List' : '▦ Grid'}</button>)}</div>
        <select value={sort} onChange={(e) => onSort(e.target.value)} className="input !w-auto !py-1.5 text-sm">
          <option value="relevance">Sort: Relevance</option><option value="rating">Top rated</option><option value="reviews">Most reviewed</option><option value="near">Nearest first</option><option value="name">Name A–Z</option>
        </select>
        </div>
      </div>
      <CategoryBanner slug={(query.match(/(?:^|&)category=([^&]+)/) || [])[1] || ''} />
      {!!(query.match(/(?:^|&)category=/)) && !loading && list.length > 2 && <LeadStrip label={title.replace(/^[^\p{L}\p{N}]+/u, '').trim() || 'businesses'} />}
      {geoErr && <p className="text-xs text-red-600 mb-1">{geoErr}</p>}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
        <button onClick={() => setAll(!allCities)} className={chip(allCities)}><E c="🌐"/> All cities</button>
        <button onClick={() => setOnly({ ...only, verified: !only.verified })} className={chip(only.verified)}><E c="✔"/> Verified</button>
        <button onClick={() => setOnly({ ...only, premium: !only.premium })} className={chip(only.premium)}>★ Premium</button>
        <button onClick={() => setOnly({ ...only, rated: !only.rated })} className={chip(only.rated)}>4.0+ Rated</button>
      </div>
      {subs && (
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-2">
          <button onClick={() => onSub?.('')} className={chip(!sub)}>All</button>
          {subs.map((s) => <button key={s} onClick={() => onSub?.(s)} className={chip(sub === s)}>{s}</button>)}
        </div>
      )}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">{[0, 1, 2, 3].map((i) => <div key={i} className="card h-72 animate-pulse bg-gray-100" />)}</div>
      ) : !list.length ? (
        <div className="card p-10 text-center"><div className="text-5xl"><E c="🔎"/></div><p className="font-semibold mt-3">No businesses found</p><p className="text-sm text-gray-500">Try “All cities”, remove filters, or search something else.</p></div>
      ) : (
        view === 'list'
          ? <div className="grid lg:grid-cols-[1fr_300px] gap-5 items-start"><div className="space-y-3">{list.slice(0, shown).map((b) => <BizRow key={b._id} b={b} />)}{list.length > shown && <button onClick={() => setShown(shown + 20)} className="btn btn-ghost w-full">Load more ({list.length - shown} more)</button>}</div>
              <aside className="hidden lg:block sticky top-32 space-y-4">
                <div className="rounded-2xl p-5 bg-gradient-to-br from-brand to-[#3b82f6] text-white"><b className="text-lg">Own a business?</b><p className="text-sm text-blue-100 mt-1">Get listed free and reach customers in {city}.</p><a href="/register-business" className="btn bg-white text-brand mt-3 w-full">List for FREE</a></div>
                <div className="card p-5 text-sm"><b>Why PVRS HUB?</b><ul className="mt-2 space-y-1.5 text-gray-600"><li><E c="✔"/> Document-verified businesses</li><li><E c="✔"/> Every edit admin-reviewed</li><li><E c="✔"/> Direct call / WhatsApp</li></ul></div>
              </aside></div>
          : <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">{list.slice(0, shown).map((b) => <BizCard key={b._id} b={b} />)}{list.length > shown && <button onClick={() => setShown(shown + 20)} className="btn btn-ghost col-span-full">Load more ({list.length - shown} more)</button>}</div>
      )}
    </div>
  );
}
