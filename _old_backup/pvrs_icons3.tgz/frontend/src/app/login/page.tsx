'use client';
import { E } from '@/components/Icon';
import { Suspense, useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { api, setSession, useConfig } from '@/lib/api';

// Firebase Phone Auth is used when NEXT_PUBLIC_FIREBASE_API_KEY is set; otherwise backend test OTP (123456).
const FB = process.env.NEXT_PUBLIC_FIREBASE_API_KEY;

function LoginInner() {
  const sp = useSearchParams(); const router = useRouter();
  const { f, ready } = useConfig();
  const [intent, setIntent] = useState(sp.get('intent') === 'user' ? 'user' : 'vendor');
  const [phone, setPhone] = useState(''); const [otp, setOtp] = useState(''); const [name, setName] = useState('');
  const [step, setStep] = useState(1); const [msg, setMsg] = useState(''); const [err, setErr] = useState(false); const [busy, setBusy] = useState(false);
  const confirmRef = useRef<any>(null);
  useEffect(() => { if (ready && !f.customerLogin) setIntent('vendor'); }, [ready, f.customerLogin]);
  const say = (m: string, e = false) => { setMsg(m); setErr(e); };

  const finish = async (body: any) => {
    const r = await api('/auth/verify-otp', { body: { phone, name, intent, ...body } });
    setSession(r.token, r.user);
    const next = sp.get('next');
    router.push(next || (['admin', 'moderator'].includes(r.user.role) ? '/admin' : r.user.role === 'vendor' ? '/vendor/dashboard' : '/'));
  };

  const send = async () => {
    if (!/^[6-9]\d{9}$/.test(phone)) return say('Enter a valid 10-digit mobile number', true);
    setBusy(true); say('');
    try {
      const r = await api('/auth/request-otp', { body: { phone, intent } });
      if (r.otpRequired === false) { await finish({}); return; } // admin has disabled OTP for this login type
      if (FB) {
        const { initializeApp, getApps } = await import('firebase/app');
        const { getAuth, RecaptchaVerifier, signInWithPhoneNumber } = await import('firebase/auth');
        const app = getApps()[0] || initializeApp({ apiKey: FB, authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN, projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID, appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID });
        const auth = getAuth(app); const w = window as any;
        w.recaptcha = w.recaptcha || new RecaptchaVerifier(auth, 'recaptcha', { size: 'invisible' });
        confirmRef.current = await signInWithPhoneNumber(auth, '+91' + phone, w.recaptcha);
        say(`OTP sent to +91 ${phone}`);
      } else say(r.message);
      setStep(2);
    } catch (e: any) { say(e.message, true); }
    setBusy(false);
  };

  const verify = async () => {
    setBusy(true); say('');
    try {
      let firebaseToken;
      if (FB) { const cred = await confirmRef.current.confirm(otp); firebaseToken = await cred.user.getIdToken(); }
      await finish({ otp, firebaseToken });
    } catch (e: any) { say(e.message, true); }
    setBusy(false);
  };

  const vendorPaused = ready && intent === 'vendor' && f.vendorSignup === false;

  return (
    <div className="min-h-[80vh] grid md:grid-cols-2">
      <div className="hidden md:flex flex-col justify-center p-12 bg-gradient-to-br from-[#0033aa] via-brand to-[#3b82f6] text-white relative overflow-hidden">
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-white/10 rounded-full" /><div className="absolute -left-10 bottom-10 w-60 h-60 bg-accent/30 rounded-full blur-2xl" />
        <h2 className="text-4xl font-black leading-tight relative">Grow your local business<br />with <span className="text-accent">PVRS HUB</span></h2>
        <ul className="mt-8 space-y-3 text-blue-50 relative">
          {['Free business listing', 'Verified badge after document check', 'Leads via enquiries, calls & WhatsApp', 'Homepage banners & featured slots'].map((t) => <li key={t} className="flex gap-3 items-center"><span className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center text-xs"><E c="✔"/></span>{t}</li>)}
        </ul>
      </div>
      <div className="flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <h1 className="text-3xl font-black">{intent === 'vendor' ? 'Business Login' : 'Login'}</h1>
          <p className="text-sm text-gray-500 mb-6">Use your mobile number — no password needed.</p>

          {f.customerLogin && (
            <div className="grid grid-cols-2 bg-gray-100 rounded-xl p-1 mb-5 text-sm font-semibold">
              <button onClick={() => setIntent('user')} className={`py-2 rounded-lg ${intent === 'user' ? 'bg-white shadow text-brand' : 'text-gray-500'}`}>Customer</button>
              <button onClick={() => setIntent('vendor')} className={`py-2 rounded-lg ${intent === 'vendor' ? 'bg-white shadow text-accent' : 'text-gray-500'}`}>Business Owner</button>
            </div>
          )}
          {!f.customerLogin && ready && <div className="mb-5 rounded-xl bg-blue-50 border border-blue-100 p-3 text-xs text-blue-800"><E c="👋"/> Customers don&apos;t need an account — <Link href="/" className="font-bold underline">browse</Link>, review and send enquiries directly.</div>}

          <div className="card p-6 shadow-sm">
            {step === 1 ? (<>
              <label className="label">Your name (new accounts)</label>
              <input className="input mb-4" value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name / business owner name" />
              <label className="label">Mobile number</label>
              <div className="flex gap-2"><span className="input !w-16 text-center font-semibold">+91</span><input className="input text-lg tracking-wider" inputMode="numeric" maxLength={10} value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="98XXXXXXXX" /></div>
              <button disabled={busy || vendorPaused} onClick={send} className="btn btn-brand w-full mt-5 !py-3">{busy ? 'Please wait…' : 'Continue'}</button>
              {vendorPaused && <p className="text-xs text-red-600 mt-2">New business registrations are paused right now. Existing owners can still log in.</p>}
            </>) : (<>
              <label className="label">Enter the 6-digit OTP sent to +91 {phone}</label>
              <input autoFocus className="input text-center tracking-[.6em] text-2xl !py-3" inputMode="numeric" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))} onKeyDown={(e) => e.key === 'Enter' && otp.length === 6 && verify()} />
              <button disabled={busy || otp.length !== 6} onClick={verify} className="btn btn-brand w-full mt-5 !py-3">{busy ? 'Verifying…' : 'Verify & Continue'}</button>
              <button onClick={() => { setStep(1); setOtp(''); }} className="text-xs text-brand w-full mt-3">← Change number</button>
            </>)}
            {msg && <p className={`text-sm text-center mt-4 ${err ? 'text-red-600' : 'text-gray-700'}`}>{msg}</p>}
          </div>
          {intent === 'vendor' && <p className="text-xs text-gray-500 mt-4 text-center">Business accounts & listings go live only after admin verification.</p>}
          <div id="recaptcha" />
        </div>
      </div>
    </div>
  );
}
export default function Login() { return <Suspense><LoginInner /></Suspense>; }
