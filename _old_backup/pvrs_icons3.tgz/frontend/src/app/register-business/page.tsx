'use client';
import { E } from '@/components/Icon';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import ListingForm from '@/components/ListingForm';
import PageHero from '@/components/PageHero';
import { useUser } from '@/lib/api';

export default function Register() {
  const { user, ready } = useUser(); const router = useRouter(); const [done, setDone] = useState('');
  useEffect(() => { if (ready && !user) router.replace('/login?intent=vendor&next=/register-business'); }, [ready, user, router]);
  if (!user) return null;
  return (
    <div>
      <PageHero title="List Your Business — Free" icon="🏪" crumb="Free Listing" subtitle="Fill in your details and upload your licence. Our team verifies and publishes within 24 hours.">
        <div className="flex flex-wrap gap-2 text-xs">{['1. Business details', '2. Contact', '3. Photos', '4. Licence upload'].map((s) => <span key={s} className="bg-white/15 rounded-full px-3 py-1.5">{s}</span>)}</div>
      </PageHero>
      <div className="max-w-6xl mx-auto px-3 md:px-4 py-8 grid lg:grid-cols-[1fr_300px] gap-6 items-start">
        <div>{done ? (
          <div className="card p-10 text-center"><div className="w-20 h-20 mx-auto rounded-full bg-emerald-50 flex items-center justify-center text-4xl"><E c="✅"/></div><h2 className="text-xl font-black mt-4">Submitted for verification</h2><p className="text-gray-600 mt-2">{done}</p><Link href="/vendor/dashboard" className="btn btn-brand mt-6">Go to Dashboard</Link></div>
        ) : <ListingForm onDone={setDone} />}</div>
        <aside className="space-y-4 lg:sticky lg:top-32">
          <div className="card p-5"><b>Why list on PVRS HUB?</b><ul className="text-sm text-gray-600 mt-3 space-y-2"><li><E c="✔"/> Free forever basic listing</li><li><E c="✔"/> Verified badge builds trust</li><li><E c="✔"/> Customer enquiries to your dashboard</li><li><E c="✔"/> Upgrade anytime for Call/WhatsApp</li></ul></div>
          <div className="card p-5 bg-amber-50 border-amber-200 text-sm text-amber-900"><b><E c="📄"/> Keep ready</b><p className="mt-1">Trade License, FSSAI or KMC registration certificate (JPG, PNG or PDF, max 5MB) with its expiry date.</p></div>
        </aside>
      </div>
    </div>
  );
}
