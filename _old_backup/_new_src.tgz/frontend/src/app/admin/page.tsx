'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, img, privateFile, useFetch, useUser, logout } from '@/lib/api';

const TABS = [['overview', '📊 Overview'], ['queue', '🛡️ Approval Queue'], ['businesses', '🏪 Businesses'], ['users', '👥 Users'], ['ads', '📢 Ads & Banners'],
  ['categories', '📂 Categories'], ['content', '📝 Offers / Blogs / Videos'], ['settings', '⚙️ Homepage Settings'], ['legal', '⚖️ Legal Pages'], ['payments', '💳 Payments'], ['logs', '🔔 Notifications & Logs']];

const Badge = ({ s }: { s: string }) => <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${({ pending: 'bg-yellow-100 text-yellow-800', approved: 'bg-green-100 text-green-800', rejected: 'bg-red-100 text-red-700', suspended: 'bg-gray-200', expired: 'bg-gray-200', paid: 'bg-green-100 text-green-800' } as any)[s] || 'bg-gray-100'}`}>{s}</span>;

export default function Admin() {
  const { user, ready } = useUser(); const router = useRouter();
  const [tab, setTab] = useState('overview'); const [nav, setNav] = useState(false);
  const queue = useFetch<any>(user?.role === 'admin' ? '/admin/queue' : null);
  useEffect(() => { if (ready && (!user || user.role !== 'admin')) router.replace('/login?next=/admin'); }, [ready, user, router]);
  if (!user || user.role !== 'admin') return <p className="p-10 text-center">Admin access only.</p>;
  const c = queue.data?.counts || {}; const total = Object.values(c).reduce((a: any, b: any) => a + b, 0) as number;

  return (
    <div className="min-h-screen flex bg-slate-100">
      <aside className={`${nav ? 'block' : 'hidden'} md:block fixed md:static inset-0 z-40 w-64 bg-slate-900 text-slate-200 p-4 overflow-y-auto`}>
        <div className="text-xl font-black text-white mb-6">PVRS <span className="text-accent">ADMIN</span></div>
        {TABS.map(([k, l]) => (
          <button key={k} onClick={() => { setTab(k); setNav(false); }} className={`w-full text-left px-3 py-2.5 rounded-lg text-sm flex justify-between ${tab === k ? 'bg-brand text-white' : 'hover:bg-slate-800'}`}>
            {l}{k === 'queue' && total > 0 && <span className="bg-red-500 text-white text-xs px-2 rounded-full">{total}</span>}
          </button>
        ))}
        <div className="border-t border-slate-700 mt-4 pt-4 space-y-2 text-sm">
          <Link href="/" className="block hover:text-white">← View website</Link>
          <button onClick={() => { logout(); router.push('/'); }} className="text-red-400">Logout</button>
        </div>
      </aside>
      <main className="flex-1 p-4 md:p-8 min-w-0">
        <div className="flex items-center gap-3 mb-6">
          <button className="md:hidden btn btn-ghost" onClick={() => setNav(true)}>☰</button>
          <h1 className="text-2xl font-black text-slate-800">{TABS.find((t) => t[0] === tab)?.[1]}</h1>
        </div>
        {tab === 'overview' && <Overview />}
        {tab === 'queue' && <Queue q={queue} />}
        {tab === 'businesses' && <Businesses />}
        {tab === 'users' && <Users />}
        {tab === 'ads' && <Ads />}
        {tab === 'categories' && <Categories />}
        {tab === 'content' && <Content />}
        {tab === 'settings' && <Settings />}
        {tab === 'legal' && <Legal />}
        {tab === 'payments' && <Payments />}
        {tab === 'logs' && <Logs />}
      </main>
    </div>
  );
}

function Overview() {
  const { data: d } = useFetch<any>('/admin/overview');
  if (!d) return <p>Loading…</p>;
  const cards = [['Revenue (Razorpay)', `₹${d.revenue.toLocaleString('en-IN')}`, 'border-l-green-500'], ['Premium listings', d.premium, 'border-l-orange-500'], ['Free listings', d.free, 'border-l-blue-500'], ['Live listings', d.live, 'border-l-emerald-500'], ['Suspended', d.suspended, 'border-l-gray-500'], ['Users', d.users, 'border-l-purple-500'], ['Leads (clicks)', d.leads, 'border-l-pink-500'], ['Pending actions', Object.values(d.queue).reduce((a: any, b: any) => a + b, 0), 'border-l-red-500']];
  return (<div className="space-y-6">
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{cards.map(([l, v, b]) => <div key={l} className={`card p-4 border-l-4 ${b}`}><p className="text-xs text-gray-500">{l}</p><p className="text-2xl font-black">{v}</p></div>)}</div>
    <div className="grid md:grid-cols-2 gap-4">
      <div className="card p-4"><h3 className="font-bold mb-2">Queue</h3>{Object.entries(d.queue).map(([k, v]: any) => <p key={k} className="text-sm flex justify-between border-b py-1"><span className="capitalize">{k}</span><b>{v}</b></p>)}</div>
      <div className="card p-4"><h3 className="font-bold mb-2">Search demand by category</h3>{Object.entries(d.searchStats).sort((a: any, b: any) => b[1] - a[1]).map(([k, v]: any) => <p key={k} className="text-sm flex justify-between border-b py-1"><span>{k}</span><b>{v}</b></p>)}</div>
    </div>
  </div>);
}

function Diff({ b }: { b: any }) {
  const u = b.pendingUpdates || {};
  const show = (v: any) => (v == null ? '—' : typeof v === 'object' ? JSON.stringify(v) : String(v));
  return (
    <table className="w-full text-xs mt-2 border"><thead className="bg-gray-50"><tr><th className="p-1.5 text-left">Field</th><th className="text-left">Live (verified)</th><th className="text-left">Requested change</th></tr></thead>
      <tbody>{Object.keys(u).map((k) => (
        <tr key={k} className="border-t align-top"><td className="p-1.5 font-semibold">{k}</td><td className="text-gray-500 break-all">{show(b[k])}</td><td className={`break-all ${show(b[k]) !== show(u[k]) ? 'bg-yellow-50 font-semibold' : ''}`}>{k === 'documents' && u[k]?.file ? <a className="text-brand underline" target="_blank" href={privateFile(u[k].file)}>View new document</a> : show(u[k])}</td></tr>
      ))}</tbody></table>
  );
}

function Queue({ q }: { q: any }) {
  const [sub, setSub] = useState('listings'); const [reason, setReason] = useState('');
  const d = q.data || {};
  const act = async (path: string, body?: any) => { try { await api(path, { method: 'PUT', body: body || {} }); q.reload(); } catch (e: any) { alert(e.message); } };
  const reject = (id: string) => { const r = prompt('Reason for rejection?', reason || 'Documents unclear'); if (r !== null) { setReason(r); act(`/admin/listings/${id}/reject`, { reason: r }); } };
  const L = (b: any, edit = false) => (
    <div key={b._id} className="card p-4">
      <div className="flex flex-wrap gap-3 justify-between">
        <div className="flex gap-3">
          <div className="w-14 h-14 rounded bg-gray-100 overflow-hidden flex items-center justify-center">{b.profileImage ? <img src={img(b.profileImage)} alt="" className="w-full h-full object-cover" /> : '🏪'}</div>
          <div><b>{b.name}</b> {b.plan === 'premium' && <Badge s="premium" />}<p className="text-xs text-gray-500">{b.category} › {b.subCategory} · {b.city}</p>
            <p className="text-xs">Owner: {b.owner?.name} +91 {b.owner?.phone} {b.owner?.status === 'pending' && <Badge s="pending" />}</p>
            <p className="text-xs">Phone: {b.contact?.phone} · WA: {b.contact?.whatsapp}</p></div>
        </div>
        <div className="flex gap-2 items-start">
          {b.documents?.file && <a href={privateFile(b.documents.file)} target="_blank" className="btn btn-ghost !text-xs">📄 {b.documents.type}</a>}
          <button onClick={() => act(`/admin/listings/${b._id}/approve`)} className="btn bg-green-600 text-white !text-xs">✔ Approve</button>
          <button onClick={() => reject(b._id)} className="btn bg-red-600 text-white !text-xs">✕ Reject</button>
        </div>
      </div>
      {b.documents && <p className="text-xs text-gray-500 mt-1">Cert no: {b.documents.number || '—'} · Expiry: {b.documents.expiry || '—'}</p>}
      {edit ? <Diff b={b} /> : <p className="text-xs text-gray-600 mt-2">{b.description}</p>}
    </div>
  );
  return (<div>
    <p className="text-sm text-gray-600 mb-3">Section 79 safety queue: nothing new or edited goes public until you approve it. Live pages keep showing the last verified version.</p>
    <div className="flex gap-2 mb-4 overflow-x-auto">
      {[['listings', 'New listings'], ['edits', 'Edit requests'], ['vendors', 'Vendor signups'], ['ads', 'Banner ads'], ['claims', 'Claims']].map(([k, l]) => (
        <button key={k} onClick={() => setSub(k)} className={`btn !text-xs ${sub === k ? 'btn-brand' : 'btn-ghost'}`}>{l} ({d.counts?.[k] || 0})</button>
      ))}
    </div>
    <div className="space-y-3">
      {sub === 'listings' && d.listings?.map((b: any) => L(b))}
      {sub === 'edits' && d.edits?.map((b: any) => L(b, true))}
      {sub === 'vendors' && d.vendors?.map((u: any) => (
        <div key={u._id} className="card p-4 flex justify-between items-center"><div><b>{u.name || 'Vendor'}</b><p className="text-xs">+91 {u.phone} · joined {new Date(u.createdAt).toLocaleDateString()}</p></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/users/${u._id}`, { status: 'approved' })} className="btn bg-green-600 text-white !text-xs">Approve</button><button onClick={() => act(`/admin/users/${u._id}`, { status: 'rejected' })} className="btn bg-red-600 text-white !text-xs">Reject</button></div></div>
      ))}
      {sub === 'ads' && d.ads?.map((a: any) => (
        <div key={a._id} className="card p-4 flex flex-wrap gap-3 justify-between items-center">
          <div className="flex gap-3 items-center">{a.image && <img src={img(a.image)} alt="" className="h-12 rounded" />}<div><b>{a.title}</b> <Badge s={a.paymentStatus} /><p className="text-xs">{a.type} · {a.days} days from {new Date(a.startDate).toLocaleDateString()} · ₹{a.amount}</p><p className="text-xs">{a.subtitle} {a.youtubeUrl}</p></div></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/ads/${a._id}`, { status: 'approved' })} className="btn bg-green-600 text-white !text-xs">Approve</button><button onClick={() => act(`/admin/ads/${a._id}`, { status: 'rejected' })} className="btn bg-red-600 text-white !text-xs">Reject</button></div>
        </div>
      ))}
      {sub === 'claims' && d.claims?.map((c: any) => (
        <div key={c._id} className="card p-4 flex justify-between items-center"><div><b>{c.businessName}</b><p className="text-xs">Claimed by {c.name} +91 {c.phone}</p><a href={privateFile(c.document)} target="_blank" className="text-xs text-brand underline">View proof</a></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/claims/${c._id}/approve`)} className="btn bg-green-600 text-white !text-xs">Approve</button><button onClick={() => act(`/admin/claims/${c._id}/reject`)} className="btn bg-red-600 text-white !text-xs">Reject</button></div></div>
      ))}
      {!d[sub]?.length && <p className="text-gray-500 text-sm">Nothing pending here 🎉</p>}
    </div>
  </div>);
}

function Businesses() {
  const list = useFetch<any[]>('/admin/businesses'); const { data: cats } = useFetch<any[]>('/categories');
  const [q, setQ] = useState(''); const [form, setForm] = useState<any>(null);
  const act = async (p: string, method = 'PUT', body: any = {}) => { try { await api(p, { method, body }); list.reload(); } catch (e: any) { alert(e.message); } };
  const save = async (e: React.FormEvent) => {
    e.preventDefault(); const fd = new FormData(e.target as HTMLFormElement);
    fd.set('contact', JSON.stringify({ phone: fd.get('phone'), whatsapp: fd.get('whatsapp') })); fd.delete('phone'); fd.delete('whatsapp');
    fd.set('unclaimed', fd.get('unclaimed') ? 'true' : 'false');
    ['profileImage'].forEach((k) => { const f = fd.get(k) as File; if (!f?.size) fd.delete(k); });
    try { await api(form._id ? `/admin/businesses/${form._id}` : '/admin/businesses', { method: form._id ? 'PUT' : 'POST', form: fd }); setForm(null); list.reload(); } catch (e: any) { alert(e.message); }
  };
  const rows = (list.data || []).filter((b) => !q || JSON.stringify([b.name, b.city, b.category, b.contact?.phone]).toLowerCase().includes(q.toLowerCase()));
  return (<div>
    <div className="flex gap-2 mb-4"><input className="input" placeholder="Search name, city, phone…" value={q} onChange={(e) => setQ(e.target.value)} /><button onClick={() => setForm({ unclaimed: true, plan: 'free' })} className="btn btn-accent shrink-0">+ Pre-load business</button></div>
    {form && (
      <form onSubmit={save} className="card p-4 grid md:grid-cols-3 gap-3 mb-4">
        <input name="name" required defaultValue={form.name} placeholder="Name" className="input" />
        <select name="category" required defaultValue={form.category} className="input"><option value="">Category</option>{cats?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select>
        <input name="subCategory" defaultValue={form.subCategory} placeholder="Sub-category" className="input" list="subs" />
        <datalist id="subs">{cats?.flatMap((c) => c.subs).map((s: string) => <option key={s} value={s} />)}</datalist>
        <input name="city" defaultValue={form.city || 'Udupi'} placeholder="City" className="input" />
        <input name="address" defaultValue={form.address} placeholder="Address" className="input" />
        <input name="phone" defaultValue={form.contact?.phone} placeholder="Phone" className="input" />
        <input name="whatsapp" defaultValue={form.contact?.whatsapp} placeholder="WhatsApp" className="input" />
        <select name="plan" defaultValue={form.plan} className="input"><option value="free">Free</option><option value="premium">Premium</option></select>
        <input name="planExpiry" type="date" defaultValue={form.planExpiry?.slice(0, 10)} className="input" title="Plan expiry" />
        <input name="rating" defaultValue={form.rating} placeholder="Rating (e.g. 4.5)" className="input" />
        <input name="reviews" defaultValue={form.reviews} placeholder="No. of ratings" className="input" />
        <input name="profileImage" type="file" accept="image/*" className="input" />
        <textarea name="description" defaultValue={form.description} placeholder="Description" className="input md:col-span-3" />
        <label className="text-sm flex gap-2 items-center"><input type="checkbox" name="unclaimed" defaultChecked={form.unclaimed} /> Unclaimed (show “Claim it now” badge)</label>
        <div className="md:col-span-2 flex gap-2 justify-end"><button type="button" onClick={() => setForm(null)} className="btn btn-ghost">Cancel</button><button className="btn btn-brand">Save</button></div>
      </form>
    )}
    <div className="card overflow-x-auto"><table className="w-full text-sm"><thead className="bg-gray-50 text-left"><tr><th className="p-3">Business</th><th>City</th><th>Plan</th><th>Status</th><th>Views</th><th className="text-right pr-3">Actions</th></tr></thead>
      <tbody>{rows.map((b) => (
        <tr key={b._id} className="border-t"><td className="p-3"><b>{b.name}</b>{b.unclaimed && <span className="text-[10px] text-accent ml-1">UNCLAIMED</span>}{b.pendingUpdates && <span className="text-[10px] text-yellow-700 ml-1">EDIT PENDING</span>}<br /><span className="text-xs text-gray-500">{b.subCategory}</span></td>
          <td>{b.city}</td><td>{b.plan}{b.planExpiry && <div className="text-[10px] text-gray-500">till {new Date(b.planExpiry).toLocaleDateString()}</div>}</td><td><Badge s={b.status} /></td><td>{b.views || 0}</td>
          <td className="text-right pr-3 whitespace-nowrap space-x-1">
            <button onClick={() => setForm(b)} className="btn btn-ghost !text-xs !px-2">Edit</button>
            {b.status === 'approved' ? <button onClick={() => act(`/admin/listings/${b._id}/suspend`)} className="btn btn-ghost !text-xs !px-2">Suspend</button> : <button onClick={() => act(`/admin/listings/${b._id}/approve`)} className="btn btn-ghost !text-xs !px-2">Approve</button>}
            <button onClick={() => confirm('Delete permanently?') && act(`/admin/businesses/${b._id}`, 'DELETE')} className="btn btn-ghost !text-xs !px-2 !text-red-600">Delete</button>
          </td></tr>
      ))}</tbody></table></div>
  </div>);
}

function Users() {
  const u = useFetch<any[]>('/admin/users');
  const upd = async (id: string, body: any) => { await api(`/admin/users/${id}`, { method: 'PUT', body }); u.reload(); };
  return (<div className="card overflow-x-auto"><table className="w-full text-sm"><thead className="bg-gray-50 text-left"><tr><th className="p-3">Name</th><th>Phone</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>{u.data?.map((x) => <tr key={x._id} className="border-t"><td className="p-3">{x.name || '—'}</td><td>+91 {x.phone}</td>
      <td><select value={x.role} onChange={(e) => upd(x._id, { role: e.target.value })} className="border rounded px-1"><option>user</option><option>vendor</option><option>admin</option></select></td>
      <td><Badge s={x.blocked ? 'blocked' : x.status} /></td>
      <td className="space-x-1">{x.status !== 'approved' && <button onClick={() => upd(x._id, { status: 'approved' })} className="btn btn-ghost !text-xs !px-2">Approve</button>}
        <button onClick={() => upd(x._id, { blocked: !x.blocked })} className="btn btn-ghost !text-xs !px-2">{x.blocked ? 'Unblock' : 'Block'}</button></td></tr>)}</tbody></table></div>);
}

function Ads() {
  const ads = useFetch<any[]>('/admin/ads'); const [f, setF] = useState<any>(null);
  const save = async (e: React.FormEvent) => {
    e.preventDefault(); const fd = new FormData(e.target as HTMLFormElement); const im = fd.get('image') as File; if (!im?.size) fd.delete('image');
    try { await api(f._id ? `/admin/ads/${f._id}` : '/admin/ads', { method: f._id ? 'PUT' : 'POST', form: fd }); setF(null); ads.reload(); } catch (e: any) { alert(e.message); }
  };
  const upd = async (id: string, body: any, method = 'PUT') => { await api(`/admin/ads/${id}`, { method, body }); ads.reload(); };
  return (<div>
    <button onClick={() => setF({ type: 'top_banner' })} className="btn btn-accent mb-4">+ New ad / banner</button>
    {f && (
      <form onSubmit={save} className="card p-4 grid md:grid-cols-3 gap-3 mb-4">
        <select name="type" defaultValue={f.type} className="input"><option value="top_banner">Top banner (970×90)</option><option value="middle_banner">Middle banner (970×90)</option><option value="promo">Promotional widget</option><option value="hero_video">Hero video ad</option></select>
        <input name="title" defaultValue={f.title} placeholder="Title" className="input" />
        <input name="subtitle" defaultValue={f.subtitle} placeholder="Subtitle" className="input" />
        <input name="cta" defaultValue={f.cta} placeholder="Button text" className="input" />
        <input name="link" defaultValue={f.link} placeholder="Link (/business/.. or https://..)" className="input" />
        <input name="youtubeUrl" defaultValue={f.youtubeUrl} placeholder="YouTube URL (video ads)" className="input" />
        <input name="bg" defaultValue={f.bg} placeholder="Background CSS (optional)" className="input" />
        <input name="imageUrl" defaultValue={f.image?.startsWith('http') ? f.image : ''} placeholder="Image URL (or upload)" className="input" />
        <input name="image" type="file" accept="image/*" className="input" />
        <label className="text-xs">Start<input name="startDate" type="date" defaultValue={f.startDate?.slice(0, 10)} className="input" /></label>
        <label className="text-xs">End<input name="endDate" type="date" defaultValue={f.endDate?.slice(0, 10)} className="input" /></label>
        <div className="flex gap-2 items-end justify-end"><button type="button" onClick={() => setF(null)} className="btn btn-ghost">Cancel</button><button className="btn btn-brand">Save</button></div>
      </form>
    )}
    <div className="grid md:grid-cols-2 gap-3">{ads.data?.map((a) => (
      <div key={a._id} className="card p-3 text-sm">
        <div className="flex justify-between"><b>{a.title}</b><Badge s={a.status} /></div>
        <p className="text-xs text-gray-500">{a.type} · by {a.createdBy} {a.amount ? `· ₹${a.amount} (${a.paymentStatus})` : ''} {a.endDate ? `· till ${new Date(a.endDate).toLocaleDateString()}` : ''}</p>
        <div className="flex gap-1 mt-2">
          <button onClick={() => setF(a)} className="btn btn-ghost !text-xs !px-2">Edit</button>
          {a.status !== 'approved' ? <button onClick={() => upd(a._id, { status: 'approved' })} className="btn btn-ghost !text-xs !px-2">Activate</button> : <button onClick={() => upd(a._id, { status: 'paused' })} className="btn btn-ghost !text-xs !px-2">Pause</button>}
          <button onClick={() => confirm('Delete?') && upd(a._id, {}, 'DELETE')} className="btn btn-ghost !text-xs !px-2 !text-red-600">Delete</button>
        </div>
      </div>
    ))}</div>
  </div>);
}

function Categories() {
  const cats = useFetch<any[]>('/categories');
  const save = async (c: any) => { try { await api(c._id ? `/admin/categories/${c._id}` : '/admin/categories', { method: c._id ? 'PUT' : 'POST', body: c }); cats.reload(); } catch (e: any) { alert(e.message); } };
  const [n, setN] = useState<any>({ name: '', icon: '📁', subs: '', color: '#0055FF' });
  return (<div className="space-y-3">
    {cats.data?.map((c) => <CatRow key={c._id} c={c} onSave={save} onDel={async () => { if (confirm('Delete category?')) { await api(`/admin/categories/${c._id}`, { method: 'DELETE' }); cats.reload(); } }} />)}
    <div className="card p-4 grid md:grid-cols-5 gap-2">
      <input className="input" placeholder="Icon" value={n.icon} onChange={(e) => setN({ ...n, icon: e.target.value })} />
      <input className="input" placeholder="Name" value={n.name} onChange={(e) => setN({ ...n, name: e.target.value })} />
      <input className="input md:col-span-2" placeholder="Sub-categories (comma separated)" value={n.subs} onChange={(e) => setN({ ...n, subs: e.target.value })} />
      <button onClick={() => { save(n); setN({ name: '', icon: '📁', subs: '', color: '#0055FF' }); }} className="btn btn-accent">+ Add</button>
    </div>
  </div>);
}
function CatRow({ c, onSave, onDel }: any) {
  const [v, setV] = useState({ ...c, subs: c.subs.join(', ') });
  return (<div className="card p-3 grid md:grid-cols-12 gap-2 items-center">
    <input className="input md:col-span-1" value={v.icon} onChange={(e) => setV({ ...v, icon: e.target.value })} />
    <input className="input md:col-span-3" value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} />
    <input className="input md:col-span-5" value={v.subs} onChange={(e) => setV({ ...v, subs: e.target.value })} />
    <input className="input md:col-span-1" type="number" value={v.order} onChange={(e) => setV({ ...v, order: Number(e.target.value) })} title="Order" />
    <div className="md:col-span-2 flex gap-1"><button onClick={() => onSave({ _id: c._id, name: v.name, icon: v.icon, subs: v.subs, order: v.order })} className="btn btn-brand !text-xs">Save</button><button onClick={onDel} className="btn btn-ghost !text-xs !text-red-600">Del</button></div>
  </div>);
}

function Content() {
  const [kind, setKind] = useState('offers');
  const list = useFetch<any[]>(`/admin/${kind}`);
  const FIELDS: Record<string, string[]> = { offers: ['title', 'subtitle', 'businessName', 'city', 'code', 'expiry'], blogs: ['title', 'excerpt', 'body', 'image'], videos: ['title', 'url', 'category'] };
  const [f, setF] = useState<any>({});
  const save = async () => { try { await api(f._id ? `/admin/${kind}/${f._id}` : `/admin/${kind}`, { method: f._id ? 'PUT' : 'POST', body: f }); setF({}); list.reload(); } catch (e: any) { alert(e.message); } };
  return (<div>
    <div className="flex gap-2 mb-4">{['offers', 'blogs', 'videos'].map((k) => <button key={k} onClick={() => { setKind(k); setF({}); }} className={`btn !text-xs capitalize ${kind === k ? 'btn-brand' : 'btn-ghost'}`}>{k}</button>)}</div>
    <div className="card p-4 grid md:grid-cols-3 gap-2 mb-4">
      {FIELDS[kind].map((k) => k === 'body' ? <textarea key={k} rows={4} className="input md:col-span-3" placeholder={k} value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
        : <input key={k} className="input" placeholder={k === 'url' ? 'YouTube / video URL' : k} value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />)}
      <div className="flex gap-2"><button onClick={save} className="btn btn-accent">{f._id ? 'Update' : '+ Add'}</button>{f._id && <button onClick={() => setF({})} className="btn btn-ghost">Cancel</button>}</div>
    </div>
    <div className="space-y-2">{list.data?.map((x) => (
      <div key={x._id} className="card p-3 flex justify-between items-center text-sm"><div><b>{x.title}</b><p className="text-xs text-gray-500">{x.subtitle || x.excerpt || x.url}</p></div>
        <div className="flex gap-1"><button onClick={() => setF(x)} className="btn btn-ghost !text-xs !px-2">Edit</button>
          <button onClick={async () => { if (confirm('Delete?')) { await api(`/admin/${kind}/${x._id}`, { method: 'DELETE' }); list.reload(); } }} className="btn btn-ghost !text-xs !px-2 !text-red-600">Delete</button></div></div>
    ))}</div>
  </div>);
}

function useSettings() {
  const s = useFetch<any>('/admin/settings');
  const save = async (patch: any) => { try { await api('/admin/settings', { method: 'PUT', body: patch }); s.reload(); alert('Saved'); } catch (e: any) { alert(e.message); } };
  return { s: s.data, save };
}
function Settings() {
  const { s, save } = useSettings(); const [v, setV] = useState<any>(null);
  useEffect(() => { if (s) setV(JSON.parse(JSON.stringify(s))); }, [s]);
  if (!v) return <p>Loading…</p>;
  const F = (path: string, label: string, area = false) => {
    const [a, b] = path.split('.'); const val = b ? v[a]?.[b] : v[a];
    const on = (e: any) => setV(b ? { ...v, [a]: { ...(v[a] || {}), [b]: e.target.value } } : { ...v, [a]: e.target.value });
    return <div key={path}><label className="label">{label}</label>{area ? <textarea className="input" rows={2} value={val || ''} onChange={on} /> : <input className="input" value={val || ''} onChange={on} />}</div>;
  };
  return (<div className="space-y-4">
    <div className="card p-4 grid md:grid-cols-2 gap-3"><h3 className="md:col-span-2 font-bold">Hero section</h3>{F('hero.title', 'Hero title')}{F('hero.subtitle', 'Hero subtitle')}
      <div className="md:col-span-2"><label className="label">Popular searches (comma separated)</label><input className="input" value={(v.popularSearches || []).join(', ')} onChange={(e) => setV({ ...v, popularSearches: e.target.value.split(',').map((x: string) => x.trim()).filter(Boolean) })} /></div></div>
    <div className="card p-4 grid md:grid-cols-4 gap-3"><h3 className="md:col-span-4 font-bold">Platform stats (trust counters)</h3>{F('stats.businesses', 'Local businesses')}{F('stats.customers', 'Happy customers')}{F('stats.verified', 'Verified label')}{F('stats.support', 'Support label')}</div>
    <div className="card p-4 grid md:grid-cols-3 gap-3"><h3 className="md:col-span-3 font-bold">Location banner</h3>{F('locationBanner.title', 'Title')}{F('locationBanner.subtitle', 'Subtitle')}{F('locationBanner.image', 'Image URL')}</div>
    <div className="card p-4 grid md:grid-cols-2 gap-3"><h3 className="md:col-span-2 font-bold">Call-to-action boxes</h3>{F('cta.vendorTitle', 'Vendor CTA title')}{F('cta.vendorText', 'Vendor CTA text')}{F('cta.advertiseTitle', 'Advertise title')}{F('cta.advertiseText', 'Advertise text')}</div>
    <div className="card p-4 grid md:grid-cols-3 gap-3"><h3 className="md:col-span-3 font-bold">Social & app links</h3>{F('social.facebook', 'Facebook')}{F('social.instagram', 'Instagram')}{F('social.youtube', 'YouTube')}{F('social.linkedin', 'LinkedIn')}{F('apps.android', 'Google Play URL')}{F('apps.ios', 'App Store URL')}</div>
    <button onClick={() => { const { pages, searchStats, ...rest } = v; save(rest); }} className="btn btn-brand">Save homepage settings</button>
  </div>);
}

function Legal() {
  const { s, save } = useSettings(); const [pages, setPages] = useState<any>(null);
  useEffect(() => { if (s) setPages(s.pages || {}); }, [s]);
  if (!pages) return <p>Loading…</p>;
  return (<div className="space-y-4">{Object.entries(pages).map(([k, p]: any) => (
    <div key={k} className="card p-4"><input className="input font-bold mb-2" value={p.title} onChange={(e) => setPages({ ...pages, [k]: { ...p, title: e.target.value } })} />
      <textarea className="input" rows={8} value={p.body} onChange={(e) => setPages({ ...pages, [k]: { ...p, body: e.target.value } })} /><p className="text-xs text-gray-500 mt-1">URL: /legal/{k}</p></div>
  ))}<button onClick={() => save({ pages })} className="btn btn-brand">Save legal pages</button></div>);
}

function Payments() {
  const p = useFetch<any[]>('/admin/payments');
  return (<div className="card overflow-x-auto"><table className="w-full text-sm"><thead className="bg-gray-50 text-left"><tr><th className="p-3">Date</th><th>Purpose</th><th>Amount</th><th>Razorpay ID</th><th>Status</th></tr></thead>
    <tbody>{p.data?.map((x) => <tr key={x._id} className="border-t"><td className="p-3">{new Date(x.createdAt).toLocaleString()}</td><td>{x.purpose}{x.mock && ' (test)'}</td><td>₹{x.amount}</td><td className="text-xs">{x.razorpayPaymentId || x.orderId}</td><td><Badge s={x.status} /></td></tr>)}</tbody></table></div>);
}

function Logs() {
  const n = useFetch<any[]>('/admin/notifications'); const a = useFetch<any[]>('/admin/audit');
  const run = async () => { const r = await api('/admin/run-expiry-job', { body: {} }); alert(JSON.stringify(r)); n.reload(); };
  return (<div className="grid md:grid-cols-2 gap-4">
    <div><div className="flex justify-between mb-2"><h3 className="font-bold">Notifications / email & WhatsApp alerts</h3><button onClick={run} className="btn btn-ghost !text-xs">Run expiry check now</button></div>
      <div className="space-y-2">{n.data?.map((x) => <div key={x._id} className="card p-3 text-xs"><b>{x.title}</b> <span className="text-gray-400">[{x.channel}] → {x.to || 'admin'}</span><p>{x.message}</p><p className="text-gray-400">{new Date(x.createdAt).toLocaleString()}</p></div>)}</div></div>
    <div><h3 className="font-bold mb-2">Audit log</h3><div className="space-y-2">{a.data?.map((x) => <div key={x._id} className="card p-3 text-xs"><b>{x.action}</b> {JSON.stringify(x.meta)}<p className="text-gray-400">{new Date(x.createdAt).toLocaleString()}</p></div>)}</div></div>
  </div>);
}
