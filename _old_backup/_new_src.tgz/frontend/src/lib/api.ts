'use client';
import { useEffect, useState } from 'react';

export const API = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

export const getToken = () => (typeof window === 'undefined' ? null : localStorage.getItem('pvrs_token'));
export const getUser = () => {
  if (typeof window === 'undefined') return null;
  try { return JSON.parse(localStorage.getItem('pvrs_user') || 'null'); } catch { return null; }
};
export const setSession = (token: string, user: any) => {
  localStorage.setItem('pvrs_token', token); localStorage.setItem('pvrs_user', JSON.stringify(user));
  window.dispatchEvent(new Event('pvrs-auth'));
};
export const logout = () => { localStorage.removeItem('pvrs_token'); localStorage.removeItem('pvrs_user'); window.dispatchEvent(new Event('pvrs-auth')); };

export async function api<T = any>(path: string, opts: { method?: string; body?: any; form?: FormData } = {}): Promise<T> {
  const headers: Record<string, string> = {};
  const t = getToken(); if (t) headers.Authorization = `Bearer ${t}`;
  let body: any;
  if (opts.form) body = opts.form;
  else if (opts.body !== undefined) { headers['Content-Type'] = 'application/json'; body = JSON.stringify(opts.body); }
  const res = await fetch(`${API}/api${path}`, { method: opts.method || (body ? 'POST' : 'GET'), headers, body, cache: 'no-store' });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && t) logout();
  if (!res.ok) throw new Error(data.message || `Request failed (${res.status})`);
  return data;
}

export function useUser() {
  const [user, setUser] = useState<any>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const f = () => setUser(getUser());
    f(); setReady(true);
    window.addEventListener('pvrs-auth', f);
    return () => window.removeEventListener('pvrs-auth', f);
  }, []);
  return { user, ready };
}

export function useFetch<T = any>(path: string | null, deps: any[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const load = () => {
    if (!path) return;
    setLoading(true);
    api<T>(path).then((d) => { setData(d); setError(''); }).catch((e) => setError(e.message)).finally(() => setLoading(false));
  };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(load, [path, ...deps]);
  return { data, error, loading, reload: load, setData };
}

export const img = (u?: string) => (!u ? '' : u.startsWith('http') ? u : `${API}${u}`);
export const privateFile = (p?: string) => (p ? `${API}/api/admin/files/${p}?token=${getToken()}` : '#');

export function ytId(url?: string) {
  if (!url) return null;
  const m = url.match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([\w-]{11})/);
  return m ? m[1] : null;
}
export const ytThumb = (url?: string) => { const id = ytId(url); return id ? `https://img.youtube.com/vi/${id}/hqdefault.jpg` : ''; };

export const CITY_KEY = 'pvrs_city';
export const getCity = () => (typeof window === 'undefined' ? 'Udupi' : localStorage.getItem(CITY_KEY) || 'Udupi');
