'use client';
import Link from 'next/link';
import { api, img } from '@/lib/api';

export const track = (businessId: string, type: string) => api('/leads', { body: { businessId, type } }).catch(() => {});

export default function BizCard({ b }: { b: any }) {
  return (
    <div className="card overflow-hidden hover:shadow-lg transition flex flex-col">
      <Link href={`/business/${b._id}`} className="block relative h-36 bg-gradient-to-br from-blue-50 to-orange-50">
        {b.profileImage ? <img src={img(b.profileImage)} alt={b.name} className="w-full h-full object-cover" /> : <div className="h-full flex items-center justify-center text-5xl">🏪</div>}
        {b.plan === 'premium' && <span className="absolute top-2 left-2 bg-accent text-white text-[10px] font-bold px-2 py-0.5 rounded">PREMIUM</span>}
        {b.verified && <span className="absolute top-2 right-2 bg-green-600 text-white text-[10px] font-bold px-2 py-0.5 rounded">✔ Verified</span>}
      </Link>
      <div className="p-3 flex-1 flex flex-col">
        <Link href={`/business/${b._id}`} className="font-bold text-gray-900 truncate hover:text-brand">{b.name}</Link>
        <p className="text-xs text-gray-500">{b.city} · {b.subCategory}</p>
        {b.rating > 0 && <p className="text-xs mt-1"><span className="bg-green-600 text-white px-1.5 rounded font-bold">{Number(b.rating).toFixed(1)}★</span> <span className="text-gray-500">{b.reviews} ratings</span></p>}
        {b.unclaimed && <Link href={`/business/${b._id}#claim`} className="flash mt-2 text-[11px] font-bold text-accent">⚠ Is this your business? Claim it now!</Link>}
        <div className="mt-auto pt-3">
          {b.contact ? (
            <div className="flex gap-2">
              <a href={`tel:${b.contact.phone}`} onClick={() => track(b._id, 'call')} className="flex-1 btn btn-ghost !py-1.5 !text-xs">📞 Call</a>
              <a href={`https://wa.me/91${b.contact.whatsapp || b.contact.phone}`} target="_blank" onClick={() => track(b._id, 'whatsapp')} className="flex-1 btn !py-1.5 !text-xs bg-green-500 text-white hover:bg-green-600">💬 WhatsApp</a>
            </div>
          ) : (
            <Link href={`/business/${b._id}`} className="btn btn-brand w-full !py-1.5 !text-xs">Send Enquiry</Link>
          )}
        </div>
      </div>
    </div>
  );
}
