// Default texts of the 3 plan cards on /advertise — editable in Admin → Homepage Settings → Pricing plans
export type PlanText = { n: string; feats: string[]; no: string[]; cta: string; best?: boolean };
export const DEFAULT_PLANS: PlanText[] = [
  { n: 'Free Listing', feats: ['Business page & search visibility', '1 profile image', 'Enquiry form leads', 'Verified badge after document check'], no: ['Call & WhatsApp buttons', 'Gallery & videos'], cta: 'Start free' },
  { n: 'Premium', feats: ['Call & WhatsApp buttons unlocked', 'Photo gallery + header banner', 'YouTube / Facebook / Instagram videos', 'Featured homepage slider', 'WhatsApp alert on every lead', 'Banner ad booking'], no: [], cta: 'Go Premium', best: true },
  { n: 'Banner Ads', feats: ['Top carousel or middle banner', 'Promotional widget', 'Hero video ad (2× price)', 'Book & pay from dashboard'], no: [], cta: 'Book a banner' },
];
