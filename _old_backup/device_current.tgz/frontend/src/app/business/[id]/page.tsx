'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { api, img, useFetch, useUser, ytId, useConfig, localFavs, toggleLocalFav } from '@/lib/api';
import BizCard, { track } from '@/components/BizCard';
import { HoursTable, openNow } from '@/components/Hours';

function Embed({ url }: { url: string }) {
  const id = ytId(url);
  if (id) return <iframe className="w-full aspect-video rounded-xl" src={`https://www.youtube.com/embed/${id}`} allowFullScreen />;
  if (url.includes('facebook.com')) return <iframe className="w-full aspect-video rounded-xl" src={`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}`} allowFullScreen />;
  if (url.includes('instagram.com')) { const clean = url.split('?')[0].replace(/\/$/, ''); return <iframe className="w-full h-[480px] rounded-xl" src={`${clean}/embed`} />; }
  return null;
}
const Stars = ({ n, size = 'text-base' }: { n: number; size?: string }) => (
  <span className={`${size} text-amber-400`}>{[1, 2, 3, 4, 5].map((i) => <span key={i}>{i <= Math.round(n) ? '★' : '☆'}</span>)}</span>
);

export default function BusinessPage() {
  const { id } = useParams<{ id: string }>();
  const { data: b, error, loading } = useFetch<any>(`/businesses/${id}`);
  const { data: cats } = useFetch<any[]>('/categories');
  const reviews = useFetch<any[]>(`/businesses/${id}/reviews`);
  const { user } = useUser();
  const { f } = useConfig();
  const [report, setReport] = useState<any>(null);
  const [sheet, setSheet] = useState(false);
  const [photo, setPhoto] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [saved, setSaved] = useState(false);
  const [enq, setEnq] = useState<any>({ name: '', phone: '', message: '' });
  const [rev, setRev] = useState<any>({ rating: 5, text: '' });
  const fileRef = useRef<HTMLInputElement>(null);
  const tracked = useRef(false);
  useEffect(() => { if (b && !tracked.current) { tracked.current = true; track(b._id, 'view'); } }, [b]);
  useEffect(() => { if (user) setEnq((e: any) => ({ ...e, name: e.name || user.name || '', phone: e.phone || user.phone || '' })); }, [user]);
  useEffect(() => { if (!b) return; if (user) api<any[]>('/favorites').then((l) => setSaved(l.some((x) => x._id === b._id))).catch(() => {}); else setSaved(localFavs().includes(b._id)); }, [user, b]);
  const flash = (m: string) => { setToast(m); setTimeout(() => setToast(''), 3500); };

  if (loading) return (
    <div className="max-w-6xl mx-auto px-4 py-6 animate-pulse space-y-4"><div className="h-48 bg-gray-200 rounded-2xl" /><div className="h-6 w-1/2 bg-gray-200 rounded" /><div className="h-24 bg-gray-200 rounded-2xl" /></div>
  );
  if (error || !b) return <div className="p-16 text-center"><div className="text-6xl">🔍</div><h1 className="text-xl font-bold mt-3">Listing not found</h1><Link href="/" className="btn btn-brand mt-4">Go home</Link></div>;
  const cat = cats?.find((c) => c.slug === b.category);
  const isFood = /food|restaurant/.test(b.category);
  const isMedical = /health|medical|hospital/.test(b.category);

  const claim = async () => {
    const f = fileRef.current?.files?.[0]; if (!f) return flash('Please attach a proof document');
    const fd = new FormData(); fd.append('businessId', b._id); fd.append('document', f); fd.append('name', user?.name || '');
    try { flash((await api('/vendor/claims', { form: fd })).message); } catch (e: any) { flash(e.message); }
  };
  const sendEnq = async (e: React.FormEvent) => {
    e.preventDefault();
    try { flash((await api('/enquiries', { body: { businessId: b._id, ...enq } })).message); setEnq({ ...enq, message: '' }); } catch (er: any) { flash(er.message); }
  };
  const sendRev = async (e: React.FormEvent) => {
    e.preventDefault();
    try { flash((await api('/reviews', { body: { businessId: b._id, ...rev } })).message); setRev({ rating: 5, text: '', name: rev.name, phone: rev.phone }); } catch (er: any) { flash(er.message); }
  };
  const fav = async () => {
    if (!user) { const on = toggleLocalFav(b._id); setSaved(on); return flash(on ? 'Saved to this device ❤️' : 'Removed from saved'); }
    try { setSaved((await api(`/favorites/${b._id}`, { body: {} })).saved); } catch (e: any) { flash(e.message); }
  };
  const sendReport = async (e: React.FormEvent) => {
    e.preventDefault();
    try { flash((await api('/reports', { body: { businessId: b._id, ...report } })).message); setReport(null); } catch (er: any) { flash(er.message); }
  };
  const share = async () => {
    const url = window.location.href;
    try { if (navigator.share) await navigator.share({ title: b.name, url }); else { await navigator.clipboard.writeText(url); flash('Link copied'); } } catch { /* cancelled */ }
  };

  const ld = { '@context': 'https://schema.org', '@type': 'LocalBusiness', name: b.name, description: b.description, image: b.profileImage ? img(b.profileImage) : undefined, address: { '@type': 'PostalAddress', streetAddress: b.address, addressLocality: b.city, addressCountry: 'IN' }, ...(b.rating > 0 ? { aggregateRating: { '@type': 'AggregateRating', ratingValue: Number(b.rating).toFixed(1), reviewCount: b.reviews || 1 } } : {}), ...(b.contact?.phone ? { telephone: '+91' + b.contact.phone } : {}) };
  return (
    <div className="max-w-6xl mx-auto px-3 md:px-4 py-4">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld).replace(/</g, '\\u003c') }} />
      <p className="text-xs text-gray-500 mb-3"><Link href="/" className="hover:text-brand">Home</Link> › <Link href={`/category/${b.category}`} className="hover:text-brand">{cat?.name}</Link> › {b.subCategory}</p>

      {/* Hero */}
      <div className="relative rounded-2xl overflow-hidden bg-gradient-to-r from-[#0033aa] to-brand">
        {b.bannerImage && <img src={img(b.bannerImage)} alt="" className="absolute inset-0 w-full h-full object-cover opacity-40" />}
        <div className="relative p-5 md:p-8 flex flex-col md:flex-row gap-5 text-white">
          <div className="w-28 h-28 md:w-36 md:h-36 rounded-2xl overflow-hidden bg-white/20 ring-4 ring-white/40 flex items-center justify-center text-5xl shrink-0 shadow-xl">
            {b.profileImage ? <img src={img(b.profileImage)} alt={b.name} className="w-full h-full object-cover" /> : '🏪'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap gap-2 mb-2">
              {b.verified && <span className="bg-emerald-500 text-xs font-bold px-2.5 py-1 rounded-full">✔ Verified</span>}
              {b.plan === 'premium' && <span className="bg-accent text-xs font-bold px-2.5 py-1 rounded-full">★ Premium</span>}
              <span className="bg-white/20 text-xs font-semibold px-2.5 py-1 rounded-full">{cat?.icon} {b.subCategory}</span>
            </div>
            <h1 className="text-2xl md:text-4xl font-black leading-tight flex items-center gap-2">{b.name} {b.verified && <span title="Verified Profile" className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm shadow-md" style={{marginTop: "4px"}}>✓</span>}</h1>
            <div className="flex flex-wrap items-center gap-3 mt-2 text-sm">
              {b.rating > 0 && <span className="flex items-center gap-1"><span className="bg-emerald-600 px-2 py-0.5 rounded font-bold">{Number(b.rating).toFixed(1)}★</span> {b.reviews} ratings</span>}
              <span>📍 {b.address ? `${b.address}, ` : ''}{b.city}</span>
              {b.hours ? (() => { const o = openNow(b.hours); return o && <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${o.open ? 'bg-emerald-500' : 'bg-red-500/90'}`}>{o.open ? '● ' : ''}{o.label}</span>; })() : b.timings && <span>🕒 {b.timings}</span>}
            </div>
          </div>
          <div className="flex md:flex-col gap-2 md:self-start">
            <button onClick={fav} className="btn bg-white/15 hover:bg-white/25 text-white !text-xs">{saved ? '❤️ Saved' : '🤍 Save'}</button>
            <button onClick={share} className="btn bg-white/15 hover:bg-white/25 text-white !text-xs">🔗 Share</button>
          </div>
        </div>
      </div>

      {/* Action bar */}
      <div className="card p-3 md:p-4 mt-3 flex flex-wrap gap-2 items-center md:sticky md:top-[108px] z-20 shadow-sm">
        {b.contact ? (<>
          <a href={`tel:${b.contact.phone}`} onClick={() => track(b._id, 'call')} className="btn btn-brand flex-1 md:flex-none">📞 Call Now</a>
          <a href={`https://wa.me/91${b.contact.whatsapp || b.contact.phone}`} target="_blank" onClick={() => track(b._id, 'whatsapp')} className="btn bg-green-500 text-white hover:bg-green-600 flex-1 md:flex-none">💬 WhatsApp</a>
        </>) : (
          <a href="#enquiry" className="btn btn-brand flex-1 md:flex-none">✉️ Send Enquiry</a>
        )}
        {isFood && b.orderOnline && f.orderOnline !== false && <button onClick={() => { setSheet(true); track(b._id, 'order'); }} className="btn btn-accent flex-1 md:flex-none">🛵 Order Online</button>}
        {b.mapUrl && <a href={b.mapUrl} target="_blank" className="btn btn-ghost flex-1 md:flex-none">🗺️ Directions</a>}
        {b.contactLocked && <span className="text-xs text-gray-500 w-full md:w-auto md:ml-auto"><b className="font-mono text-sm text-gray-700">📞 XXXXXXXXXX</b> 🔒 Number shown on Premium listings — send an enquiry instead.</span>}
      </div>

      {b.unclaimed && <a href="#claim" className="flash block mt-3 text-center rounded-xl bg-orange-50 border border-orange-200 py-2 text-sm font-bold text-accent">⚠ Is this your business? Claim it now!</a>}

      <div className="grid md:grid-cols-3 gap-4 mt-4">
        <div className="md:col-span-2 space-y-4">
          {b.description && <section className="card p-5"><h2 className="font-bold mb-2">About</h2><p className="text-sm text-gray-700 whitespace-pre-line leading-relaxed">{b.description}</p>
            {b.tags?.length > 0 && <div className="flex flex-wrap gap-1.5 mt-3">{b.tags.map((t: string) => <span key={t} className="text-xs bg-gray-100 rounded-full px-2.5 py-1">{t}</span>)}</div>}</section>}

          {b.gallery?.length > 0 && (
            <section className="card p-5"><h2 className="font-bold mb-3">Photos ({b.gallery.length})</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">{b.gallery.map((g: string) => <button key={g} onClick={() => setPhoto(g)}><img src={img(g)} alt="" className="w-full h-28 object-cover rounded-lg hover:opacity-90" /></button>)}</div>
            </section>
          )}
          {b.videos && Object.values(b.videos).some(Boolean) && (
            <section className="card p-5"><h2 className="font-bold mb-3">Videos</h2>
              <div className="grid md:grid-cols-2 gap-3">{Object.values(b.videos).filter(Boolean).map((u: any) => <Embed key={u} url={u} />)}</div>
            </section>
          )}

          {isMedical && (
            <div className="p-4 rounded-xl bg-yellow-50 border border-yellow-300 text-xs text-yellow-900">
              <b>Three-Possibility Rule:</b> this medical information may be accurate, outdated, or incorrect. Always verify registration numbers, qualifications and medicine labels directly with the provider. <Link href="/legal/disclaimer" className="underline">Read disclaimer</Link>
            </div>
          )}

          {/* Reviews */}
          <section className="card p-5">
            <div className="flex items-center justify-between mb-3"><h2 className="font-bold">Ratings & Reviews</h2>{b.rating > 0 && <span className="flex items-center gap-2"><b className="text-2xl">{Number(b.rating).toFixed(1)}</b><Stars n={b.rating} /></span>}</div>
            {f.reviews === false ? <p className="text-xs text-gray-400 mb-3">Reviews are paused right now.</p> : user ? (
              <form onSubmit={sendRev} className="bg-gray-50 rounded-xl p-3 mb-4">
                <div className="flex items-center gap-1 mb-2 text-2xl">{[1, 2, 3, 4, 5].map((i) => <button type="button" key={i} onClick={() => setRev({ ...rev, rating: i })} className={i <= rev.rating ? 'text-amber-400' : 'text-gray-300'}>★</button>)}</div>
                <textarea className="input" rows={2} placeholder="Share your experience…" value={rev.text} onChange={(e) => setRev({ ...rev, text: e.target.value })} />
                <button className="btn btn-brand mt-2 !text-xs">Submit review</button>
              </form>
            ) : <Link href={`/login?intent=user&next=/business/${b._id}`} className="block text-sm text-brand font-semibold mb-4">Login with OTP to write a review ➔</Link>}
            <div className="space-y-3">
              {reviews.data?.map((r) => (
                <div key={r._id} className="border-b last:border-0 pb-3">
                  <div className="flex items-center gap-2"><span className="w-8 h-8 rounded-full bg-brand/10 text-brand font-bold flex items-center justify-center text-sm">{(r.name || 'C')[0]}</span><b className="text-sm">{r.name}</b><Stars n={r.rating} size="text-sm" /><span className="text-xs text-gray-400 ml-auto">{new Date(r.createdAt).toLocaleDateString('en-IN')}</span></div>
                  {r.text && <p className="text-sm text-gray-700 mt-1 ml-10">{r.text}</p>}
                </div>
              ))}
              {!reviews.data?.length && <p className="text-sm text-gray-500">No reviews yet. Be the first!</p>}
            </div>
          </section>

          {/* Related Businesses */}
          {b.related?.length > 0 && (
            <section className="mt-8">
              <h2 className="font-bold text-xl mb-4">Similar Businesses you might like</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                {b.related.map((rBiz: any) => (
                  <BizCard key={rBiz._id} b={rBiz} />
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Sidebar */}
        <aside className="space-y-4">
          {f.enquiries !== false && <form id="enquiry" onSubmit={sendEnq} className="card p-5 scroll-mt-40">
            <h2 className="font-bold">Send Enquiry</h2><p className="text-xs text-gray-500 mb-3">The business will call you back.</p>
            <input required className="input mb-2" placeholder="Your name" value={enq.name} onChange={(e) => setEnq({ ...enq, name: e.target.value })} />
            <input required className="input mb-2" inputMode="numeric" maxLength={10} placeholder="10-digit mobile" value={enq.phone} onChange={(e) => setEnq({ ...enq, phone: e.target.value.replace(/\D/g, '') })} />
            <textarea className="input mb-2" rows={3} placeholder="What do you need?" value={enq.message} onChange={(e) => setEnq({ ...enq, message: e.target.value })} />
            <button className="btn btn-accent w-full">Send Enquiry</button>
          </form>}
          <div className="card p-5 text-sm space-y-2">
            <h2 className="font-bold">Details</h2>
            <p>📍 {b.address ? `${b.address}, ` : ''}{b.city}</p>
            {b.hours ? <div className="pt-2"><p className="font-semibold mb-1">🕒 Business hours</p><HoursTable hours={b.hours} /></div> : b.timings && <p>🕒 {b.timings}</p>}
            {b.contact?.email && <p>✉️ {b.contact.email}</p>}
            <p>{cat?.icon} {cat?.name} › {b.subCategory}</p>
            {f.reports !== false && <button onClick={() => (user ? setReport({ reason: '' }) : (window.location.href = '/login?intent=user&next=' + encodeURIComponent(window.location.pathname)))} className="text-xs text-red-500 hover:underline pt-2">🚩 Report this listing</button>}
          </div>
          {b.unclaimed && f.claims !== false && (
            <div id="claim" className="card p-5 border-accent scroll-mt-40">
              <h2 className="font-bold text-accent">Claim this business</h2>
              <p className="text-xs text-gray-600 mt-1">Verify with Trade License / FSSAI / KMC certificate. After admin approval you can manage this page.</p>
              {user ? (<><input ref={fileRef} type="file" accept=".jpg,.jpeg,.png,.pdf" className="input mt-3" /><button onClick={claim} className="btn btn-accent w-full mt-2">Submit Claim</button></>)
                : <Link href={`/login?intent=vendor&next=/business/${b._id}`} className="btn btn-accent w-full mt-3">Login to claim</Link>}
            </div>
          )}
        </aside>
      </div>

      {report && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end md:items-center justify-center" onClick={() => setReport(null)}>
          <form onSubmit={sendReport} className="bg-white w-full md:max-w-md rounded-t-2xl md:rounded-2xl p-5 slideup" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-bold text-lg">Report {b.name}</h3><p className="text-xs text-gray-500 mb-3">Reports go to our Grievance team (IT Act Sec. 79).</p>
            <div className="grid grid-cols-2 gap-2 mb-3">{['Fake / fraud listing', 'Wrong phone / address', 'Business closed', 'Offensive content', 'Copyright / trademark', 'Other'].map((r) => (
              <button type="button" key={r} onClick={() => setReport({ ...report, reason: r })} className={`text-xs border rounded-lg px-2 py-2 ${report.reason === r ? 'border-red-500 bg-red-50 text-red-700 font-semibold' : ''}`}>{r}</button>))}</div>
            <textarea className="input mb-2" rows={3} placeholder="Details (optional)" value={report.details || ''} onChange={(e) => setReport({ ...report, details: e.target.value })} />
            <div className="flex gap-2"><button type="button" onClick={() => setReport(null)} className="btn btn-ghost flex-1">Cancel</button><button disabled={!report.reason} className="btn bg-red-600 text-white flex-1">Submit report</button></div>
          </form>
        </div>
      )}
      {photo && <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4" onClick={() => setPhoto(null)}><img src={img(photo)} alt="" className="max-h-full max-w-full rounded-lg" /></div>}
      {toast && <div className="fixed bottom-20 md:bottom-6 left-1/2 -translate-x-1/2 z-50 bg-gray-900 text-white text-sm px-4 py-2.5 rounded-full shadow-xl">{toast}</div>}

      {sheet && (
        <div className="fixed inset-0 z-50 bg-black/50" onClick={() => setSheet(false)}>
          <div className="absolute bottom-0 inset-x-0 md:max-w-md md:mx-auto bg-white rounded-t-2xl p-5 slideup" onClick={(e) => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
            <h3 className="font-bold text-lg">Order from {b.name}</h3>
            <p className="text-xs text-gray-500 mb-4">You will be redirected to the partner app</p>
            <div className="space-y-3">
              {b.orderOnline.swiggy && <a href={b.orderOnline.swiggy} target="_blank" className="flex items-center justify-between rounded-xl px-4 py-3 text-white font-bold" style={{ background: '#FC8019' }}><span className="text-lg">Swiggy</span><span>Order →</span></a>}
              {b.orderOnline.zomato && <a href={b.orderOnline.zomato} target="_blank" className="flex items-center justify-between rounded-xl px-4 py-3 text-white font-bold" style={{ background: '#E23744' }}><span className="text-lg italic">zomato</span><span>Order →</span></a>}
            </div>
            <button onClick={() => setSheet(false)} className="btn btn-ghost w-full mt-4">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
