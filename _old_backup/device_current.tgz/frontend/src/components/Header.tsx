'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useUser, logout, CITY_KEY, getCity, useConfig } from '@/lib/api';
import Suggest from './Suggest';

const CITIES = ['Udupi', 'Manipal', 'Malpe', 'Mangaluru', 'Kundapura', 'Karkala'];
const NAV = [['Home', '/'], ['Categories', '/categories'], ['Offers', '/offers'], ['Featured', '/search?featured=1'], ['Trending', '/trending'], ['Videos', '/videos'], ['Blogs', '/blogs'], ['About', '/legal/about']];

export default function Header() {
  const [q, setQ] = useState('');
  const [city, setCity] = useState('Udupi');
  const [menu, setMenu] = useState(false);
  const { user } = useUser();
  const { f } = useConfig();
  const router = useRouter();
  const path = usePathname();
  useEffect(() => setCity(getCity()), []);
  if (path.startsWith('/admin')) return null;

  const changeCity = (c: string) => { setCity(c); localStorage.setItem(CITY_KEY, c); window.dispatchEvent(new Event('pvrs-city')); };
  const locate = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition((p) => {
      // Nearest of our coastal cities (approx coords)
      const pts: Record<string, [number, number]> = { Udupi: [13.34, 74.74], Manipal: [13.35, 74.79], Malpe: [13.35, 74.70], Mangaluru: [12.91, 74.86], Kundapura: [13.62, 74.69], Karkala: [13.21, 74.99] };
      let best = 'Udupi', d = 1e9;
      for (const [k, [a, b]] of Object.entries(pts)) { const x = (a - p.coords.latitude) ** 2 + (b - p.coords.longitude) ** 2; if (x < d) { d = x; best = k; } }
      changeCity(best);
    });
  };
  const search = (e?: React.FormEvent) => { e?.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}&city=${city}`); };
  const dash = ['admin', 'moderator'].includes(user?.role) ? '/admin' : user?.role === 'vendor' ? '/vendor/dashboard' : '/vendor/dashboard';

  return (
    <header className="bg-white border-b sticky top-0 z-40 shadow-sm">
      <div className="max-w-7xl mx-auto px-3 md:px-4 py-2 md:py-3 flex items-center gap-3">
        <Link href="/" className="flex items-center gap-1 shrink-0">
          <span className="text-2xl">📍</span>
          <span className="leading-none">
            <span className="block text-xl md:text-2xl font-black text-brand">PVRS <span className="text-accent">HUB</span></span>
            <span className="hidden md:block text-[9px] text-gray-500">Udupi | Mangaluru | Our Local. Your Global.</span>
          </span>
        </Link>

        {/* Desktop search */}
        <form onSubmit={search} className="hidden md:flex flex-1 min-w-0 max-w-2xl mx-2 lg:mx-4 border border-gray-300 rounded-lg focus-within:border-brand">
          <div className="flex items-center px-2 bg-gray-50 border-r rounded-l-lg">
            <button type="button" onClick={locate} title="Use my location" className="text-brand px-1">📍</button>
            <select value={city} onChange={(e) => changeCity(e.target.value)} className="bg-transparent outline-none text-sm font-medium py-2 max-w-[100px]">
              {CITIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div className="flex-1 relative flex"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search for businesses, products or services..." className="flex-1 px-3 text-sm outline-none" /><Suggest q={q} onPick={() => setQ('')} /></div>
          <button className="bg-brand text-white px-6 rounded-r-lg font-semibold hover:bg-brand-dark">Search</button>
        </form>

        <div className="ml-auto flex items-center gap-3 text-xs font-medium shrink-0">
          <Link href="/advertise" className="hidden lg:flex flex-col items-center text-gray-600 hover:text-brand"><span className="text-lg">🏢</span>For Businesses</Link>
          {user ? (
            <div className="relative">
              <button onClick={() => setMenu(!menu)} className="flex flex-col items-center text-gray-700 hover:text-brand">
                <span className="text-lg">👤</span><span className="hidden lg:block max-w-[110px] truncate">{user.name || user.phone}</span>
              </button>
              {menu && (
                <div className="absolute right-0 mt-2 w-48 card shadow-lg py-1 text-sm z-50" onMouseLeave={() => setMenu(false)}>
                  <Link href={dash} className="block px-4 py-2 hover:bg-gray-50" onClick={() => setMenu(false)}>{['admin', 'moderator'].includes(user.role) ? 'Admin Panel' : 'My Dashboard'}</Link>
                  <Link href="/register-business" className="block px-4 py-2 hover:bg-gray-50" onClick={() => setMenu(false)}>Add Listing</Link>
                  <Link href="/favorites" className="block px-4 py-2 hover:bg-gray-50" onClick={() => setMenu(false)}>❤️ Saved Businesses</Link>
                    <Link href="/contact?tab=mine" className="block px-4 py-2 hover:bg-gray-50" onClick={() => setMenu(false)}>⚠️ My Complaints</Link>
                  <button onClick={() => { logout(); setMenu(false); router.push('/'); }} className="block w-full text-left px-4 py-2 hover:bg-gray-50 text-red-600">Logout</button>
                </div>
              )}
            </div>
          ) : (
            <>
            <Link href="/favorites" className="hidden lg:flex flex-col items-center text-gray-600 hover:text-brand"><span className="text-lg">❤️</span><span>Saved</span></Link>
            <Link href="/login" className="flex flex-col items-center text-gray-600 hover:text-brand"><span className="text-lg">👤</span><span className="hidden lg:block">{f.customerLogin ? 'Login / Register' : 'Business Login'}</span></Link>
            </>
          )}
          <Link href="/register-business" className="hidden lg:flex flex-col items-center btn-accent rounded-lg px-4 py-1.5 shrink-0">
            <span className="font-bold text-sm">+ List Your Business</span><span className="text-[9px] uppercase opacity-90">It&apos;s Free</span>
          </Link>
        </div>
      </div>

      {/* Mobile dual-box search */}
      <form onSubmit={search} className="md:hidden px-3 pb-2 flex gap-2">
        <div className="flex items-center border rounded-lg px-2 w-[38%] bg-gray-50">
          <button type="button" onClick={locate} className="text-brand text-sm">📍</button>
          <select value={city} onChange={(e) => changeCity(e.target.value)} className="bg-transparent outline-none text-sm w-full py-2">
            {CITIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="flex-1 flex items-center border rounded-full px-3 bg-white">
          <div className="relative w-full"><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Restaurants near me" className="w-full text-sm outline-none py-2" /><Suggest q={q} onPick={() => setQ('')} /></div>
          <button className="text-brand">🔍</button>
        </div>
      </form>

      <nav className="hidden md:block bg-brand text-white">
        <ul className="max-w-7xl mx-auto px-4 flex gap-1 text-sm font-medium">
          {NAV.map(([n, h]) => (
            <li key={n}><Link href={h} className={`block px-4 py-2 hover:bg-white/15 ${path === h ? 'bg-white/20' : ''}`}>{n}</Link></li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
