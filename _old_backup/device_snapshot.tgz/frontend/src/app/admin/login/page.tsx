'use client';
import { E } from '@/components/Icon';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, setSession } from '@/lib/api';

export default function AdminLogin() {
  const router = useRouter();
  const [phone, setPhone] = useState('9999999999');
  const [otp, setOtp] = useState('123456');
  const [step, setStep] = useState(1);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const sendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setMsg('');
    try {
      const r = await api('/auth/request-otp', { body: { phone } });
      setMsg(r.message || 'OTP Sent (Check console or use 123456)');
      setStep(2);
    } catch (err: any) {
      setMsg(err.message || 'Error sending OTP');
    }
    setBusy(false);
  };

  const verifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setMsg('');
    try {
      const r = await api('/auth/verify-otp', { body: { phone, otp, intent: 'admin' } });
      if (!['admin', 'moderator'].includes(r.user?.role)) {
        throw new Error('Unauthorized: This number is not registered as an Admin.');
      }
      setSession(r.token, r.user);
      router.replace('/admin');
    } catch (err: any) {
      setMsg(err.message || 'Error verifying OTP');
    }
    setBusy(false);
  };

  return (
    <>
      <style dangerouslySetInnerHTML={{__html: `
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}} />
      <div className="min-h-screen bg-[#060a16] flex items-center justify-center p-4 font-sans relative overflow-hidden text-slate-200">
      
      {/* Animated Background Elements */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-blue-600/20 rounded-full blur-[120px] mix-blend-screen animate-pulse pointer-events-none" style={{ animationDuration: '4s' }}></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/20 rounded-full blur-[120px] mix-blend-screen animate-pulse pointer-events-none" style={{ animationDuration: '6s' }}></div>
      <div className="absolute top-[30%] left-[40%] w-[40%] h-[40%] bg-emerald-600/10 rounded-full blur-[100px] mix-blend-screen animate-pulse pointer-events-none" style={{ animationDuration: '5s' }}></div>
      
      {/* Overlay pattern (optional noise or grid) */}
      <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 pointer-events-none mix-blend-overlay"></div>

      <div className="relative max-w-[420px] w-full z-10">
        
        {/* Logo / Header area */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 shadow-lg shadow-blue-600/30 mb-4 transform rotate-3 hover:rotate-0 transition duration-300">
            <span className="text-white text-3xl font-black">A</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight text-white mb-1">System <span className="text-blue-500">Access</span></h1>
          <p className="text-slate-400 text-sm font-medium tracking-wide">Tap2Bizz MASTER CONTROL</p>
        </div>

        {/* Glass Card */}
        <div className="bg-white/[0.03] backdrop-blur-2xl rounded-3xl shadow-2xl overflow-hidden border border-white/[0.08] relative">
          {/* Top highlight border */}
          <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-blue-500/50 to-transparent"></div>
          
          <div className="p-8 md:p-10">
            {msg && (
              <div className={`p-4 rounded-xl mb-8 text-sm font-medium flex items-start gap-3 backdrop-blur-sm ${
                msg.includes('Error') || msg.includes('Unauthorized') 
                ? 'bg-red-500/10 text-red-400 border border-red-500/20' 
                : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
              }`}>
                <span className="text-lg mt-[-2px]">
                  {msg.includes('Error') || msg.includes('Unauthorized') ? <E c="⚠" /> : <E c="✓" />}
                </span>
                <span className="flex-1">{msg}</span>
              </div>
            )}
            
            {step === 1 ? (
              <form onSubmit={sendOtp} className="space-y-6">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 pl-1">Admin Mobile</label>
                  <div className="flex bg-black/40 border border-white/10 rounded-2xl overflow-hidden focus-within:border-blue-500/50 focus-within:ring-2 focus-within:ring-blue-500/20 transition-all shadow-inner">
                    <span className="px-5 py-4 bg-white/5 text-slate-400 border-r border-white/10 font-semibold">+91</span>
                    <input 
                      type="text" 
                      value={phone} 
                      onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))} 
                      className="w-full bg-transparent px-5 py-4 outline-none text-white font-medium text-lg placeholder-slate-600 transition-colors" 
                      placeholder="Enter 10 digits" 
                      required 
                    />
                  </div>
                </div>
                
                <button 
                  type="submit" 
                  disabled={busy || phone.length !== 10} 
                  className="group relative w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold py-4 rounded-2xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_20px_rgba(79,70,229,0.3)] hover:shadow-[0_0_25px_rgba(79,70,229,0.5)] overflow-hidden"
                >
                  <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-[shimmer_1.5s_infinite]"></div>
                  <span className="relative flex items-center justify-center gap-2 text-[15px]">
                    {busy ? 'Authenticating...' : 'Continue'} 
                    {!busy && <span className="group-hover:translate-x-1 transition-transform">→</span>}
                  </span>
                </button>
              </form>
            ) : (
              <form onSubmit={verifyOtp} className="space-y-6 animate-[fadeIn_0.3s_ease-out]">
                <div>
                  <label className="flex items-center justify-between text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 pl-1">
                    <span>Security Code</span>
                    <span className="text-[10px] text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded-full">Sent to +91 {phone}</span>
                  </label>
                  <input 
                    type="text" 
                    value={otp} 
                    onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))} 
                    className="w-full bg-black/40 border border-white/10 rounded-2xl px-5 py-4 outline-none focus:border-blue-500/50 focus:ring-2 focus:ring-blue-500/20 transition-all text-center tracking-[1em] text-white text-2xl font-bold placeholder-slate-700 shadow-inner" 
                    placeholder="••••••" 
                    required 
                    autoFocus
                  />
                </div>
                
                <button 
                  type="submit" 
                  disabled={busy || otp.length < 4} 
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold py-4 rounded-2xl transition-all disabled:opacity-50 shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_25px_rgba(16,185,129,0.5)] text-[15px]"
                >
                  {busy ? 'Verifying...' : 'Unlock Admin Panel'}
                </button>
                
                <button 
                  type="button" 
                  onClick={() => setStep(1)} 
                  className="w-full flex items-center justify-center gap-2 text-slate-500 text-sm font-medium hover:text-slate-300 transition-colors mt-4 py-2"
                >
                  <span>←</span> Change Phone Number
                </button>
              </form>
            )}
          </div>
          
          <div className="bg-black/20 p-5 text-center flex items-center justify-center gap-2 border-t border-white/[0.05]">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]"></span>
            <span className="text-xs text-slate-400 font-medium tracking-wide uppercase">Secure Connection Active</span>
          </div>
        </div>
        
        {/* Footer info */}
        <div className="mt-8 text-center text-xs text-slate-600 font-medium tracking-wider">
          &copy; {new Date().getFullYear()} Tap2Bizz INTERNET. ALL RIGHTS RESERVED.
        </div>
      </div>
    </div>
    </>
  );
}
