import type { MetadataRoute } from 'next';
export default function manifest(): MetadataRoute.Manifest {
  return { name: 'Tap2Bizz', short_name: 'Tap2Bizz', description: 'Udupi, Manipal, Malpe & Mangaluru local business directory', start_url: '/', display: 'standalone', background_color: '#ffffff', theme_color: '#0055FF',
    icons: [{ src: '/icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any' }] };
}
