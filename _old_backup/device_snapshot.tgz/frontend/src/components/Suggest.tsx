'use client';
import { E, CatIcon } from '@/components/Icon';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api } from '@/lib/api';

// Live autocomplete dropdown for search inputs
export default function Suggest({ q, onPick }: { q: string; onPick: () => void }) {
  const [items, setItems] = useState<any[]>([]);
  useEffect(() => {
    if (q.trim().length < 2) { setItems([]); return; }
    const t = setTimeout(() => api<any[]>(`/suggest?q=${encodeURIComponent(q)}`).then(setItems).catch(() => setItems([])), 200);
    return () => clearTimeout(t);
  }, [q]);
  if (!items.length) return null;
  return (
    <div className="absolute left-0 right-0 top-full mt-1 bg-white border rounded-xl shadow-xl z-50 overflow-hidden text-sm text-gray-800">
      {items.map((s) => (
        <Link key={s.href} href={s.href} onMouseDown={(e) => e.preventDefault()} onClick={() => { setItems([]); onPick(); }} className="flex items-center gap-3 px-4 py-2.5 hover:bg-blue-50">
          <span className="w-7 text-center">{s.type === 'business' ? <E c="🏪" /> : <CatIcon icon={s.icon} name={s.name || s.label} />}</span>
          <span className="flex-1 truncate">{s.label}</span>
          <span className="text-[10px] uppercase text-gray-400">{s.type === 'business' ? s.sub : s.type === 'sub' ? 'service' : 'category'}</span>
        </Link>
      ))}
    </div>
  );
}
