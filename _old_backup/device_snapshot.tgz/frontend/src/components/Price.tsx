'use client';
export const pct = (price: number, mrp: number) => (mrp > price && price > 0 ? Math.round((1 - price / mrp) * 100) : 0);
export function Price({ price, mrp, unit, big = 'text-3xl' }: { price: number | string; mrp?: number; unit?: string; big?: string; badge?: boolean }) {
  const p = Number(price) || 0; const off = pct(p, mrp || 0);
  return (<div>
    {off > 0 && <div className="flex items-center gap-2 text-xs"><s className="text-gray-500">₹{Number(mrp).toLocaleString('en-IN')}{unit}</s><span className="bg-green-600 text-white font-bold px-1.5 rounded">{off}% off</span></div>}
    <p className={`${big} font-black leading-tight`}>₹{p.toLocaleString('en-IN')}<span className="text-sm font-semibold text-gray-600">{unit}</span></p>
  </div>);
}

export function Ribbon({ off }: { off: number }) {
  if (off <= 0) return null;
  return (
    <div className="absolute top-4 -right-8 w-32 bg-red-600 text-white text-[10px] font-black tracking-widest text-center py-1 rotate-45 shadow-md z-10 pointer-events-none">
      SAVE {off}%
    </div>
  );
}
