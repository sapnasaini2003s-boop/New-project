'use client';
import { E, T } from '@/components/Icon';
import { useEffect, useMemo, useState } from 'react';
import { api, img, useUser } from '@/lib/api';
import type { MenuCat } from './MenuEditor';
import { menuKind } from '@/lib/menuKind';

const Dot = ({ veg }: { veg: boolean | null }) => veg === null ? <span className="w-3.5 h-3.5 shrink-0" /> : <span className={`w-3.5 h-3.5 shrink-0 border rounded-[3px] flex items-center justify-center ${veg ? 'border-green-600' : 'border-red-600'}`}><span className={`w-1.5 h-1.5 rounded-full ${veg ? 'bg-green-600' : 'bg-red-600'}`} /></span>;
const key = (c: string, n: string) => `${c}||${n}`;
type Biz = { _id: string; name: string; orderable: boolean; min?: number; whatsapp: boolean; category?: string };

// Order Online Menu: search, Veg / Non-Veg, categories, cart → order → WhatsApp to the restaurant
export default function MenuView({ menu, biz }: { menu: MenuCat[]; biz: Biz }) {
  const { user } = useUser(); const kd = menuKind(biz.category);
  const [q, setQ] = useState(''); const [showSearch, setShowSearch] = useState(false); const [veg, setVeg] = useState(false); const [non, setNon] = useState(false);
  const [closed, setClosed] = useState<Record<string, boolean>>({}); const [all, setAll] = useState<Record<string, boolean>>({}); const [jump, setJump] = useState(false);
  const [cart, setCart] = useState<Record<string, number>>({}); const [sheet, setSheet] = useState(false);
  const [f, setF] = useState({ name: '', phone: '', type: kd.types[0][0], address: '', note: '' }); const [busy, setBusy] = useState(false); const [err, setErr] = useState(''); const [done, setDone] = useState<any>(null);
  const CK = `pvrs_cart_${biz._id}`;

  useEffect(() => { try { const c = JSON.parse(localStorage.getItem(CK) || '{}'); if (c && typeof c === 'object') setCart(c); const p = JSON.parse(localStorage.getItem('pvrs_orderer') || 'null'); if (p) setF((x) => ({ ...x, name: p.name || '', phone: p.phone || '' })); } catch { /* storage unavailable */ } }, [CK]);
  useEffect(() => { if (user) setF((x) => ({ ...x, name: x.name || user.name || '', phone: x.phone || user.phone || '' })); }, [user]);
  useEffect(() => { try { localStorage.setItem(CK, JSON.stringify(cart)); } catch { /* ignore */ } }, [cart, CK]);

  const flat = useMemo(() => menu.flatMap((c) => c.items.map((i) => ({ ...i, cat: c.name, k: key(c.name, i.name), price: Number(i.price) }))), [menu]);
  const lines = flat.filter((i) => cart[i.k] > 0).map((i) => ({ ...i, qty: cart[i.k] }));
  const count = lines.reduce((s, l) => s + l.qty, 0); const total = lines.reduce((s, l) => s + l.qty * l.price, 0);
  const setQty = (k: string, d: number) => setCart((c) => { const n = Math.max(0, Math.min(20, (c[k] || 0) + d)); const x = { ...c }; if (n) x[k] = n; else delete x[k]; return x; });

  const cats = useMemo(() => menu.map((c) => ({ ...c, items: c.items.filter((i: any) => (!veg || i.veg === true) && (!non || i.veg === false) && (!q || i.name.toLowerCase().includes(q.toLowerCase()))) })).filter((c) => c.items.length), [menu, q, veg, non]);
  const chip = (on: boolean) => `px-3 py-1.5 rounded-full border text-xs font-medium flex items-center gap-1.5 transition-colors ${on ? 'border-brand bg-blue-50 text-brand' : 'border-gray-200 bg-white text-gray-700 hover:bg-gray-50'}`;

  const place = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      const r = await api(`/businesses/${biz._id}/orders`, { body: { ...f, items: lines.map((l) => ({ cat: l.cat, name: l.name, qty: l.qty })) } });
      try { localStorage.setItem('pvrs_orderer', JSON.stringify({ name: f.name, phone: f.phone })); } catch { /* ignore */ }
      setDone(r); setCart({});
      if (r.waUrl) window.open(r.waUrl, '_blank');
    } catch (er: any) { setErr(er.message); }
    setBusy(false);
  };
  const Step = ({ k }: { k: string }) => cart[k] ? (
    <div className="inline-flex items-center rounded-lg border border-green-600 bg-green-50 text-green-700 font-bold overflow-hidden"><button type="button" aria-label="Remove one" onClick={() => setQty(k, -1)} className="w-8 h-8 text-lg">−</button><span className="w-6 text-center text-sm">{cart[k]}</span><button type="button" aria-label="Add one" onClick={() => setQty(k, 1)} className="w-8 h-8 text-lg">+</button></div>
  ) : <button type="button" onClick={() => setQty(k, 1)} className="px-5 h-8 rounded-lg border border-green-600 text-green-700 text-sm font-bold bg-white hover:bg-green-50">{kd.add}</button>;

  return (
    <section className="card p-0 md:p-0 overflow-hidden relative border border-gray-200 shadow-sm">
      <div className="bg-gray-50 border-b border-gray-100 p-4 md:p-5">
        <div className="flex items-center justify-between gap-2 mb-3"><h2 className="font-bold text-base md:text-lg text-gray-900">{kd.title}</h2>{biz.orderable && <span className="text-[11px] font-semibold text-green-700 bg-green-50 border border-green-200 rounded-full px-2 py-0.5">{biz.whatsapp ? 'Order on WhatsApp' : 'Order here'}</span>}</div>
        <div className="flex gap-2 items-center flex-wrap">
          <button onClick={() => setShowSearch(!showSearch)} className={chip(showSearch)} aria-label="Search menu"><E c="🔍"/></button>
          {kd.veg && <button onClick={() => { setVeg(!veg); if (!veg) setNon(false); }} className={chip(veg)}><Dot veg={true} /> Veg</button>}
          {kd.veg && <button onClick={() => { setNon(!non); if (!non) setVeg(false); }} className={chip(non)}><Dot veg={false} /> Non Veg</button>}
        </div>
        {showSearch && <input autoFocus className="input w-full mt-3 bg-white" placeholder={`Search ${kd.noun}s…`} value={q} onChange={(e) => setQ(e.target.value)} />}
      </div>

      <div className="p-4 md:p-5 bg-white pb-24">
        {!cats.length && <p className="text-sm text-gray-500 py-10 text-center flex flex-col items-center gap-2"><span className="text-3xl opacity-50"><E c={kd.veg ? '🍽' : '📋'}/></span> No {kd.noun}s found.</p>}
        {cats.map((c, i) => {
          const isOpen = !closed[c.name]; const lim = all[c.name] || q ? c.items.length : 4;
          return (
            <div key={c.name} id={`menu-${i}`} className="mb-5 last:mb-0 scroll-mt-32">
              <button onClick={() => setClosed({ ...closed, [c.name]: isOpen })} className="w-full flex justify-between items-center py-2 mb-1 group text-left">
                <span className="font-bold text-base md:text-lg text-gray-800 group-hover:text-brand">{c.name} <span className="text-gray-500 text-sm ml-1 font-medium">({c.items.length})</span></span>
                <span className={`text-gray-400 text-xs transition-transform ${isOpen ? 'rotate-180' : ''}`}>▼</span>
              </button>
              {isOpen && <div className="space-y-4">
                {c.items.slice(0, lim).map((it: any) => { const k = key(c.name, it.name); return (
                  <div key={k} className="flex gap-3 items-start pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <div className="mt-1"><Dot veg={it.veg} /></div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-800 text-[15px] leading-snug break-words">{it.name}</p>
                      <p className="font-bold text-gray-700 text-sm mt-1">₹{it.price}</p>
                      {it.desc && <p className="text-xs text-gray-500 mt-1 leading-relaxed line-clamp-2">{it.desc}</p>}
                      {biz.orderable && !it.image && <div className="mt-2"><Step k={k} /></div>}
                    </div>
                    {it.image && <div className="shrink-0 flex flex-col items-center gap-2"><div className="w-20 h-20 md:w-24 md:h-24 rounded-xl overflow-hidden border border-gray-100 bg-gray-50"><img src={img(it.image)} alt={it.name} loading="lazy" className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = 'none'; }} /></div>{biz.orderable && <Step k={k} />}</div>}
                  </div>); })}
                {c.items.length > lim && <button onClick={() => setAll({ ...all, [c.name]: true })} className="w-full text-center py-2 text-sm font-semibold text-brand hover:bg-blue-50 rounded-lg">View all {c.items.length} items in {c.name}</button>}
              </div>}
            </div>
          );
        })}
      </div>

      {/* category jump */}
      {!!cats.length && (
        <div className={`fixed left-1/2 -translate-x-1/2 z-30 ${count ? 'bottom-[8.5rem] md:bottom-24' : 'bottom-[5rem] md:bottom-6'}`}>
          {jump && <div className="absolute bottom-12 left-1/2 -translate-x-1/2 bg-white border border-gray-200 shadow-2xl rounded-2xl p-2 w-60 max-h-[40vh] overflow-y-auto">
            <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wider px-3 pt-1 pb-1 mb-1 border-b">Menu categories</div>
            {cats.map((c, i) => <a key={c.name} href={`#menu-${i}`} onClick={() => { setClosed({ ...closed, [c.name]: false }); setJump(false); }} className="flex justify-between items-center px-3 py-2.5 rounded-xl hover:bg-gray-100 text-sm font-medium text-gray-700"><span className="truncate">{c.name}</span><span className="text-gray-400 text-xs ml-2">{c.items.length}</span></a>)}
          </div>}
          <button onClick={() => setJump(!jump)} className="bg-gray-900 text-white rounded-full px-5 py-2.5 text-sm font-bold shadow-xl flex items-center gap-2"><span>≡</span> Menu</button>
        </div>
      )}

      {/* cart bar */}
      {biz.orderable && count > 0 && !sheet && (
        <button onClick={() => { setSheet(true); setDone(null); setErr(''); }} className="fixed z-40 inset-x-3 bottom-[4.75rem] md:inset-x-auto md:right-6 md:bottom-6 md:w-96 bg-green-600 hover:bg-green-700 text-white rounded-2xl px-4 py-3 shadow-2xl flex items-center justify-between font-bold">
          <span className="text-sm"><E c="🛒"/> {count} item{count > 1 ? 's' : ''} added</span><span className="text-sm">View cart <E c="➔"/></span>
        </button>
      )}

      {/* cart + checkout sheet */}
      {sheet && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-end md:items-center justify-center" onClick={() => setSheet(false)}>
          <div className="bg-white w-full md:max-w-md rounded-t-2xl md:rounded-2xl max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 bg-white px-4 py-3 border-b flex justify-between items-center z-10"><b>{done ? 'Order placed' : `Your list · ${biz.name}`}</b><button onClick={() => setSheet(false)} className="w-8 h-8 rounded-full bg-gray-100" aria-label="Close"><E c="✕"/></button></div>
            {done ? (
              <div className="p-6 text-center space-y-3">
                <div className="text-5xl"><E c="✅"/></div><p className="font-bold">Reference {done.orderNo}</p><p className="text-sm text-gray-600">{done.message}</p>
                {done.waUrl && <a href={done.waUrl} target="_blank" rel="noopener" className="btn bg-green-500 text-white w-full !py-3"><E c="💬"/> Open WhatsApp to send</a>}
                <button onClick={() => setSheet(false)} className="btn btn-ghost w-full">Close</button>
              </div>
            ) : (
              <form onSubmit={place} className="p-4 space-y-4">
                <div className="space-y-2">{lines.map((l) => <div key={l.k} className="flex items-center gap-2"><Dot veg={l.veg} /><div className="flex-1 min-w-0"><p className="text-sm font-medium truncate">{l.name}</p><p className="text-xs text-gray-500">{l.cat}</p></div><Step k={l.k} /></div>)}</div>
                {!lines.length && <p className="text-sm text-gray-500 text-center py-4">Your cart is empty.</p>}
                <div className="rounded-xl bg-gray-50 border p-3 text-sm"><p className="font-bold mb-1">Enquiry message</p>{lines.map((l) => <p key={l.k} className="text-gray-700">{l.name} — Quantity {l.qty}</p>)}<p className="text-[11px] text-gray-500 mt-2">Price and availability are confirmed by the {kd.who}.</p></div>
                {!!biz.min && total < biz.min && <p className="text-xs text-amber-700 bg-amber-50 rounded-lg p-2">Minimum order value is ₹{biz.min} — please add more items.</p>}
                <div className={`grid gap-2 ${kd.types.length === 1 ? 'grid-cols-1' : kd.types.length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>{kd.types.map(([v, l]) => <button type="button" key={v} onClick={() => setF({ ...f, type: v })} className={`rounded-xl border py-2 text-xs font-semibold ${f.type === v ? 'border-brand bg-blue-50 text-brand' : ''}`}>{l}</button>)}</div>
                <div className="grid grid-cols-2 gap-2"><div><label className="label">Your name *</label><input required minLength={2} maxLength={60} className="input" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
                  <div><label className="label">Mobile *</label><input required inputMode="numeric" maxLength={10} pattern="[6-9][0-9]{9}" title="10-digit mobile" className="input" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value.replace(/\D/g, '') })} /></div></div>
                {!!kd.addrType && f.type === kd.addrType && <div><label className="label">Your address *</label><textarea required minLength={8} maxLength={200} rows={2} className="input" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></div>}
                <div><label className="label">Note for the {kd.who} <span className="font-normal text-gray-400">(optional)</span></label><input maxLength={200} className="input" placeholder={kd.note} value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} /></div>
                {err && <p className="text-sm text-red-600 bg-red-50 rounded-lg p-2">{err}</p>}
                <button disabled={busy || !lines.length || (!!biz.min && total < biz.min)} className="btn bg-green-600 hover:bg-green-700 text-white w-full !py-3 disabled:opacity-50">{busy ? 'Placing order…' : biz.whatsapp ? <><E c="💬" /> {kd.cta}</> : kd.key === 'food' || kd.key === 'shopping' ? 'Place order' : 'Send request'}</button>
                <p className="text-[11px] text-gray-400 text-center">{biz.whatsapp ? `Your request is saved with the ${kd.who} and opens in WhatsApp.` : `The ${kd.who} gets your request in its dashboard and will call you.`} Payment is made directly to the {kd.who}.</p>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
