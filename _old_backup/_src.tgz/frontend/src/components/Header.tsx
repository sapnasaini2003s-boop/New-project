'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function Header() {
  const [query, setQuery] = useState('');
  const router = useRouter();

  const handleSearch = () => {
    if(query) router.push(`/search?q=${query}`);
  };

  return (
    <header className="bg-white border-b shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="text-blue-900 text-2xl md:text-3xl font-bold flex items-center">
            <span className="text-blue-600 mr-2 text-3xl">📍</span> PVRS HUB
          </Link>
          <div className="hidden md:block text-[10px] text-gray-500 font-medium">
            Udupi | Mangaluru | Our Local. Your Global.
          </div>
        </div>

        <div className="hidden lg:flex flex-1 max-w-2xl mx-8 border rounded-md overflow-hidden bg-white shadow-sm">
           <div className="px-4 py-2 bg-gray-50 border-r flex items-center text-sm text-gray-700 min-w-[120px]">
              📍 Udupi
           </div>
           <input 
             type="text" 
             value={query}
             onChange={(e) => setQuery(e.target.value)}
             onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
             placeholder="Search for businesses, products or services..." 
             className="flex-1 px-4 py-2 outline-none text-sm" 
           />
           <button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 font-medium transition">Search</button>
        </div>

        <div className="flex items-center gap-2 md:gap-4 text-sm font-medium">
          <Link href="/login" className="hidden lg:flex flex-col items-center cursor-pointer text-gray-600 hover:text-blue-600">
            <span className="text-xl">🏢</span>
            <span className="text-xs mt-1">For Businesses</span>
          </Link>
          <Link href="/login" className="flex flex-col items-center cursor-pointer text-gray-600 hover:text-blue-600">
            <span className="text-xl">👤</span>
            <span className="text-xs mt-1 hidden md:block">Login</span>
          </Link>
          <Link href="/register-business" className="bg-orange-500 hover:bg-orange-600 text-white px-2 py-1 md:px-4 md:py-2 rounded-md font-bold shadow-md transition flex flex-col items-center">
            <span>+ List Business</span>
            <span className="text-[9px] font-normal uppercase opacity-90 hidden md:block">It's Free</span>
          </Link>
        </div>
      </div>

      <nav className="bg-blue-900 text-white">
        <div className="container mx-auto px-4 hidden md:block">
          <ul className="flex items-center space-x-6 py-2 text-sm font-medium">
            <li className="bg-blue-700 px-4 py-1.5 rounded cursor-pointer hover:bg-blue-600"><Link href="/">Home</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/categories">Categories</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/offers">Offers</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/search">Featured</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/trending">Trending</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/videos">Videos</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/blogs">Blogs</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/legal">About</Link></li>
            <li className="cursor-pointer hover:text-orange-400 transition"><Link href="/contact">Contact</Link></li>
          </ul>
        </div>
      </nav>
    </header>
  );
}
