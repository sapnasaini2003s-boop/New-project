import React from 'react';
import Link from 'next/link';

export default async function BusinessDetailPage({ params }: { params: { id: string } }) {
  let biz = null;
  try {
    const res = await fetch(`http://localhost:5000/api/businesses/${params.id}`, { cache: 'no-store' });
    if (res.ok) biz = await res.json();
  } catch (err) {
    console.error(err);
  }

  if (!biz) {
    return <div className="p-8 text-center text-red-500 font-bold">Business not found.</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Main Content */}
      <main className="flex-1 pb-12">
        {/* Cover Photo */}
        <div className="w-full h-64 md:h-80 relative bg-gray-900">
          <img 
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=2000&auto=format&fit=crop" 
            alt="Cover" 
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
          
          <div className="absolute bottom-0 left-0 w-full">
            <div className="container mx-auto px-4 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="text-white">
                <div className="flex items-center gap-2 mb-2">
                  <span className="bg-blue-600 text-xs font-bold px-2 py-1 rounded text-white uppercase tracking-wider">{biz.category}</span>
                  <span className="bg-green-500 text-xs font-bold px-2 py-1 rounded text-white flex items-center gap-1">✅ Verified</span>
                  {biz.subscription?.plan === 'premium' && (
                    <span className="bg-yellow-500 text-black text-xs font-bold px-2 py-1 rounded uppercase">Premium</span>
                  )}
                </div>
                <h1 className="text-3xl md:text-5xl font-bold mb-2">{biz.name}</h1>
                <p className="text-gray-200 flex items-center gap-2 text-sm md:text-base">
                  <span>📍 {biz.location?.city}, Karnataka</span>
                  <span>•</span>
                  <span className="flex items-center text-yellow-400">⭐⭐⭐⭐⭐ <span className="text-white ml-1 font-medium">4.8 (1.2K Reviews)</span></span>
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 mt-6">
          <div className="flex flex-col lg:flex-row gap-8">
            
            {/* Left Column (Main Info) */}
            <div className="flex-1">
              {/* Action Buttons */}
              <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-wrap gap-3 mb-6">
                <button className="flex-1 min-w-[120px] bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 transition">
                  📞 Call Now
                </button>
                <button className="flex-1 min-w-[120px] bg-green-500 hover:bg-green-600 text-white font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 transition">
                  💬 WhatsApp
                </button>
                <button className="flex-1 min-w-[120px] bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 transition">
                  🗺️ Get Directions
                </button>
                <button className="flex-1 min-w-[120px] bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold py-2.5 rounded-lg flex items-center justify-center gap-2 transition">
                  🌐 Website
                </button>
              </div>

              {/* Tabs */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-6">
                <div className="flex border-b overflow-x-auto hide-scrollbar">
                  {['About', 'Services', 'Products', 'Offers', 'Reviews'].map((tab, i) => (
                    <button key={tab} className={`px-6 py-4 font-bold text-sm whitespace-nowrap ${i === 0 ? 'text-blue-600 border-b-2 border-blue-600' : 'text-gray-500 hover:bg-gray-50'}`}>
                      {tab}
                    </button>
                  ))}
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-4">About Business</h3>
                  <p className="text-gray-600 leading-relaxed mb-6">
                    Hotel Diana is a premium restaurant offering delicious food, great ambiance, and excellent service. We serve a variety of cuisines including authentic South Indian, North Indian, and Chinese. Our specialty is the Udupi Masala Dosa and Filter Coffee. 
                    <br/><br/>
                    Established in 1995, we have been serving the local community with the highest standards of hygiene and taste.
                  </p>
                  
                  <h3 className="text-xl font-bold text-gray-800 mb-4">Gallery</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[1, 2, 3, 4].map((img) => (
                      <div key={img} className="aspect-square bg-gray-200 rounded-lg overflow-hidden cursor-pointer hover:opacity-90 transition">
                        <img src={`https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=300&auto=format&fit=crop&sig=${img}`} alt="Gallery" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Reviews Section */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-gray-800">User Reviews</h3>
                  <button className="text-blue-600 font-bold text-sm hover:underline">Write a Review</button>
                </div>
                
                <div className="space-y-6">
                  {[1, 2].map((review) => (
                    <div key={review} className="border-b pb-6 last:border-0 last:pb-0">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-700 font-bold">JD</div>
                        <div>
                          <div className="font-bold text-gray-800">John Doe</div>
                          <div className="text-xs text-gray-500">2 days ago</div>
                        </div>
                      </div>
                      <div className="text-yellow-400 text-sm mb-2">⭐⭐⭐⭐⭐</div>
                      <p className="text-gray-600 text-sm">Amazing food and great service! The ambiance is perfect for family dinners. Highly recommended if you visit Udupi.</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column (Sidebar) */}
            <div className="w-full lg:w-[350px]">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 sticky top-20">
                <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">Contact Info</h3>
                
                <div className="space-y-4 mb-6">
                  <div className="flex gap-3">
                    <span className="text-blue-500 text-xl">📞</span>
                    <div>
                      <div className="text-xs text-gray-500 font-medium">Phone Number</div>
                      <div className="font-bold text-gray-800">+91 98765 43210</div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <span className="text-blue-500 text-xl">✉️</span>
                    <div>
                      <div className="text-xs text-gray-500 font-medium">Email Address</div>
                      <div className="font-bold text-gray-800">contact@hoteldiana.com</div>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <span className="text-blue-500 text-xl">📍</span>
                    <div>
                      <div className="text-xs text-gray-500 font-medium">Address</div>
                      <div className="text-sm font-medium text-gray-800">KM Marg, Near Service Bus Stand, Udupi, Karnataka 576101</div>
                    </div>
                  </div>
                </div>

                <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">Business Hours</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-gray-600">Monday</span><span className="font-medium text-green-600">Open • 8 AM - 10 PM</span></div>
                  <div className="flex justify-between"><span className="text-gray-600">Tuesday</span><span className="font-medium text-gray-800">8 AM - 10 PM</span></div>
                  <div className="flex justify-between"><span className="text-gray-600">Wednesday</span><span className="font-medium text-gray-800">8 AM - 10 PM</span></div>
                  <div className="flex justify-between"><span className="text-gray-600">Thursday</span><span className="font-medium text-gray-800">8 AM - 10 PM</span></div>
                  <div className="flex justify-between"><span className="text-gray-600">Friday</span><span className="font-medium text-gray-800">8 AM - 10 PM</span></div>
                  <div className="flex justify-between"><span className="text-gray-600">Saturday</span><span className="font-medium text-gray-800">8 AM - 11 PM</span></div>
                  <div className="flex justify-between"><span className="text-gray-600">Sunday</span><span className="font-medium text-gray-800">8 AM - 11 PM</span></div>
                </div>

                {/* Map Placeholder */}
                <div className="mt-6 w-full h-40 bg-gray-200 rounded-lg overflow-hidden relative">
                   <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?q=80&w=400&auto=format&fit=crop" className="w-full h-full object-cover opacity-60" />
                   <div className="absolute inset-0 flex items-center justify-center">
                      <button className="bg-white text-blue-600 font-bold px-4 py-2 rounded shadow-md text-sm">View on Map</button>
                   </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}
