'use client';
import React, { useState } from 'react';

export default function RegisterBusinessPage() {
  const [formData, setFormData] = useState({
    name: '', category: '', phone: '', city: 'Udupi'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('http://localhost:5000/api/businesses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      if(res.ok) {
        alert("Registration Submitted! Routed to Global Manual Review Safety Queue.");
      } else {
        alert("Failed to submit.");
      }
    } catch(err) { console.error(err); }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="bg-blue-900 p-6 text-white text-center">
          <h1 className="text-2xl font-bold">List Your Business (FREE)</h1>
          <p className="text-sm text-blue-200 mt-1">Grow your local sales today.</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 md:p-8">
          <h2 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">1. Basic Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Business Name *</label>
              <input required type="text" className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500" onChange={e => setFormData({...formData, name: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Primary Category *</label>
              <select required className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500" onChange={e => setFormData({...formData, category: e.target.value})}>
                <option value="">Select Category</option>
                <option value="Food & Dining">Food & Dining</option>
                <option value="Medical & Healthcare">Medical & Healthcare</option>
                <option value="Electronics">Electronics</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Contact Phone (Hidden on Free Plan) *</label>
              <input required type="text" maxLength={10} className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500" onChange={e => setFormData({...formData, phone: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
              <select required className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500" onChange={e => setFormData({...formData, city: e.target.value})}>
                <option value="Udupi">Udupi</option>
                <option value="Mangaluru">Mangaluru</option>
              </select>
            </div>
          </div>

          <div className="bg-orange-50 border border-orange-200 rounded p-4 mb-6">
            <h2 className="text-md font-bold text-orange-800 mb-2">2. Mandatory Verification (Anti-Switch Trick Control)</h2>
            <p className="text-xs text-orange-600 mb-4">Under Section 79 of the Indian IT Act, 2000, new signups must provide trade documents.</p>
            <div className="mb-3">
              <label className="block text-sm font-bold text-gray-700 mb-1">Upload Trade License / FSSAI / KMC Certificate *</label>
              <input type="file" required className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
            </div>
          </div>

          <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded text-lg transition">
            Submit for Manual Review
          </button>
        </form>
      </div>
    </div>
  );
}
