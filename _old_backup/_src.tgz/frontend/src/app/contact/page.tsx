import React from 'react';
import Link from 'next/link';

export default function ContactUsPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden flex flex-col md:flex-row">
          <div className="w-full md:w-1/2 bg-blue-900 p-8 text-white">
             <h2 className="text-3xl font-bold mb-4">Get In Touch</h2>
             <p className="text-blue-200 mb-8">Have any questions about listing your business? We're here to help.</p>
             
             <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <span className="text-2xl">📍</span>
                  <div>
                    <h4 className="font-bold">Our Office</h4>
                    <p className="text-sm text-blue-200">123 Main Street, Udupi, Karnataka 576101</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <span className="text-2xl">📞</span>
                  <div>
                    <h4 className="font-bold">Call Us</h4>
                    <p className="text-sm text-blue-200">+91 98765 43210</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <span className="text-2xl">✉️</span>
                  <div>
                    <h4 className="font-bold">Email Support</h4>
                    <p className="text-sm text-blue-200">support@pvrshub.com</p>
                  </div>
                </div>
             </div>
          </div>
          <div className="w-full md:w-1/2 p-8">
             <h3 className="text-2xl font-bold text-gray-800 mb-6">Send a Message</h3>
             <form className="space-y-4">
               <div>
                 <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                 <input type="text" className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500" />
               </div>
               <div>
                 <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                 <input type="email" className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500" />
               </div>
               <div>
                 <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
                 <textarea rows={4} className="w-full border border-gray-300 rounded px-3 py-2 outline-none focus:border-blue-500"></textarea>
               </div>
               <button className="w-full bg-blue-600 text-white font-bold py-3 rounded hover:bg-blue-700 transition">Send Message</button>
             </form>
          </div>
        </div>
      </div>
    </div>
  );
}
