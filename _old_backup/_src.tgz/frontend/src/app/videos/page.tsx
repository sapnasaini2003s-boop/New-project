import React from 'react';
import Link from 'next/link';

export default function VideosPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">🎥 Local Videos & Promos</h1>
        <p className="text-gray-600 mb-8">Watch exclusive video tours and promotions from our premium vendors.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-lg transition cursor-pointer group">
              <div className="h-48 bg-slate-800 relative flex items-center justify-center overflow-hidden">
                <img src={`https://images.unsplash.com/photo-1555396273-367ea4eb4db5?q=80&w=400&auto=format&fit=crop&sig=${i}`} alt="Video" className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition duration-500" />
                <div className="absolute w-12 h-12 bg-red-600 rounded-full flex items-center justify-center text-white pl-1 shadow-lg group-hover:bg-red-700 transition">
                   ▶
                </div>
                <span className="absolute bottom-2 right-2 bg-black/70 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">03:45</span>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-gray-800 line-clamp-2 mb-1">Inside Tour of The Best Seafood Restaurant in Coastal Karnataka</h3>
                <p className="text-xs text-gray-500">Sponsored by Hotel Diana • 12K Views</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
