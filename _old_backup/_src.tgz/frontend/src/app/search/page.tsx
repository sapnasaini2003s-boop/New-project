import React from 'react';
import Link from 'next/link';

export default async function SearchListingPage({ searchParams }: { searchParams: { q?: string, category?: string } }) {
  let businesses = [];
  try {
    const params = new URLSearchParams();
    if(searchParams.q) params.append('q', searchParams.q);
    if(searchParams.category) params.append('category', searchParams.category);
    
    const res = await fetch(`http://localhost:5000/api/businesses?${params.toString()}`, { cache: 'no-store' });
    if (res.ok) businesses = await res.json();
  } catch (err) {
    console.error(err);
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="container mx-auto px-4 py-6 flex flex-col md:flex-row gap-6">
        {/* Left Sidebar Filters */}
        <aside className="w-full md:w-64 bg-white p-4 rounded-xl border border-gray-200 shadow-sm h-fit sticky top-24">
          <div className="flex justify-between items-center mb-4 border-b pb-2">
            <h3 className="font-bold text-gray-800">Filters</h3>
            <span className="text-blue-600 text-xs cursor-pointer">Clear All</span>
          </div>
          
          <div className="mb-4">
            <h4 className="text-sm font-bold text-gray-700 mb-2">Location</h4>
            <select className="w-full border border-gray-300 rounded p-2 text-sm outline-none">
              <option>Udupi</option>
              <option>Mangaluru</option>
            </select>
          </div>

          <div className="mb-4">
            <h4 className="text-sm font-bold text-gray-700 mb-2">Category</h4>
            <div className="space-y-2 text-sm text-gray-600">
              <label className="flex items-center gap-2"><input type="checkbox" defaultChecked /> Food & Dining</label>
              <label className="flex items-center gap-2"><input type="checkbox" /> Hotels & Stay</label>
              <label className="flex items-center gap-2"><input type="checkbox" /> Electronics</label>
            </div>
          </div>
        </aside>

        {/* Right Side Listing */}
        <main className="flex-1">
          <div className="flex justify-between items-center mb-6 bg-white p-3 rounded-lg border border-gray-200 shadow-sm">
            <h2 className="font-bold text-gray-800">{businesses.length} Results Found</h2>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-gray-500">Sort by:</span>
              <select className="border border-gray-300 rounded p-1 outline-none">
                <option>Popularity</option>
              </select>
            </div>
          </div>

          <div className="space-y-4">
            {businesses.map((biz: any) => (
              <div key={biz._id} className="bg-white p-4 rounded-xl border border-gray-200 shadow-sm flex flex-col sm:flex-row gap-4 hover:shadow-md transition">
                <div className="w-full sm:w-48 h-32 bg-gray-200 rounded-lg overflow-hidden shrink-0 relative flex items-center justify-center text-4xl">
                  🏪
                  <span className="absolute top-2 left-2 bg-green-500 text-white text-[10px] font-bold px-2 py-0.5 rounded">Verified</span>
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <Link href={`/business/${biz._id}`}>
                         <h3 className="text-lg font-bold text-blue-900 hover:underline cursor-pointer">{biz.name}</h3>
                      </Link>
                      <span className="text-gray-400 cursor-pointer hover:text-red-500">🤍</span>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">📍 {biz.location?.city} • {biz.category}</p>
                    <p className="text-xs text-gray-600 line-clamp-2">{biz.description}</p>
                  </div>
                  {biz.subscription?.plan === 'premium' ? (
                    <div className="flex gap-2 mt-3">
                      <button className="bg-blue-50 text-blue-600 border border-blue-200 px-4 py-1.5 rounded text-sm font-bold hover:bg-blue-100 transition">📞 Call</button>
                      <button className="bg-green-50 text-green-600 border border-green-200 px-4 py-1.5 rounded text-sm font-bold hover:bg-green-100 transition">💬 WhatsApp</button>
                    </div>
                  ) : (
                    <div className="mt-3 text-xs text-gray-400">Contact hidden (Free Tier)</div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    </div>
  );
}
