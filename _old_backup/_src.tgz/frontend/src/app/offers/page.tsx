import React from 'react';

export default async function OffersPage() {
  let offers = [];
  try {
    const res = await fetch('http://localhost:5000/api/offers', { cache: 'no-store' });
    if(res.ok) offers = await res.json();
  } catch(e) { console.error(e); }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Special Offers & Discounts</h1>
        <p className="text-gray-600 mb-8">Grab the best deals from trusted local businesses around you.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {offers.map((offer: any) => (
            <div key={offer.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col hover:shadow-md transition">
              <div className={`h-40 ${offer.bg} relative flex items-center justify-center p-4 text-center`}>
                <div className="absolute inset-0 bg-black/10"></div>
                <div className="relative z-10 border-2 border-dashed border-white p-4 rounded w-full h-full flex flex-col items-center justify-center">
                  <h3 className="text-white font-black text-2xl uppercase shadow-sm">{offer.title}</h3>
                  <p className="text-orange-100 text-sm font-bold mt-1">{offer.subtitle}</p>
                </div>
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-bold text-lg text-gray-800">{offer.businessName}</h4>
                  <p className="text-xs text-gray-500 mb-3">📍 {offer.location}</p>
                  <p className="text-sm text-gray-600 mb-4">{offer.expiry}</p>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <span className="text-xs font-bold text-gray-400">Code: <span className="text-gray-800">{offer.code}</span></span>
                  <button className="bg-blue-600 text-white px-4 py-1.5 rounded text-sm font-bold hover:bg-blue-700">Get Offer</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
