import React from 'react';
import Link from 'next/link';

export default function TrendingPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">🔥 Trending Now</h1>
        <p className="text-gray-600 mb-8">The most searched and highly rated businesses this week.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
            <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition">
              <div className="h-40 bg-gray-200 relative">
                <img src={`https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=300&auto=format&fit=crop&sig=${i+10}`} alt="Trending" className="w-full h-full object-cover" />
                <span className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded shadow">#1 Trending</span>
              </div>
              <div className="p-4">
                <h3 className="font-bold text-lg text-blue-900 mb-1">City Center Mall {i}</h3>
                <p className="text-xs text-gray-500 mb-2">📍 Mangaluru • Shopping</p>
                <div className="flex items-center gap-2 mb-3">
                  <span className="bg-green-100 text-green-700 text-xs font-bold px-1.5 py-0.5 rounded">⭐ 4.9</span>
                  <span className="text-xs text-gray-500">(1.2K+ Searches)</span>
                </div>
                <Link href="/search"><button className="w-full border border-blue-600 text-blue-600 rounded py-1.5 text-sm font-bold hover:bg-blue-50">View Details</button></Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
