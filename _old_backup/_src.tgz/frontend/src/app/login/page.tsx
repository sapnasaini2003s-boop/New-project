'use client';
import React, { useState } from 'react';

export default function LoginPage() {
  const [step, setStep] = useState(1);
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);

  const requestOTP = async () => {
    if(phone.length !== 10) return alert('Enter valid 10 digit number');
    setLoading(true);
    try {
      const res = await fetch('http://localhost:5000/api/users/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone })
      });
      if(res.ok) {
        setStep(2);
        // Default mock OTP is 123456
        alert('Mock OTP sent: 123456'); 
      } else {
        alert('Failed to send OTP');
      }
    } catch(err) { console.error(err); }
    setLoading(false);
  };

  const verifyOTP = async () => {
    if(otp.length !== 6) return alert('Enter 6 digit OTP');
    setLoading(true);
    try {
      const res = await fetch('http://localhost:5000/api/users/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, otp })
      });
      const data = await res.json();
      if(res.ok) {
        alert('Login Successful!');
        localStorage.setItem('user', JSON.stringify(data.user));
        window.location.href = '/vendor/dashboard'; // Redirect to dashboard
      } else {
        alert(data.message || 'Invalid OTP');
      }
    } catch(err) { console.error(err); }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-lg border border-gray-100 p-8 w-full max-w-md">
        <div className="text-center mb-6">
          <div className="text-blue-900 text-3xl font-bold mb-2">📍 PVRS HUB</div>
          <h1 className="text-xl font-bold text-gray-800">Login / Register</h1>
          <p className="text-sm text-gray-500 mt-1">10-Digit Mobile Number OTP Authentication</p>
        </div>

        {step === 1 ? (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Mobile Number</label>
            <div className="flex mb-4">
              <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                +91
              </span>
              <input 
                type="text" 
                maxLength={10}
                className="flex-1 block w-full rounded-none rounded-r-md border border-gray-300 px-3 py-2 focus:border-blue-500 focus:ring-blue-500 sm:text-sm outline-none" 
                placeholder="Enter 10-digit number"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
              />
            </div>
            <button 
              onClick={requestOTP}
              disabled={loading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition disabled:opacity-50"
            >
              {loading ? 'Sending...' : 'Get OTP'}
            </button>
            <p className="text-xs text-center text-gray-400 mt-4">By continuing, you agree to our Terms of Use and Privacy Policy.</p>
          </div>
        ) : (
          <div>
            <p className="text-sm text-gray-600 mb-4 text-center">OTP sent to +91 {phone}</p>
            <div className="flex justify-center mb-6">
              <input 
                type="text" 
                maxLength={6} 
                placeholder="Enter 6 digit OTP"
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                className="w-full text-center tracking-widest border border-gray-300 rounded-md text-lg py-2 focus:border-blue-500 outline-none" 
              />
            </div>
            <button 
              onClick={verifyOTP}
              disabled={loading}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition disabled:opacity-50"
            >
              {loading ? 'Verifying...' : 'Verify & Login'}
            </button>
            <button 
              onClick={() => setStep(1)}
              className="w-full mt-2 bg-white text-blue-600 hover:bg-gray-50 border border-blue-600 font-bold py-2 px-4 rounded transition"
            >
              Back
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
