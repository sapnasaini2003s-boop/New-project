import React from 'react';
import Link from 'next/link';

export default async function Home() {
  let approvedBusinesses = [];
  try {
    const res = await fetch('http://localhost:5000/api/businesses', { cache: 'no-store' });
    if(res.ok) approvedBusinesses = await res.json();
  } catch(e) { console.error(e); }

  return (
    <div className="min-h-screen bg-gray-50">

      {/* 2. Top Banner Ad */}
      <div className="container mx-auto px-4 py-4">
        <Link href="/search">
          <div className="w-full h-20 md:h-24 bg-gradient-to-r from-red-900 to-red-700 rounded-lg flex items-center justify-center text-white shadow-md relative overflow-hidden cursor-pointer hover:opacity-90">
            <div className="flex items-center justify-between w-full px-8">
               <div className="flex items-center gap-4">
                  <span className="text-4xl">🏍️</span>
                  <div>
                     <h3 className="font-bold text-lg md:text-xl text-yellow-400">SRI GANESH MOTORS</h3>
                     <p className="text-xs opacity-90">Authorised Dealer - Udupi</p>
                  </div>
               </div>
               <div className="text-center hidden md:block">
                  <h2 className="text-2xl font-black italic tracking-wider text-white">RIDE THE NEW STYLE</h2>
                  <p className="text-xs uppercase tracking-widest mt-1">Wide Range | Best Offers | Easy Finance</p>
               </div>
               <button className="bg-yellow-400 text-black font-bold px-6 py-2 rounded shadow-lg text-sm">VIEW MORE</button>
            </div>
          </div>
        </Link>
      </div>

      {/* 3. Hero Section */}
      <section className="container mx-auto px-4 py-2">
        <div className="bg-blue-900 rounded-xl p-8 md:p-12 text-white relative overflow-hidden h-[400px] flex items-center bg-[url('https://images.unsplash.com/photo-1596422846543-75c6fc197f07?q=80&w=2000&auto=format&fit=crop')] bg-cover bg-center">
          <div className="absolute inset-0 bg-blue-900/80"></div>
          
          <div className="relative z-10 w-full flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="w-full md:w-3/5">
                <h1 className="text-3xl md:text-5xl font-bold mb-3 leading-tight">Find Local Businesses<br/>Near You</h1>
                <p className="text-sm md:text-base mb-8 text-blue-100 font-medium tracking-wide uppercase">Search. Connect. Grow. Udupi | Mangaluru | Beyond.</p>

                {/* Tabs */}
                <div className="flex gap-1 mb-2">
                <button className="bg-white text-blue-900 px-5 py-2.5 rounded-t-lg font-bold text-sm flex items-center gap-2"><span className="text-blue-600">🏢</span> Businesses</button>
                <button className="bg-blue-900/60 hover:bg-blue-800 text-white border border-blue-700/50 border-b-0 px-5 py-2.5 rounded-t-lg font-medium text-sm transition flex items-center gap-2"><span>🛍️</span> Products</button>
                <button className="bg-blue-900/60 hover:bg-blue-800 text-white border border-blue-700/50 border-b-0 px-5 py-2.5 rounded-t-lg font-medium text-sm transition flex items-center gap-2"><span>🛠️</span> Services</button>
                </div>

                {/* Search Box */}
                <div className="bg-white p-2 rounded-b-lg rounded-tr-lg flex flex-col md:flex-row gap-2 shadow-xl">
                <div className="flex-1 flex items-center border rounded-md px-3 py-2 bg-white hover:border-blue-400 transition">
                    <span className="text-gray-400 mr-2 text-lg">🔍</span>
                    <input type="text" placeholder="What are you looking for?" className="w-full outline-none text-gray-700 font-medium" />
                </div>
                <div className="md:w-[200px] flex items-center border rounded-md px-3 py-2 bg-white hover:border-blue-400 transition">
                    <span className="text-blue-500 mr-2">📍</span>
                    <select className="w-full outline-none text-gray-700 bg-transparent font-medium cursor-pointer">
                        <option>Udupi</option>
                        <option>Mangaluru</option>
                    </select>
                </div>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-2 rounded-md font-bold transition shadow-md">Search</button>
                </div>

                {/* Popular Searches */}
                <div className="mt-5 flex flex-wrap items-center gap-2 text-xs font-medium">
                <span className="text-blue-200 mr-2">Popular Searches:</span>
                {['Restaurant', 'Hospitals', 'Hotels', 'Salons', 'Builders', 'Car Service', 'Electronics'].map(tag => (
                    <span key={tag} className="border border-white/30 px-3 py-1 rounded-full hover:bg-white hover:text-blue-900 cursor-pointer transition">
                    {tag}
                    </span>
                ))}
                </div>
            </div>

            {/* Video Ad Space */}
            <div className="hidden md:block w-2/5">
                <div className="bg-black/40 backdrop-blur-sm border border-white/20 p-2 rounded-xl relative group cursor-pointer h-[220px]">
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition rounded-xl flex items-center justify-center">
                        <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-md">
                            <div className="w-0 h-0 border-t-[12px] border-t-transparent border-l-[20px] border-l-white border-b-[12px] border-b-transparent ml-2"></div>
                        </div>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                        <h4 className="font-bold text-lg text-white">Discover Udupi & Mangaluru</h4>
                        <p className="text-sm text-gray-200">A City of Opportunities</p>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Top Categories */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-blue-900 flex items-center gap-2">Browse Top Categories</h2>
          <Link href="/categories" className="text-blue-600 text-sm font-semibold hover:underline flex items-center gap-1">View All Categories <span className="text-lg">→</span></Link>
        </div>
        
        <div className="grid grid-cols-4 md:grid-cols-9 gap-4 md:gap-6">
          {[
            { icon: '🍴', name: 'Restaurants\n& Food', color: 'text-orange-500' },
            { icon: '🛏️', name: 'Hotels\n& Stay', color: 'text-blue-500' },
            { icon: '🏥', name: 'Health &\nHospitals', color: 'text-red-500' },
            { icon: '🎓', name: 'Education\n& Training', color: 'text-purple-500' },
            { icon: '🏠', name: 'Home &\nConstruction', color: 'text-orange-400' },
            { icon: '🚗', name: 'Automotive\n& Transport', color: 'text-blue-600' },
            { icon: '🛍️', name: 'Shopping\n& Retail', color: 'text-pink-500' },
            { icon: '💅', name: 'Beauty &\nWellness', color: 'text-green-500' },
            { icon: '➡️', name: 'More\nCategories', color: 'text-gray-500' }
          ].map((cat, i) => (
            <div key={i} className="flex flex-col items-center text-center cursor-pointer group">
              <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-white border border-gray-100 shadow-sm flex items-center justify-center text-2xl md:text-3xl mb-3 group-hover:shadow-lg group-hover:-translate-y-2 group-hover:border-blue-100 transition-all duration-300">
                <span className={cat.color}>{cat.icon}</span>
              </div>
              <span className="text-[11px] md:text-xs font-semibold text-gray-700 whitespace-pre-line leading-tight group-hover:text-blue-700 transition">{cat.name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Trust Counters */}
      <section className="container mx-auto px-4 py-4 mb-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 bg-white border border-gray-100 p-6 rounded-xl shadow-sm">
             <div className="flex flex-col items-center justify-center text-center border-r border-gray-100 last:border-0">
                 <span className="text-3xl mb-2 text-orange-500">🏪</span>
                 <h4 className="text-2xl font-bold text-gray-800">5,000+</h4>
                 <p className="text-xs text-gray-500 font-medium">Local Businesses</p>
             </div>
             <div className="flex flex-col items-center justify-center text-center border-r border-gray-100 last:border-0">
                 <span className="text-3xl mb-2 text-blue-500">👥</span>
                 <h4 className="text-2xl font-bold text-gray-800">100,000+</h4>
                 <p className="text-xs text-gray-500 font-medium">Happy Customers</p>
             </div>
             <div className="flex flex-col items-center justify-center text-center border-r border-gray-100 last:border-0">
                 <span className="text-3xl mb-2 text-green-500">✅</span>
                 <h4 className="text-2xl font-bold text-gray-800">Verified</h4>
                 <p className="text-xs text-gray-500 font-medium">Businesses</p>
             </div>
             <div className="flex flex-col items-center justify-center text-center md:border-r border-gray-100 last:border-0">
                 <span className="text-3xl mb-2 text-red-500">❤️</span>
                 <h4 className="text-2xl font-bold text-gray-800">Support</h4>
                 <p className="text-xs text-gray-500 font-medium">Local</p>
             </div>
             <div className="hidden md:flex flex-col items-center justify-center text-center bg-blue-50 rounded-lg p-2 cursor-pointer hover:bg-blue-100 transition">
                 <h4 className="font-bold text-blue-900 leading-tight">Explore Udupi & Mangaluru</h4>
                 <p className="text-xs text-blue-700 mt-1">Great Businesses. Greater People.</p>
             </div>
        </div>
      </section>

      {/* Featured Businesses */}
      <section className="container mx-auto px-4 py-6 bg-blue-50/50 rounded-2xl mb-12">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h2 className="text-2xl font-bold text-blue-900">Featured Businesses</h2>
            <p className="text-sm text-gray-500 mt-1">Handpicked businesses you can trust</p>
          </div>
          <a href="#" className="text-blue-600 text-sm font-semibold hover:underline">View All Featured →</a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {approvedBusinesses.length === 0 ? (
                <div className="col-span-4 text-center py-8 text-gray-500">No approved businesses yet. Approve some from the Admin Panel!</div>
            ) : approvedBusinesses.map((biz: any, i: number) => (
                <Link href={`/business/${biz._id}`} key={biz._id || i} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300 group cursor-pointer block">
                    <div className="h-40 bg-gray-200 relative overflow-hidden flex items-center justify-center text-4xl">
                        {/* Placeholder image */}
                        🏪
                        <div className="absolute top-3 left-3 bg-orange-500 text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm">{biz.subscription?.plan === 'premium' ? 'Premium' : 'Featured'}</div>
                    </div>
                    <div className="p-4">
                        <h3 className="font-bold text-lg text-gray-800 leading-tight truncate">{biz.name}</h3>
                        <p className="text-xs text-gray-500 mt-1">{biz.location?.city}</p>
                        <div className="flex items-center gap-2 mt-2">
                            <span className="bg-green-100 text-green-700 text-xs font-bold px-1.5 py-0.5 rounded">⭐ 4.5</span>
                            <span className="text-xs text-gray-500 font-medium truncate">{biz.category}</span>
                        </div>
                        {biz.subscription?.plan === 'premium' ? (
                          <div className="flex gap-2 mt-4">
                              <button className="flex-1 flex items-center justify-center gap-1 border border-blue-600 text-blue-600 rounded-md py-1.5 text-sm font-semibold hover:bg-blue-50 transition">📞 Call</button>
                              <button className="flex-1 flex items-center justify-center gap-1 bg-green-500 text-white rounded-md py-1.5 text-sm font-semibold hover:bg-green-600 transition shadow-sm">💬 WhatsApp</button>
                          </div>
                        ) : (
                          <div className="mt-4 text-center text-xs text-gray-400 border border-dashed border-gray-300 py-1.5 rounded-md">
                             Contact hidden (Free Plan)
                          </div>
                        )}
                    </div>
                </Link>
            ))}
        </div>
      </section>

      {/* Middle Banner Ad */}
      <section className="container mx-auto px-4 py-4 mb-8">
         <div className="w-full bg-blue-50 border border-blue-100 rounded-lg flex items-center p-6 shadow-sm overflow-hidden relative">
            <div className="flex items-center gap-6 z-10">
                <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center text-white text-3xl font-black shadow-lg">C</div>
                <div>
                    <h3 className="text-2xl font-black text-blue-900 tracking-tight">COASTAL TMT</h3>
                    <p className="text-sm font-bold text-blue-600 tracking-widest uppercase">Stronger Foundations. Brighter Tomorrow.</p>
                </div>
            </div>
            <div className="ml-auto flex gap-8 z-10 hidden md:flex text-center">
                <div><span className="text-2xl block mb-1">🏗️</span><span className="text-xs font-bold text-blue-900">High Strength</span></div>
                <div><span className="text-2xl block mb-1">⏱️</span><span className="text-xs font-bold text-blue-900">Long Life</span></div>
                <div><span className="text-2xl block mb-1">🛡️</span><span className="text-xs font-bold text-blue-900">Trusted Quality</span></div>
            </div>
            <div className="absolute right-0 top-0 bottom-0 w-1/4 bg-red-600 skew-x-12 translate-x-10 hidden md:block"></div>
         </div>
      </section>

      {/* Footer CTA */}
      <section className="container mx-auto px-4 py-8 mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white border border-blue-100 rounded-xl p-8 shadow-sm flex items-center justify-between hover:shadow-md transition">
                 <div>
                     <h3 className="text-2xl font-bold text-blue-900 mb-2">Are You a Business Owner?</h3>
                     <p className="text-gray-600 text-sm mb-6 max-w-sm">List your business, get more customers and grow with PVRS HUB.</p>
                     <button className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 px-6 rounded-md shadow transition">List Your Business - It's Free!</button>
                 </div>
                 <div className="text-6xl hidden sm:block">🏪</div>
              </div>
              <div className="bg-orange-50 border border-orange-100 rounded-xl p-8 shadow-sm flex items-center justify-between hover:shadow-md transition">
                 <div>
                     <h3 className="text-2xl font-bold text-orange-700 mb-2">Advertise with PVRS HUB</h3>
                     <p className="text-gray-600 text-sm mb-6 max-w-sm">Reach thousands of local customers through banners, featured listings and video ads.</p>
                     <button className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2.5 px-6 rounded-md shadow transition">Explore Advertising Options</button>
                 </div>
                 <div className="text-6xl hidden sm:block">📢</div>
              </div>
          </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0f172a] text-gray-300 pt-12 pb-6 border-t-4 border-blue-600">
          <div className="container mx-auto px-4">
              <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-6 border-b border-gray-800 pb-8">
                  <div className="flex items-center gap-2">
                    <div className="text-white text-2xl font-bold flex items-center">
                        <span className="text-blue-500 mr-2 text-3xl">📍</span> PVRS HUB
                    </div>
                  </div>
                  <div className="flex flex-wrap justify-center gap-4 md:gap-8 text-sm font-medium">
                      <a href="#" className="hover:text-white transition">About</a>
                      <a href="#" className="hover:text-white transition">Contact</a>
                      <a href="#" className="hover:text-white transition">Privacy Policy</a>
                      <a href="#" className="hover:text-white transition">Terms & Conditions</a>
                      <a href="#" className="hover:text-white transition">Business Listing Policy</a>
                      <a href="#" className="hover:text-white transition">Help</a>
                  </div>
                  <div className="flex items-center gap-4">
                      <span className="text-sm font-semibold">Follow Us</span>
                      <div className="flex gap-2">
                          <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-600 cursor-pointer transition">fb</div>
                          <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-pink-600 cursor-pointer transition">ig</div>
                          <div className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-600 cursor-pointer transition">yt</div>
                      </div>
                  </div>
              </div>
              <div className="flex flex-col md:flex-row justify-between items-center text-xs text-gray-500">
                  <p>© 2026 PVRS HUB. All Rights Reserved. | Made for Our Local Community ❤️</p>
                  <div className="flex gap-2 mt-4 md:mt-0">
                      <button className="bg-black border border-gray-700 rounded px-3 py-1 text-white flex items-center gap-2 hover:bg-gray-900">
                          <span className="text-lg">🤖</span> Get it on Google Play
                      </button>
                      <button className="bg-black border border-gray-700 rounded px-3 py-1 text-white flex items-center gap-2 hover:bg-gray-900">
                          <span className="text-lg">🍎</span> Download on the App Store
                      </button>
                  </div>
              </div>
          </div>
      </footer>
    </div>
  );
}
