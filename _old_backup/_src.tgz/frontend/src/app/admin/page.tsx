'use client';
import React, { useEffect, useState } from 'react';
import Link from 'next/link';

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('overview');
  const [pending, setPending] = useState<any[]>([]);
  const [allBusinesses, setAllBusinesses] = useState<any[]>([]);
  const [pendingUsers, setPendingUsers] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [pendingRes, allRes, pendingUsersRes, allUsersRes] = await Promise.all([
        fetch('http://localhost:5000/api/businesses/pending'),
        fetch('http://localhost:5000/api/businesses'),
        fetch('http://localhost:5000/api/users/pending'),
        fetch('http://localhost:5000/api/users')
      ]);
      if (pendingRes.ok) setPending(await pendingRes.json());
      if (allRes.ok) setAllBusinesses(await allRes.json());
      if (pendingUsersRes.ok) setPendingUsers(await pendingUsersRes.json());
      if (allUsersRes.ok) setAllUsers(await allUsersRes.json());
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAction = async (id: string, action: 'approve' | 'reject') => {
    try {
      const res = await fetch(`http://localhost:5000/api/businesses/${action}/${id}`, { method: 'PUT' });
      if (res.ok) { alert(`Business ${action}d successfully`); fetchData(); }
    } catch (err) { console.error(err); }
  };

  const handleUserAction = async (id: string) => {
    try {
      const res = await fetch(`http://localhost:5000/api/users/approve/${id}`, { method: 'PUT' });
      if (res.ok) { alert('User approved successfully'); fetchData(); }
    } catch (err) { console.error(err); }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col md:flex-row font-sans">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-slate-900 text-white min-h-screen flex flex-col shadow-2xl">
        <div className="p-6 border-b border-slate-800">
          <h2 className="text-2xl font-black tracking-wider text-blue-400">ADMIN PRO</h2>
          <p className="text-xs text-slate-400 mt-1">Global Command Center</p>
        </div>
        <nav className="flex-1 px-4 py-6 space-y-2">
          <button onClick={() => setActiveTab('overview')} className={`w-full text-left px-4 py-3 rounded-lg font-medium transition ${activeTab === 'overview' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>📊 Overview & Revenue</button>
          
          <button onClick={() => setActiveTab('users')} className={`w-full text-left px-4 py-3 rounded-lg font-medium transition flex justify-between items-center ${activeTab === 'users' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>
            <span>👥 User Management</span>
            {pendingUsers.length > 0 && <span className="bg-orange-500 text-white text-xs px-2 py-0.5 rounded-full">{pendingUsers.length}</span>}
          </button>

          <button onClick={() => setActiveTab('queue')} className={`w-full text-left px-4 py-3 rounded-lg font-medium transition flex justify-between items-center ${activeTab === 'queue' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>
            <span>🛡️ Business Queue</span>
            {pending.length > 0 && <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{pending.length}</span>}
          </button>
          
          <button onClick={() => setActiveTab('subscriptions')} className={`w-full text-left px-4 py-3 rounded-lg font-medium transition ${activeTab === 'subscriptions' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>💳 Subscriptions & Trending</button>
          <button onClick={() => setActiveTab('blogs')} className={`w-full text-left px-4 py-3 rounded-lg font-medium transition ${activeTab === 'blogs' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:bg-slate-800'}`}>📝 Blog Manager</button>
        </nav>
        <div className="p-4 border-t border-slate-800">
          <Link href="/" className="block text-center text-sm text-slate-400 hover:text-white">← Back to Website</Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto h-screen">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-slate-800">
            {activeTab === 'overview' && 'Revenue & Analytics'}
            {activeTab === 'queue' && 'Global Manual Review Queue'}
            {activeTab === 'subscriptions' && 'Plan & Trending Management'}
            {activeTab === 'blogs' && 'Content & Blog Manager'}
          </h1>
          <button onClick={fetchData} className="bg-white border border-slate-300 text-slate-700 px-4 py-2 rounded-lg font-medium shadow-sm hover:bg-slate-50 transition">🔄 Refresh Data</button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center h-64"><div className="text-xl font-bold text-slate-400 animate-pulse">Loading System Data...</div></div>
        ) : (
          <>
            {/* TAB: OVERVIEW */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-green-500">
                    <p className="text-sm font-bold text-slate-500 mb-1">Total Revenue (Razorpay)</p>
                    <h3 className="text-3xl font-black text-slate-800">₹ 84,500</h3>
                    <p className="text-xs text-green-600 mt-2 flex items-center gap-1">↑ 12% from last month</p>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-blue-500">
                    <p className="text-sm font-bold text-slate-500 mb-1">Premium Vendors</p>
                    <h3 className="text-3xl font-black text-slate-800">142</h3>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-orange-500">
                    <p className="text-sm font-bold text-slate-500 mb-1">Free Tier Listings</p>
                    <h3 className="text-3xl font-black text-slate-800">890</h3>
                  </div>
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 border-l-4 border-l-red-500">
                    <p className="text-sm font-bold text-slate-500 mb-1">Action Required</p>
                    <h3 className="text-3xl font-black text-slate-800">{pending.length}</h3>
                    <p className="text-xs text-red-600 mt-2">Pending in queue</p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB: USER MANAGEMENT */}
            {activeTab === 'users' && (
              <div className="space-y-6">
                {/* Pending Users */}
                {pendingUsers.length > 0 && (
                  <div className="bg-orange-50 border border-orange-200 rounded-2xl p-6">
                    <h2 className="text-xl font-bold text-orange-900 mb-4">Pending User Approvals (Vendor Signups)</h2>
                    <div className="space-y-4">
                      {pendingUsers.map(user => (
                        <div key={user.id} className="bg-white p-4 rounded-xl border border-orange-100 flex justify-between items-center shadow-sm">
                          <div>
                            <h4 className="font-bold text-slate-800">{user.name || 'Vendor'}</h4>
                            <p className="text-sm text-slate-600">📞 +91 {user.phone}</p>
                          </div>
                          <button onClick={() => handleUserAction(user.id)} className="bg-green-500 text-white font-bold px-4 py-2 rounded-lg hover:bg-green-600">Approve User</button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* All Users */}
                <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
                  <h2 className="text-xl font-bold text-slate-800 mb-6">All Registered Users</h2>
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200">
                        <th className="p-4 text-xs font-bold text-slate-500 uppercase">Name</th>
                        <th className="p-4 text-xs font-bold text-slate-500 uppercase">Phone</th>
                        <th className="p-4 text-xs font-bold text-slate-500 uppercase">Role</th>
                        <th className="p-4 text-xs font-bold text-slate-500 uppercase">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {allUsers.map(user => (
                        <tr key={user.id} className="border-b border-slate-100 hover:bg-slate-50">
                          <td className="p-4 font-medium text-slate-800">{user.name || 'N/A'}</td>
                          <td className="p-4 text-slate-600">+91 {user.phone}</td>
                          <td className="p-4 text-slate-600 capitalize">{user.role}</td>
                          <td className="p-4">
                            {user.isApproved 
                              ? <span className="bg-green-100 text-green-700 text-xs font-bold px-2 py-1 rounded">Approved</span>
                              : <span className="bg-orange-100 text-orange-700 text-xs font-bold px-2 py-1 rounded">Pending</span>
                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB: REVIEW QUEUE (ANTI-SWITCH & DOC VERIFICATION) */}
            {activeTab === 'queue' && (
              <div className="space-y-6">
                {pending.length === 0 ? (
                  <div className="bg-green-50 border border-green-200 p-8 rounded-2xl text-center">
                    <span className="text-4xl block mb-2">🎉</span>
                    <h3 className="text-xl font-bold text-green-800">Inbox Zero!</h3>
                    <p className="text-green-600">All vendors and profile edits have been reviewed.</p>
                  </div>
                ) : (
                  pending.map(biz => (
                    <div key={biz._id} className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden flex flex-col md:flex-row">
                      {/* Left: Document Viewer */}
                      <div className="w-full md:w-1/3 bg-slate-50 p-6 border-r border-slate-200 flex flex-col">
                        <h4 className="font-bold text-slate-800 mb-4 flex items-center gap-2">📄 FSSAI / Trade License</h4>
                        <div className="flex-1 bg-slate-200 rounded-lg flex flex-col items-center justify-center border-2 border-dashed border-slate-300 p-4">
                           <span className="text-4xl mb-2">📋</span>
                           <span className="text-xs font-bold text-slate-500 text-center">document_upload_v1.pdf<br/>(Mock Preview)</span>
                           <button className="mt-4 bg-blue-100 text-blue-700 px-4 py-2 rounded text-xs font-bold">View Full Document</button>
                        </div>
                      </div>

                      {/* Right: Data & Compare */}
                      <div className="w-full md:w-2/3 p-6 flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider mb-2 inline-block ${biz.pendingUpdates ? 'bg-orange-100 text-orange-800' : 'bg-blue-100 text-blue-800'}`}>
                                {biz.pendingUpdates ? 'Profile Edit Request (Anti-Switch Trick)' : 'New Business Signup'}
                              </span>
                              <h3 className="text-2xl font-black text-slate-800">{biz.name}</h3>
                              <p className="text-sm text-slate-500">📍 {biz.location?.city} • {biz.category}</p>
                            </div>
                            <span className="text-xs font-mono text-slate-400">ID: {biz._id}</span>
                          </div>

                          {/* Anti-Switch Compare Tool */}
                          {biz.pendingUpdates && (
                            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
                              <h4 className="text-xs font-bold text-orange-800 uppercase tracking-wider mb-3">Data Comparison Engine</h4>
                              <div className="grid grid-cols-2 gap-4">
                                <div className="bg-white p-3 rounded border border-red-100">
                                  <p className="text-[10px] font-bold text-red-500 mb-1">OLD DATA (Currently Live)</p>
                                  <p className="text-sm font-medium">{biz.contact?.phone}</p>
                                  <p className="text-sm text-slate-600">{biz.category}</p>
                                </div>
                                <div className="bg-white p-3 rounded border border-green-100 relative">
                                  <span className="absolute -left-3 top-1/2 -translate-y-1/2 bg-white rounded-full text-slate-400">➔</span>
                                  <p className="text-[10px] font-bold text-green-600 mb-1">NEW DATA (Requested)</p>
                                  <p className="text-sm font-medium">{biz.pendingUpdates.contact?.phone || biz.contact?.phone}</p>
                                  <p className="text-sm text-slate-600">{biz.pendingUpdates.category || biz.category}</p>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex gap-3 mt-6 pt-4 border-t border-slate-100">
                          <button onClick={() => handleAction(biz._id, 'approve')} className="flex-1 bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg transition shadow-sm flex items-center justify-center gap-2">✅ Approve & Publish</button>
                          <button onClick={() => handleAction(biz._id, 'reject')} className="flex-1 bg-red-50 hover:bg-red-100 text-red-600 font-bold py-3 rounded-lg transition border border-red-200">❌ Reject</button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB: SUBSCRIPTIONS */}
            {activeTab === 'subscriptions' && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase">Business Name</th>
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase">Category</th>
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase">Current Plan</th>
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase">License Expiry</th>
                      <th className="p-4 text-xs font-bold text-slate-500 uppercase text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allBusinesses.map((biz, idx) => {
                      const isExpiring = idx % 3 === 0; // Mock logic for demo
                      return (
                        <tr key={biz._id} className="border-b border-slate-100 hover:bg-slate-50 transition">
                          <td className="p-4 font-bold text-slate-800">{biz.name}</td>
                          <td className="p-4 text-sm text-slate-600">{biz.category}</td>
                          <td className="p-4">
                            {biz.subscription?.plan === 'premium' 
                              ? <span className="bg-yellow-100 text-yellow-800 text-xs font-bold px-2 py-1 rounded">PREMIUM</span>
                              : <span className="bg-slate-100 text-slate-600 text-xs font-bold px-2 py-1 rounded">FREE TIER</span>
                            }
                          </td>
                          <td className="p-4">
                            {isExpiring ? (
                              <div className="flex items-center gap-2 text-red-600 text-sm font-bold">
                                <span>⚠️ Expiring in 5 days</span>
                              </div>
                            ) : (
                              <span className="text-sm text-slate-500">24 Oct 2027</span>
                            )}
                          </td>
                          <td className="p-4 text-right">
                            <button className="text-orange-500 text-sm font-bold hover:underline mr-4">⭐ Mark Trending</button>
                            <button className="text-blue-600 text-sm font-bold hover:underline">Manage</button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* TAB: CONTENT & BLOGS */}
            {activeTab === 'blogs' && (
              <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8">
                 <h2 className="text-xl font-bold text-slate-800 mb-6">Create New Blog Post</h2>
                 <form className="space-y-6">
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Article Title</label>
                      <input type="text" className="w-full border border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500" placeholder="e.g. Top 10 Restaurants in Udupi" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Category / Tag</label>
                      <select className="w-full border border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500">
                        <option>Travel Guide</option>
                        <option>Food & Dining</option>
                        <option>Local News</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Content</label>
                      <textarea rows={6} className="w-full border border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500" placeholder="Write your article here..."></textarea>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-700 mb-2">Cover Image URL</label>
                      <input type="text" className="w-full border border-slate-300 rounded-lg p-3 outline-none focus:border-blue-500" placeholder="https://unsplash.com/..." />
                    </div>
                    <button type="button" className="bg-blue-600 text-white font-bold px-8 py-3 rounded-lg hover:bg-blue-700 transition">Publish Blog</button>
                 </form>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
