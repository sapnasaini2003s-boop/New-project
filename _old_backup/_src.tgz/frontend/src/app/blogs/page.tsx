import React from 'react';
import Link from 'next/link';

export default function BlogsPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">📰 Blogs & Articles</h1>
        <p className="text-gray-600 mb-8">Discover local guides, tips, and updates from the community.</p>

        <div className="space-y-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6 hover:shadow-md transition">
              <div className="w-full md:w-64 h-40 bg-gray-200 rounded-lg overflow-hidden shrink-0">
                <img src={`https://images.unsplash.com/photo-1476224203421-9ac39bcb3327?q=80&w=400&auto=format&fit=crop&sig=${i}`} alt="Blog" className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 flex flex-col justify-center">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2 py-1 rounded">Travel Guide</span>
                  <span className="text-xs text-gray-400">Oct 12, 2026</span>
                </div>
                <h2 className="text-xl font-bold text-gray-800 mb-2 hover:text-blue-600 cursor-pointer">Top 10 Hidden Beaches to Visit Around Udupi this Summer</h2>
                <p className="text-sm text-gray-600 mb-4 line-clamp-2">Coastal Karnataka is home to some of the most pristine and untouched beaches. In this guide, we explore the secret spots that tourists usually miss...</p>
                <div>
                   <button className="text-sm font-bold text-blue-600 hover:underline">Read Full Article →</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
