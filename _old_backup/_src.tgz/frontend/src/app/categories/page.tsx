import React from 'react';

export default function CategoriesPage() {
  const categories = [
    { name: 'Food & Dining', subs: ['Pure Veg Restaurants', 'Non-Veg Dhabas', 'Cafes', 'Biryani Houses', 'Ice Cream Parlours', 'Home Kitchens & Home-Cooked Food Deliveries'], icon: '🍴' },
    { name: 'Property & Rentals', subs: ['Rent Houses', 'Student PGs & Hostels', 'Flats & Apartments for Lease', 'Commercial Shops', 'Real Estate Brokers'], icon: '🏢' },
    { name: 'Daily Needs & Utilities', subs: ['Electricians', 'Plumbers', 'Laundry & Dry Cleaning', 'AC Repair', 'Carpenters', 'Pest Control', 'Appliance Technicians', 'Packers & Movers'], icon: '🛠️' },
    { name: 'Medical & Healthcare', subs: ['General Physicians', 'Dentists', '24/7 Pharmacies', 'Diagnostic Labs', 'Ayurvedic Clinics', 'Local Home Nursing Care'], icon: '🏥' },
    { name: 'Travel & Logistics', subs: ['Car Rentals', 'Two-Wheeler/Scooter Rentals', 'Auto-Rickshaw Call Links', 'Local Taxi Services', 'Garages', 'Towing Services'], icon: '🚗' },
    { name: 'Weddings & Local Events', subs: ['Kalyana Mantapas (Wedding Halls)', 'Event Decorators', 'Local Photographers', 'DJ Sound Providers', 'Outdoor Caterers'], icon: '🎉' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="container mx-auto">
        <h1 className="text-3xl font-bold text-blue-900 mb-2">All Categories</h1>
        <p className="text-gray-600 mb-8">Browse local businesses in Coastal Karnataka by category.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((cat, i) => (
            <div key={i} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition">
              <div className="flex items-center gap-3 mb-4 border-b pb-4">
                <span className="text-3xl">{cat.icon}</span>
                <h2 className="text-xl font-bold text-gray-800">{cat.name}</h2>
              </div>
              <ul className="space-y-2">
                {cat.subs.map((sub, j) => (
                  <li key={j} className="text-sm text-gray-600 hover:text-blue-600 cursor-pointer flex items-center gap-2">
                    <span className="text-blue-400 text-xs">➤</span> {sub}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
