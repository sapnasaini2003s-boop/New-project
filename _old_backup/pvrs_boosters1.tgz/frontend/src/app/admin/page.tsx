﻿'use client';
import { BoostersAdmin, OfferCard, PartnerAdmin } from '@/components/AdminGrowth';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { LineChart, BarList, Donut, Spark, SERIES } from '@/components/Charts';
import { api, img, privateFile, useFetch, useUser, logout, API, getToken, loadConfig } from '@/lib/api';

/* ─── Business Detail Modal ─── */
function ViewBusiness({ b, onClose }: { b: any; onClose: () => void }) {
  if (!b) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center p-4 overflow-y-auto" onClick={onClose}>
      <div className="bg-white rounded-3xl w-full max-w-3xl my-8 shadow-2xl overflow-hidden animate-in" onClick={(e) => e.stopPropagation()}>
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white p-6 relative">
          <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition">✕</button>
          <div className="flex gap-4 items-start">
            <div className="w-20 h-20 rounded-2xl bg-white/10 overflow-hidden flex items-center justify-center shrink-0 shadow-lg">
              {(b.profileImage || b.image) ? <img src={img(b.profileImage || b.image)} alt="" className="w-full h-full object-cover" /> : <span className="text-4xl">🏪</span>}
            </div>
            <div>
              <h2 className="text-2xl font-black">{b.name}</h2>
              <p className="text-slate-300 text-sm mt-1">{b.category} › {b.subCategory}</p>
              <div className="flex gap-2 mt-2 flex-wrap">
                {b.plan === 'premium' && <span className="bg-amber-400 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-full">⭐ PREMIUM</span>}
                {b.verified && <span className="bg-emerald-400 text-emerald-900 text-[10px] font-bold px-2 py-0.5 rounded-full">✔ VERIFIED</span>}
                {b.badge && <span className="bg-blue-400 text-blue-900 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">{b.badge}</span>}
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${b.status === 'approved' ? 'bg-emerald-400 text-emerald-900' : b.status === 'pending' ? 'bg-amber-400 text-amber-900' : 'bg-red-400 text-red-900'}`}>{b.status?.toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[['⭐ Rating', b.rating ? Number(b.rating).toFixed(1) : 'N/A'], ['💬 Reviews', b.reviews || 0], ['👁 Views', b.views || 0], ['📞 Leads', b.leads || 0]].map(([label, val]) => (
              <div key={label} className="bg-slate-50 rounded-xl p-3 text-center">
                <p className="text-[11px] text-slate-400 font-medium">{label}</p>
                <p className="text-xl font-black text-slate-800 mt-0.5">{val}</p>
              </div>
            ))}
          </div>

          {/* Info Grid */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">📍 Location & Contact</h3>
              <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                <p><span className="text-slate-400 font-medium">City:</span> <span className="text-slate-700 font-semibold">{b.city || '—'}</span></p>
                <p><span className="text-slate-400 font-medium">Address:</span> <span className="text-slate-700">{b.address || '—'}</span></p>
                <p><span className="text-slate-400 font-medium">Phone:</span> <span className="text-slate-700 font-mono">{b.contact?.phone || '—'}</span></p>
                <p><span className="text-slate-400 font-medium">WhatsApp:</span> <span className="text-slate-700 font-mono">{b.contact?.whatsapp || '—'}</span></p>
                {b.timings && <p><span className="text-slate-400 font-medium">Timings:</span> <span className="text-slate-700">{b.timings}</span></p>}
              </div>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">💼 Plan & Subscription</h3>
              <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                <p><span className="text-slate-400 font-medium">Plan:</span> <span className={`font-bold ${b.plan === 'premium' ? 'text-amber-600' : 'text-slate-600'}`}>{b.plan?.toUpperCase()}</span></p>
                {b.planExpiry && <p><span className="text-slate-400 font-medium">Expiry:</span> <span className="text-slate-700">{new Date(b.planExpiry).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</span></p>}
                <p><span className="text-slate-400 font-medium">Unclaimed:</span> <span className="text-slate-700">{b.unclaimed ? 'Yes ⚠️' : 'No'}</span></p>
                {b.owner && <p><span className="text-slate-400 font-medium">Owner:</span> <span className="text-slate-700">{b.owner.name || '—'} (+91 {b.owner.phone})</span></p>}
                <p><span className="text-slate-400 font-medium">Created:</span> <span className="text-slate-700">{b.createdAt ? new Date(b.createdAt).toLocaleDateString('en-IN') : '—'}</span></p>
              </div>
            </div>
          </div>

          {/* Documents */}
          {b.documents && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">📄 Compliance Documents</h3>
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm space-y-1">
                <p><span className="text-amber-600 font-medium">Type:</span> <span className="text-amber-900 font-semibold">{b.documents.type}</span></p>
                <p><span className="text-amber-600 font-medium">Number:</span> <span className="text-amber-900 font-mono">{b.documents.number || '—'}</span></p>
                <p><span className="text-amber-600 font-medium">Expiry:</span> <span className="text-amber-900">{b.documents.expiry || '—'}</span></p>
                {b.documents.file && <a href={privateFile(b.documents.file)} target="_blank" className="inline-block mt-2 bg-amber-100 hover:bg-amber-200 text-amber-800 px-4 py-2 rounded-lg text-xs font-bold transition">📎 View Document File</a>}
              </div>
            </div>
          )}

          {/* Description */}
          {b.description && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">📝 Description</h3>
              <p className="bg-slate-50 rounded-xl p-4 text-sm text-slate-600 whitespace-pre-line leading-relaxed">{b.description}</p>
            </div>
          )}

          {/* Order Online Links */}
          {b.orderOnline && Object.values(b.orderOnline).some(Boolean) && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">🛵 Order Online Links</h3>
              <div className="flex gap-2">
                {b.orderOnline.swiggy && <a href={b.orderOnline.swiggy} target="_blank" className="bg-orange-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Swiggy →</a>}
                {b.orderOnline.zomato && <a href={b.orderOnline.zomato} target="_blank" className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Zomato →</a>}
              </div>
            </div>
          )}

          {/* Pending Updates */}
          {b.pendingUpdates && Object.keys(b.pendingUpdates).length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-amber-700 uppercase tracking-wider">⚠️ Pending Edit Request</h3>
              <div className="bg-amber-50 border border-amber-200 rounded-xl overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-amber-100"><tr><th className="p-2.5 text-left text-amber-800">Field</th><th className="text-left text-amber-800">Current</th><th className="text-left text-amber-800">Requested</th></tr></thead>
                  <tbody>{Object.entries(b.pendingUpdates).map(([k, v]: any) => (
                    <tr key={k} className="border-t border-amber-200"><td className="p-2.5 font-semibold text-amber-900">{k}</td><td className="text-amber-700 p-2.5">{b[k] != null ? String(b[k]) : '—'}</td><td className="text-amber-900 font-medium p-2.5">{String(v)}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 flex justify-between items-center border-t border-slate-100">
          <p className="text-[11px] text-slate-400">ID: {b._id}</p>
          <div className="flex gap-2">
            <Link href={`/business/${b._id}`} target="_blank" className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-100 transition">🌐 View Public Page</Link>
            <button onClick={onClose} className="bg-slate-200 text-slate-700 px-5 py-2 rounded-xl text-xs font-bold hover:bg-slate-300 transition">Close</button>
          </div>
        </div>
      </div>
    </div>
  );
}

const TABS = [
  ['overview', '🏠', 'Dashboard', 'Main'],
  ['analytics', '📈', 'Analytics', 'Main'],
  ['queue', '🛡️', 'Approval Queue', 'Moderation'],
  ['enquiries', '📨', 'Enquiries & Reviews', 'Moderation'],
  ['businesses', '🏪', 'Businesses', 'Directory'],
  ['categories', '📂', 'Categories', 'Directory'],
  ['users', '👥', 'Users', 'Directory'],
  ['ads', '📢', 'Ads & Banners', 'Marketing'],
  ['boosters', '🚀', 'Biz Boosters & Leads', 'Marketing'],
  ['partner', '🤝', 'Partner Programme', 'Marketing'],
  ['content', '📝', 'Offers / Blogs / Videos', 'Marketing'],
  ['payments', '💳', 'Payments', 'Marketing'],
  ['settings', '🎨', 'Homepage Settings', 'Website'],
  ['legal', '⚖️', 'Legal Pages', 'Website'],
  ['features', '🎛️', 'Feature Controls', 'Website'],
  ['team', '🧑‍💼', 'Team & Admins', 'System'],
  ['system', '🖥️', 'System & Migrations', 'System'],
  ['logs', '🔔', 'Notifications & Logs', 'System'],
];
const MOD_TABS = ['overview', 'queue', 'enquiries'];

const Badge = ({ s }: { s: string }) => (
  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full inline-flex items-center gap-1 ${
    ({ pending: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200', approved: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200', rejected: 'bg-red-50 text-red-700 ring-1 ring-red-200', suspended: 'bg-slate-100 text-slate-600 ring-1 ring-slate-200', expired: 'bg-slate-100 text-slate-500', paid: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200', premium: 'bg-blue-50 text-blue-700 ring-1 ring-blue-200', blocked: 'bg-red-50 text-red-700 ring-1 ring-red-200' } as any)[s] || 'bg-slate-100 text-slate-600'
  }`}>
    <span className={`w-1.5 h-1.5 rounded-full ${
      ({ pending: 'bg-amber-500', approved: 'bg-emerald-500', rejected: 'bg-red-500', suspended: 'bg-slate-400', paid: 'bg-emerald-500', premium: 'bg-blue-500', blocked: 'bg-red-500' } as any)[s] || 'bg-slate-400'
    }`} />
    {s}
  </span>
);

export default function Admin() {
  const { user, ready } = useUser(); const router = useRouter();
  const [tab, setTab] = useState('overview'); const [nav, setNav] = useState(false);
  const queue = useFetch<any>(['admin', 'moderator'].includes(user?.role) ? '/admin/queue' : null);
  useEffect(() => { if (ready && !user) router.replace('/admin/login'); }, [ready, user, router]);
  if (!user || !['admin', 'moderator'].includes(user.role)) return (
    <div className="p-10 text-center space-y-3 min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex flex-col items-center justify-center">
      <div className="bg-white rounded-2xl max-w-sm w-full p-8 shadow-2xl">
        <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4"><span className="text-3xl">🔒</span></div>
        <h2 className="text-xl font-black text-slate-800 mb-2">Access Denied</h2>
        <p className="text-sm text-gray-500 mb-6">{user ? `Logged in as +91 ${user.phone} (${user.role}). Admin access required.` : 'Please log in to continue.'}</p>
        <button onClick={() => { logout(); router.push('/admin/login'); }} className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold py-3 rounded-xl hover:shadow-lg transition">Go to Admin Login</button>
      </div>
    </div>
  );
  const c = queue.data?.counts || {}; const total = Object.values(c).reduce((a: any, b: any) => a + b, 0) as number;
  const currentTab = TABS.find((t) => t[0] === tab);

  return (
    <div className="min-h-screen flex bg-[#fafafa]">
      {/* Sidebar */}
      {nav && <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={() => setNav(false)} />}
      <aside className={`${nav ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 fixed md:static inset-y-0 left-0 z-40 w-[260px] bg-gradient-to-b from-[#0f172a] to-[#1e293b] text-slate-300 flex flex-col transition-transform duration-200`}>
        <div className="p-5 pb-2">
          <div className="flex items-center gap-2.5 mb-1">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center text-white font-black text-sm shadow-lg shadow-blue-500/30">P</div>
            <div><span className="text-lg font-black text-white tracking-wide">PVRS</span> <span className="text-lg font-black text-blue-400">HUB</span></div>
          </div>
          <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-semibold ml-[46px] -mt-1">Admin Console</p>
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5">
          {TABS.filter(([k]) => user.role === 'admin' || MOD_TABS.includes(k)).map(([k, icon, label, group], i, arr) => (
            <div key={k}>{(i === 0 || arr[i - 1][3] !== group) && <p className="px-3 pt-4 pb-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-slate-500">{group}</p>}
            <button onClick={() => { setTab(k); setNav(false); }}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-[13px] font-medium flex items-center gap-3 transition-all duration-150 ${
                tab === k
                  ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-600/30'
                  : 'hover:bg-white/5 text-slate-400 hover:text-white'
              }`}>
              <span className="text-base w-6 text-center">{icon}</span>
              <span className="flex-1">{label}</span>
              {k === 'queue' && total > 0 && <span className="bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">{total}</span>}
            </button></div>
          ))}
        </div>
        <div className="p-4 border-t border-white/10 space-y-1">
          <Link href="/" className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition px-2 py-1.5 rounded-lg hover:bg-white/5">
            <span>←</span> <span>View Website</span>
          </Link>
          <button onClick={() => { logout(); router.push('/'); }} className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 transition px-2 py-1.5 rounded-lg hover:bg-red-500/10 w-full">
            <span>⏻</span> <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0">
        {/* Top bar */}
        <header className="bg-white/80 backdrop-blur-md border-b border-slate-200/50 px-6 md:px-10 py-5 flex items-center gap-5 sticky top-0 z-20 shadow-[0_4px_20px_-10px_rgba(0,0,0,0.05)]">
          <button className="md:hidden w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition" onClick={() => setNav(true)}>
            <span className="text-lg">☰</span>
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <span className="text-xl">{currentTab?.[1]}</span> {currentTab?.[2]}
            </h1>
            <p className="text-xs text-slate-400 hidden md:block">Welcome back, Admin • {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
          </div>
          <div className="flex items-center gap-3">
            {total > 0 && <button onClick={() => setTab('queue')} className="relative bg-red-50 text-red-600 px-3 py-2 rounded-xl text-xs font-bold hover:bg-red-100 transition">
              🔔 {total} Pending
            </button>}
            <div className="w-9 h-9 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center text-white text-sm font-bold">A</div>
          </div>
        </header>

        <div className="p-4 md:p-8">
          {tab === 'overview' && <Dashboard go={setTab} role={user.role} />}
          {tab === 'analytics' && <Overview />}
          {tab === 'team' && <Team />}
          {tab === 'system' && <System />}
          {tab === 'queue' && <Queue q={queue} />}
          {tab === 'businesses' && <Businesses />}
          {tab === 'users' && <Users />}
          {tab === 'ads' && <Ads />}
          {tab === 'boosters' && <BoostersAdmin />}
          {tab === 'partner' && <PartnerAdmin />}
          {tab === 'categories' && <Categories />}
          {tab === 'content' && <Content />}
          {tab === 'settings' && <Settings />}
          {tab === 'legal' && <Legal />}
          {tab === 'enquiries' && <Enquiries />}
          {tab === 'features' && <Features />}
          {tab === 'payments' && <Payments />}
          {tab === 'logs' && <Logs />}
        </div>
      </main>
    </div>
  );
}

/* ─── Overview ─── */
function Overview() {
  const [days, setDays] = useState(30);
  const { data: d } = useFetch<any>('/admin/overview');
  const { data: a } = useFetch<any>(`/admin/analytics?days=${days}`, [days]);
  if (!d || !a) return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-pulse">{[...Array(8)].map((_, i) => <div key={i} className="bg-white rounded-2xl h-28 border border-slate-100" />)}</div>
  );
  const s = a.series;
  const contacts = s.calls.map((v: number, i: number) => v + s.whatsapp[i] + s.enquiries[i]);
  const kpis = [
    { label: 'Revenue', value: `₹${(a.totals.revenue).toLocaleString('en-IN')}`, sub: `₹${d.revenue.toLocaleString('en-IN')} all time`, trend: a.trends.revenue, spark: s.revenue, color: SERIES[2] },
    { label: 'Page views', value: a.totals.views.toLocaleString('en-IN'), sub: 'business page visits', trend: a.trends.views, spark: s.views, color: SERIES[0] },
    { label: 'Leads', value: a.totals.contacts.toLocaleString('en-IN'), sub: 'calls + WhatsApp + enquiries', trend: a.trends.contacts, spark: contacts, color: SERIES[1] },
    { label: 'New listings', value: a.totals.listings, sub: `${d.live} live now`, trend: a.trends.listings, spark: s.listings, color: SERIES[3] },
  ];
  const q = d.queue || {}; const pending = Object.values(q).reduce((x: any, y: any) => x + y, 0) as number;
  const Card = ({ title, children, right, className = '' }: any) => (
    <div className={`bg-white rounded-2xl border border-slate-100 p-5 ${className}`}><div className="flex items-center justify-between mb-4"><h3 className="font-bold text-slate-800 text-sm">{title}</h3>{right}</div>{children}</div>
  );
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-slate-500">Performance for the last <b className="text-slate-800">{days} days</b></p>
        <div className="flex bg-white border border-slate-200 rounded-xl p-1 text-xs font-bold">
          {[7, 30, 90].map((n) => <button key={n} onClick={() => setDays(n)} className={`px-3 py-1.5 rounded-lg ${days === n ? 'bg-slate-900 text-white' : 'text-slate-500 hover:text-slate-800'}`}>{n}D</button>)}
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((k) => (
          <div key={k.label} className="bg-white rounded-2xl border border-slate-100 p-5 hover:shadow-md transition">
            <div className="flex items-center justify-between"><p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{k.label}</p>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${k.trend >= 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-600'}`}>{k.trend >= 0 ? '▲' : '▼'} {Math.abs(k.trend)}%</span></div>
            <p className="text-2xl md:text-3xl font-black text-slate-900 mt-2">{k.value}</p>
            <div className="flex items-end justify-between mt-1"><p className="text-[11px] text-slate-400">{k.sub}</p><Spark data={k.spark} color={k.color} /></div>
          </div>
        ))}
      </div>

      {pending > 0 && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-4 flex flex-wrap gap-3 items-center">
          <span className="text-2xl">⏳</span><b className="text-amber-900">{pending} items waiting for your approval</b>
          <div className="flex flex-wrap gap-2 text-xs">{Object.entries(q).filter(([, v]: any) => v > 0).map(([k, v]: any) => <span key={k} className="bg-white border border-amber-200 rounded-full px-2.5 py-1 capitalize text-amber-800 font-semibold">{k}: {v}</span>)}</div>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        <Card title="Traffic & leads" className="lg:col-span-2">
          <LineChart labels={a.labels} series={[{ name: 'Page views', data: s.views, color: SERIES[0] }, { name: 'Calls', data: s.calls, color: SERIES[1] }, { name: 'WhatsApp', data: s.whatsapp, color: SERIES[2] }, { name: 'Enquiries', data: s.enquiries, color: SERIES[3] }]} />
        </Card>
        <Card title="Plan mix">
          <Donut label="listings" parts={[{ name: 'Premium', value: a.plans.premium, color: SERIES[1] }, { name: 'Free', value: a.plans.free, color: SERIES[0] }]} />
          <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-3 text-center">
            {[['Live', d.live], ['Suspended', d.suspended], ['Users', d.users]].map(([l, v]) => <div key={l}><p className="text-lg font-black text-slate-900">{v}</p><p className="text-[11px] text-slate-400">{l}</p></div>)}
          </div>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card title="Revenue (₹)"><LineChart labels={a.labels} series={[{ name: 'Revenue', data: s.revenue, color: SERIES[2] }]} height={180} money /></Card>
        <Card title="Growth"><LineChart labels={a.labels} series={[{ name: 'New listings', data: s.listings, color: SERIES[3] }, { name: 'New users', data: s.users, color: SERIES[0] }]} height={180} /></Card>
        <Card title="Search demand by category"><BarList data={a.searches} color={SERIES[1]} /></Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <Card title="Listings by category"><BarList data={a.byCategory} color={SERIES[0]} /></Card>
        <Card title="Listings by city"><BarList data={a.byCity} color={SERIES[2]} /></Card>
        <Card title="Premium plans expiring (30 days)">
          {a.expiring.length ? <div className="space-y-2">{a.expiring.map((b: any) => <div key={b._id} className="flex justify-between text-sm"><span className="text-slate-700 truncate">{b.name}</span><span className="text-amber-600 font-semibold text-xs">{new Date(b.planExpiry).toLocaleDateString('en-IN')}</span></div>)}</div>
            : <p className="text-sm text-slate-400 text-center py-6">No renewals due 🎉</p>}
        </Card>
      </div>

      <Card title="Top performing businesses" right={<span className="text-xs text-slate-400">views + leads</span>}>
        <div className="overflow-x-auto"><table className="w-full text-sm">
          <thead><tr className="text-left text-xs text-slate-400 uppercase tracking-wider"><th className="pb-2">#</th><th className="pb-2">Business</th><th className="pb-2">City</th><th className="pb-2">Plan</th><th className="pb-2 text-right">Views</th><th className="pb-2 text-right">Leads</th><th className="pb-2 text-right">Rating</th></tr></thead>
          <tbody>{a.topBusinesses.map((b: any, i: number) => (
            <tr key={b._id} className="border-t border-slate-100 hover:bg-slate-50"><td className="py-2.5 text-slate-400">{i + 1}</td><td className="font-semibold text-slate-800"><a href={`/business/${b._id}`} target="_blank" className="hover:text-blue-600">{b.name}</a></td><td className="text-slate-500">{b.city}</td>
              <td><span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${b.plan === 'premium' ? 'bg-orange-50 text-orange-700' : 'bg-slate-100 text-slate-500'}`}>{b.plan}</span></td>
              <td className="text-right tabular-nums">{b.views}</td><td className="text-right tabular-nums">{b.leads}</td><td className="text-right">{b.rating ? `${Number(b.rating).toFixed(1)}★` : '—'}</td></tr>))}</tbody>
        </table></div>
      </Card>
    </div>
  );
}

function Diff({ b }: { b: any }) {
  const u = b.pendingUpdates || {};
  const show = (v: any) => (v == null ? '—' : typeof v === 'object' ? JSON.stringify(v) : String(v));
  return (
    <div className="mt-3 rounded-xl border border-slate-200 overflow-hidden">
      <table className="w-full text-xs">
        <thead className="bg-slate-50"><tr><th className="p-2.5 text-left font-semibold text-slate-500">Field</th><th className="text-left font-semibold text-slate-500">Current</th><th className="text-left font-semibold text-slate-500">Requested</th></tr></thead>
        <tbody>{Object.keys(u).map((k) => (
          <tr key={k} className="border-t border-slate-100 align-top"><td className="p-2.5 font-semibold text-slate-700">{k}</td><td className="text-slate-400 break-all p-2.5">{show(b[k])}</td>
            <td className={`break-all p-2.5 ${show(b[k]) !== show(u[k]) ? 'bg-amber-50 font-semibold text-amber-800' : ''}`}>{k === 'documents' && u[k]?.file ? <a className="text-blue-600 underline" target="_blank" href={privateFile(u[k].file)}>View document</a> : show(u[k])}</td></tr>
        ))}</tbody>
      </table>
    </div>
  );
}

/* ─── Approval Queue ─── */
function Queue({ q }: { q: any }) {
  const [sub, setSub] = useState('listings'); const [reason, setReason] = useState('');
  const [viewBiz, setViewBiz] = useState<any>(null);
  const d = q.data || {};
  const act = async (path: string, body?: any) => { try { await api(path, { method: 'PUT', body: body || {} }); q.reload(); } catch (e: any) { alert(e.message); } };
  const reject = (id: string) => { const r = prompt('Reason for rejection?', reason || 'Documents unclear'); if (r !== null) { setReason(r); act(`/admin/listings/${id}/reject`, { reason: r }); } };
  const L = (b: any, edit = false) => (
    <div key={b._id} className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-md transition">
      <div className="flex flex-wrap gap-3 justify-between">
        <div className="flex gap-4">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 overflow-hidden flex items-center justify-center shadow-sm">{b.profileImage ? <img src={img(b.profileImage)} alt="" className="w-full h-full object-cover" /> : <span className="text-2xl">🏪</span>}</div>
          <div>
            <div className="flex items-center gap-2"><b className="text-slate-800">{b.name}</b> {b.plan === 'premium' && <Badge s="premium" />}</div>
            <p className="text-xs text-slate-400 mt-0.5">{b.category} › {b.subCategory} · {b.city}</p>
            <p className="text-xs text-slate-500 mt-1">👤 {b.owner?.name} · +91 {b.owner?.phone} {b.owner?.status === 'pending' && <Badge s="pending" />}</p>
          </div>
        </div>
        <div className="flex gap-2 items-start">
          <button onClick={() => setViewBiz(b)} className="bg-blue-50 hover:bg-blue-100 text-blue-600 px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm">👁 View</button>
          {b.documents?.file && <a href={privateFile(b.documents.file)} target="_blank" className="bg-slate-50 text-slate-600 px-3 py-2 rounded-xl text-xs font-medium hover:bg-slate-100 transition">📄 {b.documents.type}</a>}
          <button onClick={() => act(`/admin/listings/${b._id}/approve`)} className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm shadow-emerald-500/20">✔ Approve</button>
          <button onClick={() => reject(b._id)} className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm shadow-red-500/20">✕ Reject</button>
        </div>
      </div>
      {b.documents && <p className="text-xs text-slate-400 mt-2">Certificate: {b.documents.number || '—'} · Expiry: {b.documents.expiry || '—'}</p>}
      {edit ? <Diff b={b} /> : <p className="text-xs text-slate-500 mt-3 bg-slate-50 p-3 rounded-xl">{b.description}</p>}
    </div>
  );
  return (<div>
    <ViewBusiness b={viewBiz} onClose={() => setViewBiz(null)} />
    <p className="text-sm text-slate-500 mb-4 bg-blue-50 text-blue-700 p-3 rounded-xl font-medium">🛡️ Section 79 Safety Queue — Nothing goes live without your approval.</p>
    <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
      {[['listings', 'New Listings'], ['edits', 'Edit Requests'], ['vendors', 'Vendor Signups'], ['ads', 'Banner Ads'], ['claims', 'Claims'], ['reviews', 'Reviews'], ['offers', 'Offers'], ['reports', 'Reports']].map(([k, l]) => (
        <button key={k} onClick={() => setSub(k)} className={`px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${sub === k ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'bg-white text-slate-500 border border-slate-200 hover:border-blue-300'}`}>{l} ({d.counts?.[k] || 0})</button>
      ))}
    </div>
    {(sub === 'listings' || sub === 'edits') && d[sub]?.length > 1 && (
      <button onClick={async () => { if (!confirm(`Approve all ${d[sub].length}? Make sure you checked the documents.`)) return; try { const r = await api('/admin/bulk-approve', { body: { ids: d[sub].map((x: any) => x._id) } }); alert(r.message); q.reload(); } catch (e: any) { alert(e.message); } }}
        className="mb-3 bg-emerald-50 text-emerald-700 border border-emerald-200 px-4 py-2 rounded-xl text-xs font-bold hover:bg-emerald-100">✔ Approve all {d[sub].length}</button>
    )}
    <div className="space-y-3">
      {sub === 'offers' && d.offers?.map((o: any) => <OfferCard key={o._id} o={o} act={act} />)}
      {sub === 'offers' && !d.offers?.length && <p className="text-slate-400 text-sm">No offers waiting for approval.</p>}
      {sub === 'reports' && <AutoReplyPanel />}
      {sub === 'reports' && d.reports?.map((r: any) => <ReportCard key={r._id} r={r} act={act} />)}
      {sub === 'reports' && !d.reports?.length && <p className="text-slate-400 text-sm">No open reports or grievances.</p>}
      {sub === 'listings' && d.listings?.map((b: any) => L(b))}
      {sub === 'edits' && d.edits?.map((b: any) => L(b, true))}
      {sub === 'vendors' && d.vendors?.map((u: any) => (
        <div key={u._id} className="bg-white rounded-2xl p-5 flex justify-between items-center border border-slate-100"><div><b className="text-slate-800">{u.name || 'Vendor'}</b><p className="text-xs text-slate-400 mt-1">+91 {u.phone} · joined {new Date(u.createdAt).toLocaleDateString()}</p></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/users/${u._id}`, { status: 'approved' })} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Approve</button><button onClick={() => act(`/admin/users/${u._id}`, { status: 'rejected' })} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div></div>
      ))}
      {sub === 'ads' && d.ads?.map((a: any) => (
        <div key={a._id} className="bg-white rounded-2xl p-5 flex flex-wrap gap-3 justify-between items-center border border-slate-100">
          <div className="flex gap-3 items-center">{a.image && <img src={img(a.image)} alt="" className="h-12 rounded-xl" />}<div><b className="text-slate-800">{a.title}</b> <Badge s={a.paymentStatus} /><p className="text-xs text-slate-400 mt-1">{a.type} · {a.days} days · ₹{a.amount}</p></div></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/ads/${a._id}`, { status: 'approved' })} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Approve</button><button onClick={() => act(`/admin/ads/${a._id}`, { status: 'rejected' })} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div>
        </div>
      ))}
      {sub === 'claims' && d.claims?.map((c: any) => (
        <div key={c._id} className="bg-white rounded-2xl p-5 flex justify-between items-center border border-slate-100"><div><b className="text-slate-800">{c.businessName}</b><p className="text-xs text-slate-400 mt-1">Claimed by {c.name} +91 {c.phone}</p><a href={privateFile(c.document)} target="_blank" className="text-xs text-blue-600 underline">View proof</a></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/claims/${c._id}/approve`)} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Approve</button><button onClick={() => act(`/admin/claims/${c._id}/reject`)} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div></div>
      ))}
      {sub === 'reviews' && d.reviews?.map((r: any) => (
        <div key={r._id} className="bg-white rounded-2xl p-5 flex flex-wrap gap-3 justify-between items-center border border-slate-100">
          <div><b className="text-slate-800">{r.businessName}</b> <span className="text-amber-500 font-bold ml-1">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
            <p className="text-sm text-slate-600 mt-1">“{r.text || '—'}”</p><p className="text-xs text-slate-400 mt-1">by {r.name} +91 {r.phone}</p></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/reviews/${r._id}/approve`)} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Publish</button><button onClick={() => act(`/admin/reviews/${r._id}/reject`)} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div>
        </div>
      ))}
      {!d[sub]?.length && <div className="bg-white rounded-2xl p-10 text-center border border-slate-100"><span className="text-4xl">🎉</span><p className="text-slate-500 mt-3 font-medium">All clear! Nothing pending here.</p></div>}
    </div>
  </div>);
}

/* ─── Businesses ─── */
function Businesses() {
  const list = useFetch<any[]>('/admin/businesses'); const { data: cats } = useFetch<any[]>('/categories');
  const [q, setQ] = useState(''); const [form, setForm] = useState<any>(null);
  const [viewBiz, setViewBiz] = useState<any>(null);
  const act = async (p: string, method = 'PUT', body: any = {}) => { try { await api(p, { method, body }); list.reload(); } catch (e: any) { alert(e.message); } };
  const save = async (e: React.FormEvent) => {
    e.preventDefault(); const fd = new FormData(e.target as HTMLFormElement);
    fd.set('contact', JSON.stringify({ phone: fd.get('phone'), whatsapp: fd.get('whatsapp') })); fd.delete('phone'); fd.delete('whatsapp');
    fd.set('unclaimed', fd.get('unclaimed') ? 'true' : 'false');
    ['profileImage'].forEach((k) => { const f = fd.get(k) as File; if (!f?.size) fd.delete(k); });
    try { await api(form._id ? `/admin/businesses/${form._id}` : '/admin/businesses', { method: form._id ? 'PUT' : 'POST', form: fd }); setForm(null); list.reload(); } catch (e: any) { alert(e.message); }
  };
  const rows = (list.data || []).filter((b) => !q || JSON.stringify([b.name, b.city, b.category, b.contact?.phone]).toLowerCase().includes(q.toLowerCase()));
  return (<div>
    <ViewBusiness b={viewBiz} onClose={() => setViewBiz(null)} />
    <div className="flex gap-3 mb-5">
      <div className="flex-1 relative">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
        <input className="w-full bg-white border border-slate-200 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition" placeholder="Search name, city, phone…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <ExportBtn what="businesses" /><ImportBtn onDone={() => list.reload()} /><button onClick={() => setForm({ unclaimed: true, plan: 'free' })} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-5 py-3 rounded-xl text-sm font-bold shadow-lg shadow-blue-600/20 hover:shadow-xl transition shrink-0">+ Pre-load Business</button>
    </div>
    {form && (
      <form onSubmit={save} className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 mb-5 border border-blue-200 shadow-lg shadow-blue-500/5">
        <input name="name" required defaultValue={form.name} placeholder="Business Name" className="input" />
        <select name="category" required defaultValue={form.category} className="input"><option value="">Select Category</option>{cats?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select>
        <input name="subCategory" defaultValue={form.subCategory} placeholder="Sub-category" className="input" list="subs" />
        <datalist id="subs">{cats?.flatMap((c) => c.subs).map((s: string) => <option key={s} value={s} />)}</datalist>
        <input name="city" defaultValue={form.city || 'Udupi'} placeholder="City" className="input" />
        <input name="address" defaultValue={form.address} placeholder="Address" className="input" />
        <input name="phone" defaultValue={form.contact?.phone} placeholder="Phone" className="input" />
        <input name="whatsapp" defaultValue={form.contact?.whatsapp} placeholder="WhatsApp" className="input" />
        <select name="plan" defaultValue={form.plan} className="input"><option value="free">Free</option><option value="premium">Premium</option></select>
        <input name="planExpiry" type="date" defaultValue={form.planExpiry?.slice(0, 10)} className="input" title="Plan expiry" />
        <input name="rating" defaultValue={form.rating} placeholder="Rating (e.g. 4.5)" className="input" />
        <input name="reviews" defaultValue={form.reviews} placeholder="No. of ratings" className="input" />
        <input name="profileImage" type="file" accept="image/*" className="input" />
        <textarea name="description" defaultValue={form.description} placeholder="Description" className="input md:col-span-3" />
        <label className="text-sm flex gap-2 items-center text-slate-600"><input type="checkbox" name="unclaimed" defaultChecked={form.unclaimed} className="rounded" /> Unclaimed (show "Claim it now")</label>
        <div className="md:col-span-2 flex gap-2 justify-end"><button type="button" onClick={() => setForm(null)} className="px-5 py-2.5 rounded-xl text-sm text-slate-500 hover:bg-slate-50 transition">Cancel</button><button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-sm">Save</button></div>
      </form>
    )}
    <div className="bg-white rounded-2xl overflow-hidden border border-slate-100"><table className="w-full text-sm"><thead className="bg-slate-50/80 text-left"><tr><th className="p-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Business</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">City</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Plan</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Status</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Views</th><th className="text-right pr-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Actions</th></tr></thead>
      <tbody>{rows.map((b) => (
        <tr key={b._id} className="border-t border-slate-100 hover:bg-blue-50/30 transition"><td className="p-4"><b className="text-slate-800">{b.name}</b>{b.unclaimed && <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-full ml-2">UNCLAIMED</span>}{b.pendingUpdates && <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-full ml-1">EDIT</span>}<br /><span className="text-xs text-slate-400">{b.subCategory}</span></td>
          <td className="text-slate-600">{b.city}</td><td><span className="text-xs font-medium">{b.plan}</span>{b.planExpiry && <div className="text-[10px] text-slate-400">till {new Date(b.planExpiry).toLocaleDateString()}</div>}</td><td><Badge s={b.status} /></td><td className="text-slate-600">{b.views || 0}</td>
          <td className="text-right pr-4 whitespace-nowrap space-x-1">
            <button onClick={() => setViewBiz(b)} className="text-blue-600 hover:bg-blue-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">View</button>
            <button onClick={() => setForm(b)} className="text-blue-600 hover:bg-blue-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Edit</button>
            {b.status === 'approved' ? <button onClick={() => act(`/admin/listings/${b._id}/suspend`)} className="text-amber-600 hover:bg-amber-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Suspend</button> : <button onClick={() => act(`/admin/listings/${b._id}/approve`)} className="text-emerald-600 hover:bg-emerald-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Approve</button>}
            <button onClick={() => confirm('Delete permanently?') && act(`/admin/businesses/${b._id}`, 'DELETE')} className="text-red-500 hover:bg-red-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Delete</button>
          </td></tr>
      ))}</tbody></table></div>
  </div>);
}

/* ─── Users ─── */
function Users() {
  const u = useFetch<any[]>('/admin/users');
  const upd = async (id: string, body: any) => { await api(`/admin/users/${id}`, { method: 'PUT', body }); u.reload(); };
  return (<div><div className="flex justify-end mb-3"><ExportBtn what="users" /></div><div className="bg-white rounded-2xl overflow-hidden border border-slate-100"><table className="w-full text-sm"><thead className="bg-slate-50/80 text-left"><tr><th className="p-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Name</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Phone</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Role</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Status</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Actions</th></tr></thead>
    <tbody>{u.data?.map((x) => <tr key={x._id} className="border-t border-slate-100 hover:bg-blue-50/30 transition"><td className="p-4 font-medium text-slate-800">{x.name || '—'}</td><td className="text-slate-600">+91 {x.phone}</td>
      <td><select value={x.role} onChange={(e) => upd(x._id, { role: e.target.value })} className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs font-medium"><option>user</option><option>vendor</option><option>admin</option></select></td>
      <td><Badge s={x.blocked ? 'blocked' : x.status} /></td>
      <td className="space-x-1">{x.status !== 'approved' && <button onClick={() => upd(x._id, { status: 'approved' })} className="text-emerald-600 hover:bg-emerald-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Approve</button>}
        <button onClick={() => upd(x._id, { blocked: !x.blocked })} className="text-amber-600 hover:bg-amber-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">{x.blocked ? 'Unblock' : 'Block'}</button></td></tr>)}</tbody></table></div></div>);
}

/* ─── Ads ─── */
function Ads() {
  const ads = useFetch<any[]>('/admin/ads'); const [f, setF] = useState<any>(null);
  const save = async (e: React.FormEvent) => {
    e.preventDefault(); const fd = new FormData(e.target as HTMLFormElement); const im = fd.get('image') as File; if (!im?.size) fd.delete('image');
    try { await api(f._id ? `/admin/ads/${f._id}` : '/admin/ads', { method: f._id ? 'PUT' : 'POST', form: fd }); setF(null); ads.reload(); } catch (e: any) { alert(e.message); }
  };
  const upd = async (id: string, body: any, method = 'PUT') => { await api(`/admin/ads/${id}`, { method, body }); ads.reload(); };
  return (<div>
    <button onClick={() => setF({ type: 'top_banner' })} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-5 py-3 rounded-xl text-sm font-bold shadow-lg shadow-blue-600/20 mb-5">+ New Ad / Banner</button>
    {f && (
      <form onSubmit={save} className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 mb-5 border border-blue-200">
        <select name="type" defaultValue={f.type} className="input"><option value="top_banner">Top banner (970×90)</option><option value="middle_banner">Middle banner</option><option value="promo">Promotional widget</option><option value="hero_video">Hero video ad</option></select>
        <input name="title" defaultValue={f.title} placeholder="Title" className="input" />
        <input name="subtitle" defaultValue={f.subtitle} placeholder="Subtitle" className="input" />
        <input name="cta" defaultValue={f.cta} placeholder="Button text" className="input" />
        <input name="link" defaultValue={f.link} placeholder="Link URL" className="input" />
        <input name="youtubeUrl" defaultValue={f.youtubeUrl} placeholder="YouTube URL" className="input" />
        <input name="bg" defaultValue={f.bg} placeholder="Background CSS" className="input" />
        <input name="imageUrl" defaultValue={f.image?.startsWith('http') ? f.image : ''} placeholder="Image URL" className="input" />
        <input name="image" type="file" accept="image/*" className="input" />
        <label className="text-xs text-slate-500 font-medium">Start Date<input name="startDate" type="date" defaultValue={f.startDate?.slice(0, 10)} className="input mt-1" /></label>
        <label className="text-xs text-slate-500 font-medium">End Date<input name="endDate" type="date" defaultValue={f.endDate?.slice(0, 10)} className="input mt-1" /></label>
        <div className="flex gap-2 items-end justify-end"><button type="button" onClick={() => setF(null)} className="px-4 py-2 text-slate-500 hover:bg-slate-50 rounded-xl text-sm transition">Cancel</button><button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold">Save</button></div>
      </form>
    )}
    <div className="grid md:grid-cols-2 gap-4">{ads.data?.map((a) => (
      <div key={a._id} className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-md transition">
        <div className="flex justify-between items-start"><b className="text-slate-800">{a.title}</b><Badge s={a.status} /></div>
        <p className="text-xs text-slate-400 mt-1">{a.type} · by {a.createdBy} {a.amount ? `· ₹${a.amount} (${a.paymentStatus})` : ''} {a.endDate ? `· till ${new Date(a.endDate).toLocaleDateString()}` : ''}</p>
        <div className="flex gap-1 mt-3">
          <button onClick={() => setF(a)} className="text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Edit</button>
          {a.status !== 'approved' ? <button onClick={() => upd(a._id, { status: 'approved' })} className="text-emerald-600 hover:bg-emerald-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Activate</button> : <button onClick={() => upd(a._id, { status: 'paused' })} className="text-amber-600 hover:bg-amber-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Pause</button>}
          <button onClick={() => confirm('Delete?') && upd(a._id, {}, 'DELETE')} className="text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Delete</button>
        </div>
      </div>
    ))}</div>
  </div>);
}

/* ─── Categories ─── */
function Categories() {
  const cats = useFetch<any[]>('/categories');
  const save = async (c: any) => { try { await api(c._id ? `/admin/categories/${c._id}` : '/admin/categories', { method: c._id ? 'PUT' : 'POST', body: c }); cats.reload(); } catch (e: any) { alert(e.message); } };
  const [n, setN] = useState<any>({ name: '', icon: '📁', subs: '', color: '#0055FF' });
  return (<div className="space-y-3">
    {cats.data?.map((c) => <CatRow key={c._id} c={c} onSave={save} onDel={async () => { if (confirm('Delete category?')) { await api(`/admin/categories/${c._id}`, { method: 'DELETE' }); cats.reload(); } }} />)}
    <div className="bg-white rounded-2xl p-5 grid md:grid-cols-5 gap-3 border-2 border-dashed border-blue-200">
      <input className="input" placeholder="Icon" value={n.icon} onChange={(e) => setN({ ...n, icon: e.target.value })} />
      <input className="input" placeholder="Category Name" value={n.name} onChange={(e) => setN({ ...n, name: e.target.value })} />
      <input className="input md:col-span-2" placeholder="Sub-categories (comma separated)" value={n.subs} onChange={(e) => setN({ ...n, subs: e.target.value })} />
      <button onClick={() => { save(n); setN({ name: '', icon: '📁', subs: '', color: '#0055FF' }); }} className="bg-blue-600 text-white px-4 py-2.5 rounded-xl text-sm font-bold">+ Add Category</button>
    </div>
  </div>);
}
function CatRow({ c, onSave, onDel }: any) {
  const [v, setV] = useState({ ...c, subs: c.subs.join(', ') });
  return (<div className="bg-white rounded-2xl p-4 grid md:grid-cols-12 gap-3 items-center border border-slate-100 hover:shadow-sm transition">
    <input className="input md:col-span-1 text-center text-xl" value={v.icon} onChange={(e) => setV({ ...v, icon: e.target.value })} />
    <input className="input md:col-span-3 font-medium" value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} />
    <input className="input md:col-span-5 text-xs" value={v.subs} onChange={(e) => setV({ ...v, subs: e.target.value })} />
    <input className="input md:col-span-1" type="number" value={v.order} onChange={(e) => setV({ ...v, order: Number(e.target.value) })} title="Order" />
    <div className="md:col-span-2 flex gap-2"><button onClick={() => onSave({ _id: c._id, name: v.name, icon: v.icon, subs: v.subs, order: v.order })} className="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex-1">Save</button><button onClick={onDel} className="text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg text-xs font-medium">Del</button></div>
  </div>);
}

/* ─── Content ─── */
function Content() {
  const [kind, setKind] = useState('offers');
  const list = useFetch<any[]>(`/admin/${kind}`);
  const FIELDS: Record<string, string[]> = { offers: ['title', 'subtitle', 'businessName', 'city', 'code', 'expiry'], blogs: ['title', 'excerpt', 'body', 'image'], videos: ['title', 'url', 'category'] };
  const [f, setF] = useState<any>({});
  const save = async () => { try { await api(f._id ? `/admin/${kind}/${f._id}` : `/admin/${kind}`, { method: f._id ? 'PUT' : 'POST', body: f }); setF({}); list.reload(); } catch (e: any) { alert(e.message); } };
  return (<div>
    <div className="flex gap-2 mb-5">{['offers', 'blogs', 'videos'].map((k) => <button key={k} onClick={() => { setKind(k); setF({}); }} className={`px-5 py-2.5 rounded-xl text-xs font-bold capitalize transition ${kind === k ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'bg-white text-slate-500 border border-slate-200 hover:border-blue-300'}`}>{k}</button>)}</div>
    <div className="bg-white rounded-2xl p-5 grid md:grid-cols-3 gap-3 mb-5 border border-slate-100">
      {FIELDS[kind].map((k) => k === 'body' ? <textarea key={k} rows={4} className="input md:col-span-3" placeholder={k} value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
        : <input key={k} className="input" placeholder={k === 'url' ? 'YouTube / video URL' : k} value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />)}
      <div className="flex gap-2"><button onClick={save} className="bg-blue-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold">{f._id ? 'Update' : '+ Add'}</button>{f._id && <button onClick={() => setF({})} className="px-4 py-2 text-slate-500 hover:bg-slate-50 rounded-xl text-sm">Cancel</button>}</div>
    </div>
    <div className="space-y-2">{list.data?.map((x) => (
      <div key={x._id} className="bg-white rounded-2xl p-4 flex justify-between items-center text-sm border border-slate-100 hover:shadow-sm transition"><div><b className="text-slate-800">{x.title}</b><p className="text-xs text-slate-400 mt-0.5">{x.subtitle || x.excerpt || x.url}</p></div>
        <div className="flex gap-1"><button onClick={() => setF(x)} className="text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Edit</button>
          <button onClick={async () => { if (confirm('Delete?')) { await api(`/admin/${kind}/${x._id}`, { method: 'DELETE' }); list.reload(); } }} className="text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Delete</button></div></div>
    ))}</div>
  </div>);
}

/* ─── Settings ─── */
function useSettings() {
  const s = useFetch<any>('/admin/settings');
  const save = async (patch: any) => { try { await api('/admin/settings', { method: 'PUT', body: patch }); s.reload(); alert('Saved'); } catch (e: any) { alert(e.message); } };
  return { s: s.data, save };
}
function Settings() {
  const { s, save } = useSettings(); const [v, setV] = useState<any>(null);
  useEffect(() => { if (s) setV(JSON.parse(JSON.stringify(s))); }, [s]);
  if (!v) return <div className="flex items-center justify-center py-20"><div className="animate-spin w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full" /></div>;
  const F = (path: string, label: string, area = false) => {
    const [a, b] = path.split('.'); const val = b ? v[a]?.[b] : v[a];
    const on = (e: any) => setV(b ? { ...v, [a]: { ...(v[a] || {}), [b]: e.target.value } } : { ...v, [a]: e.target.value });
    return <div key={path}><label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">{label}</label>{area ? <textarea className="input" rows={2} value={val || ''} onChange={on} /> : <input className="input" value={val || ''} onChange={on} />}</div>;
  };
  return (<div className="space-y-5">
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-2 gap-4 border border-slate-100"><h3 className="md:col-span-2 font-bold text-slate-800 text-lg">🎯 Hero Section</h3>{F('hero.title', 'Hero Title')}{F('hero.subtitle', 'Hero Subtitle')}
      <div className="md:col-span-2"><label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">Popular Searches</label><input className="input" value={(v.popularSearches || []).join(', ')} onChange={(e) => setV({ ...v, popularSearches: e.target.value.split(',').map((x: string) => x.trim()).filter(Boolean) })} /></div></div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-4 gap-4 border border-slate-100"><h3 className="md:col-span-4 font-bold text-slate-800 text-lg">📊 Trust Counters</h3>{F('stats.businesses', 'Businesses')}{F('stats.customers', 'Customers')}{F('stats.verified', 'Verified Label')}{F('stats.support', 'Support Label')}</div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 border border-slate-100"><h3 className="md:col-span-3 font-bold text-slate-800 text-lg">📍 Location Banner</h3>{F('locationBanner.title', 'Title')}{F('locationBanner.subtitle', 'Subtitle')}{F('locationBanner.image', 'Image URL')}</div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-2 gap-4 border border-slate-100"><h3 className="md:col-span-2 font-bold text-slate-800 text-lg">📢 CTA Boxes</h3>{F('cta.vendorTitle', 'Vendor CTA Title')}{F('cta.vendorText', 'Vendor CTA Text')}{F('cta.advertiseTitle', 'Advertise Title')}{F('cta.advertiseText', 'Advertise Text')}</div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 border border-slate-100"><h3 className="md:col-span-3 font-bold text-slate-800 text-lg">🔗 Social & Apps</h3>{F('social.facebook', 'Facebook')}{F('social.instagram', 'Instagram')}{F('social.youtube', 'YouTube')}{F('social.linkedin', 'LinkedIn')}{F('apps.android', 'Play Store URL')}{F('apps.ios', 'App Store URL')}</div>
    <button onClick={() => { const { pages, searchStats, ...rest } = v; save(rest); }} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-blue-600/20 hover:shadow-xl transition">💾 Save Homepage Settings</button>
  </div>);
}

/* ─── Legal ─── */
function Legal() {
  const { s, save } = useSettings(); const [pages, setPages] = useState<any>(null);
  useEffect(() => { if (s) setPages(s.pages || {}); }, [s]);
  if (!pages) return <div className="flex items-center justify-center py-20"><div className="animate-spin w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full" /></div>;
  return (<div className="space-y-4">{Object.entries(pages).map(([k, p]: any) => (
    <div key={k} className="bg-white rounded-2xl p-6 border border-slate-100"><input className="input font-bold mb-3 text-lg" value={p.title} onChange={(e) => setPages({ ...pages, [k]: { ...p, title: e.target.value } })} />
      <textarea className="input" rows={8} value={p.body} onChange={(e) => setPages({ ...pages, [k]: { ...p, body: e.target.value } })} /><p className="text-xs text-slate-400 mt-2">🔗 URL: /legal/{k}</p></div>
  ))}<button onClick={() => save({ pages })} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-blue-600/20">💾 Save Legal Pages</button></div>);
}

/* ─── Payments ─── */
function Payments() {
  const p = useFetch<any[]>('/admin/payments');
  return (<div><div className="flex justify-end mb-3"><ExportBtn what="payments" /></div><div className="bg-white rounded-2xl overflow-hidden border border-slate-100"><table className="w-full text-sm"><thead className="bg-slate-50/80 text-left"><tr><th className="p-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Date</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Purpose</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Amount</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Razorpay ID</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Status</th></tr></thead>
    <tbody>{p.data?.map((x) => <tr key={x._id} className="border-t border-slate-100 hover:bg-blue-50/30 transition"><td className="p-4 text-slate-600">{new Date(x.createdAt).toLocaleString()}</td><td className="text-slate-800 font-medium">{x.purpose}{x.mock && <span className="text-[10px] bg-amber-50 text-amber-600 px-1.5 py-0.5 rounded-full ml-1">TEST</span>}</td><td className="font-bold text-slate-800">₹{x.amount}</td><td className="text-xs text-slate-400 font-mono">{x.razorpayPaymentId || x.orderId}</td><td><Badge s={x.status} /></td></tr>)}</tbody></table></div></div>);
}

/* ─── Logs ─── */
function Logs() {
  const n = useFetch<any[]>('/admin/notifications'); const a = useFetch<any[]>('/admin/audit');
  const run = async () => { const r = await api('/admin/run-expiry-job', { body: {} }); alert(JSON.stringify(r)); n.reload(); };
  return (<div className="grid md:grid-cols-2 gap-6">
    <div>
      <div className="flex justify-between items-center mb-4"><h3 className="font-bold text-slate-800 text-lg">🔔 Notifications</h3><button onClick={run} className="bg-amber-50 text-amber-700 px-4 py-2 rounded-xl text-xs font-bold hover:bg-amber-100 transition">Run Expiry Check</button></div>
      <div className="space-y-2">{n.data?.map((x) => <div key={x._id} className="bg-white rounded-2xl p-4 text-xs border border-slate-100"><div className="flex justify-between"><b className="text-slate-800">{x.title}</b><span className="text-slate-400">[{x.channel}]</span></div><p className="text-slate-500 mt-1">{x.message}</p><p className="text-slate-400 mt-2">{new Date(x.createdAt).toLocaleString()}</p></div>)}</div></div>
    <div>
      <h3 className="font-bold text-slate-800 text-lg mb-4">📋 Audit Log</h3>
      <div className="space-y-2">{a.data?.map((x) => <div key={x._id} className="bg-white rounded-2xl p-4 text-xs border border-slate-100"><b className="text-slate-800">{x.action}</b>{x.action === 'business_deleted' && x.meta?.snapshot && <button onClick={async () => { try { alert((await api(`/admin/restore/${x._id}`, { body: {} })).message); a.reload(); } catch (e: any) { alert(e.message); } }} className="ml-2 bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-lg font-bold">↩ Restore</button>} <span className="text-slate-400 font-mono">{JSON.stringify(x.meta)}</span><p className="text-slate-400 mt-2">{new Date(x.createdAt).toLocaleString()}</p></div>)}</div></div>
  </div>);
}

/* ─── Enquiries & Reviews ─── */
function Enquiries() {
  const e = useFetch<any[]>('/admin/enquiries'); const r = useFetch<any[]>('/admin/reviews');
  const del = async (id: string) => { if (confirm('Delete review?')) { await api(`/admin/reviews/${id}`, { method: 'DELETE' }); r.reload(); } };
  return (<div className="grid lg:grid-cols-2 gap-6">
    <div><h3 className="font-bold text-slate-800 mb-3">📨 Customer enquiries ({e.data?.length || 0})</h3>
      <div className="space-y-2">{e.data?.map((x) => (
        <div key={x._id} className="bg-white rounded-2xl p-4 border border-slate-100 text-sm">
          <div className="flex justify-between"><b>{x.businessName}</b><Badge s={x.status} /></div>
          <p className="text-slate-600 mt-1">{x.message || '—'}</p>
          <p className="text-xs text-slate-400 mt-1">{x.name} · +91 {x.phone} · {new Date(x.createdAt).toLocaleString('en-IN')}</p>
        </div>))}{!e.data?.length && <p className="text-slate-400 text-sm">No enquiries yet.</p>}</div></div>
    <div><h3 className="font-bold text-slate-800 mb-3">⭐ All reviews ({r.data?.length || 0})</h3>
      <div className="space-y-2">{r.data?.map((x) => (
        <div key={x._id} className="bg-white rounded-2xl p-4 border border-slate-100 text-sm">
          <div className="flex justify-between items-center"><b>{x.businessName}</b><div className="flex gap-2 items-center"><Badge s={x.status} /><button onClick={() => del(x._id)} className="text-red-500 text-xs">Delete</button></div></div>
          <p className="text-amber-500">{'★'.repeat(x.rating)}{'☆'.repeat(5 - x.rating)}</p><p className="text-slate-600">{x.text}</p>
          <p className="text-xs text-slate-400">{x.name} · {new Date(x.createdAt).toLocaleDateString('en-IN')}</p>
        </div>))}</div></div>
  </div>);
}


/* ─── CSV export button ─── */
function ExportBtn({ what }: { what: string }) {
  return <a href={`${API}/api/admin/export/${what}?token=${getToken()}`} className="inline-flex items-center gap-1 bg-white border border-slate-200 hover:border-blue-300 text-slate-600 px-3 py-2 rounded-xl text-xs font-bold">⬇ Export CSV</a>;
}

/* ─── Feature Controls ─── */
const FEATURE_LIST: [string, string, string, string][] = [
  ['customerLogin', '👤', 'Customer login / signup', 'Customers log in with mobile OTP (always required) to review, report or raise a grievance. OFF disables these.'],
  ['vendorSignup', '🏪', 'New business registrations', 'Allow new business owners to sign up.'],
  ['vendorOtp', '📱', 'OTP for business owner login', 'OFF = business owners log in with mobile number only. Admin login always needs OTP.'],
  ['reviews', '⭐', 'Reviews & ratings', 'Customers can write reviews (each review is moderated).'],
  ['enquiries', '📨', 'Enquiry form', 'Lead form on every business page.'],
  ['favorites', '❤️', 'Save / favourites', 'Customers can save businesses.'],
  ['claims', '🏷️', 'Claim your business', 'Owners can claim pre-loaded listings.'],
  ['reports', '🚩', 'Report listing', 'Logged-in visitors can report fake / wrong listings.'],
  ['complaintForm', '📝', 'Complaint option (Contact page)', 'Show the Complaint tab in the Contact form.'],
  ['orderOnline', '🛵', 'Order Online (Swiggy/Zomato)', 'Show the Order Online sheet on food listings.'],
  ['premiumUpgrade', '💎', 'Premium plan purchase', 'Vendors can buy Premium via Razorpay.'],
  ['bannerBooking', '📢', 'Banner ad booking', 'Premium vendors can book homepage banners.'],
  ['maintenance', '🛠️', 'Maintenance mode', 'Shows a banner and pauses vendor submissions.'],
];
function Features() {
  const f = useFetch<any>('/admin/features'); const st = useFetch<any>('/admin/settings');
  const [ann, setAnn] = useState<string | null>(null);
  const toggle = async (k: string) => {
    const v = !(f.data?.[k] ?? (k === 'customerOtp'));
    f.setData({ ...f.data, [k]: v });
    try { await api('/admin/features', { method: 'PUT', body: { [k]: v } }); loadConfig(true); } catch (e: any) { alert(e.message); f.reload(); }
  };
  const announcement = ann ?? st.data?.announcement ?? '';
  return (<div className="space-y-6 max-w-4xl">
    <div className="bg-blue-50 text-blue-800 text-sm p-4 rounded-2xl">Turn site features on/off instantly. Changes apply to the live website right away.</div>
    <div className="grid md:grid-cols-2 gap-3">
      {FEATURE_LIST.map(([k, icon, title, desc]) => {
        const on = f.data ? (f.data[k] ?? (k === 'customerOtp')) : false;
        const dim = k === 'customerOtp' && !f.data?.customerLogin || k === 'guestReviews' && !f.data?.reviews;
        return (
          <div key={k} className={`bg-white rounded-2xl p-4 border flex gap-4 items-start transition ${on ? 'border-blue-200 shadow-sm' : 'border-slate-100'} ${dim ? 'opacity-50' : ''}`}>
            <span className="text-2xl">{icon}</span>
            <div className="flex-1"><b className="text-slate-800 text-sm">{title}</b><p className="text-xs text-slate-500 mt-0.5">{desc}</p></div>
            <button onClick={() => toggle(k)} disabled={!f.data} aria-label={title}
              className={`relative w-12 h-7 rounded-full transition shrink-0 ${on ? (k === 'maintenance' ? 'bg-red-500' : 'bg-emerald-500') : 'bg-slate-300'}`}>
              <span className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow transition-all ${on ? 'left-6' : 'left-1'}`} />
            </button>
          </div>);
      })}
    </div>
    <div className="bg-white rounded-2xl p-5 border border-slate-100">
      <b className="text-slate-800 text-sm">📣 Announcement bar</b><p className="text-xs text-slate-500 mb-3">Shown at the top of the website (leave empty to hide).</p>
      <div className="flex gap-2"><input className="input" placeholder="e.g. 🎉 List your business free this Diwali!" value={announcement} onChange={(e) => setAnn(e.target.value)} />
        <button onClick={async () => { await api('/admin/settings', { method: 'PUT', body: { announcement } }); loadConfig(true); alert('Saved'); }} className="bg-blue-600 text-white px-5 rounded-xl text-sm font-bold">Save</button></div>
    </div>
    <div className="bg-white rounded-2xl p-5 border border-slate-100">
      <b className="text-slate-800 text-sm">⬇ Data exports</b><p className="text-xs text-slate-500 mb-3">Download as CSV (opens in Excel).</p>
      <div className="flex flex-wrap gap-2">{['businesses', 'users', 'enquiries', 'reviews', 'payments'].map((w) => <a key={w} href={`${API}/api/admin/export/${w}?token=${getToken()}`} className="bg-slate-50 hover:bg-blue-50 border border-slate-200 px-4 py-2 rounded-xl text-xs font-bold capitalize">{w}</a>)}</div>
    </div>
  </div>);
}

/* ─── Dashboard (home of admin) ─── */
function Dashboard({ go, role }: { go: (t: string) => void; role: string }) {
  const { data: d } = useFetch<any>('/admin/overview');
  const { data: q } = useFetch<any>('/admin/queue');
  const { data: logs } = useFetch<any[]>(role === 'admin' ? '/admin/audit' : null);
  const { data: sys } = useFetch<any>(role === 'admin' ? '/admin/system' : null);
  const hour = new Date().getHours();
  const c = q?.counts || {};
  const queueCards = [['listings', 'New listings', '🆕'], ['edits', 'Edit requests', '✏️'], ['vendors', 'Vendor signups', '🧑‍💼'], ['ads', 'Banner ads', '📢'], ['claims', 'Claims', '🏷️'], ['reviews', 'Reviews', '⭐'], ['offers', 'Offers', '🏷️'], ['reports', 'Reports', '🚩']];
  const okInt = sys?.integrations?.filter((i: any) => i.ok).length || 0;
  return (
    <div className="space-y-6">
      <div className="rounded-3xl p-6 md:p-8 text-white bg-gradient-to-br from-[#0b1b3f] via-[#0033aa] to-[#0055FF] relative overflow-hidden">
        <div className="absolute -right-16 -top-16 w-72 h-72 rounded-full bg-white/5" /><div className="absolute right-24 bottom-[-60px] w-52 h-52 rounded-full bg-orange-500/20 blur-2xl" />
        <p className="text-blue-200 text-sm relative">{hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'} 👋</p>
        <h2 className="text-2xl md:text-3xl font-black relative">Welcome to PVRS HUB control centre</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-6 relative">
          {[['Live listings', d?.live], ['Premium', d?.premium], ['Users', d?.users], ['Revenue', d ? `₹${d.revenue.toLocaleString('en-IN')}` : '']].map(([l, v]) => (
            <div key={l as string} className="bg-white/10 backdrop-blur rounded-2xl p-4"><p className="text-xs text-blue-100">{l}</p><p className="text-2xl font-black mt-1">{v ?? '…'}</p></div>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-3"><h3 className="font-bold text-slate-800">Needs your attention</h3><button onClick={() => go('queue')} className="text-xs font-bold text-blue-600">Open queue →</button></div>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {queueCards.map(([k, l, i]) => (
            <button key={k} onClick={() => go('queue')} className={`text-left rounded-2xl p-4 border transition hover:shadow-md ${c[k] ? 'bg-amber-50 border-amber-200' : 'bg-white border-slate-100'}`}>
              <span className="text-xl">{i}</span><p className={`text-2xl font-black mt-1 ${c[k] ? 'text-amber-700' : 'text-slate-300'}`}>{c[k] || 0}</p><p className="text-xs text-slate-500">{l}</p>
            </button>))}
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-bold text-slate-800 mb-4">Quick actions</h3>
          <div className="grid grid-cols-2 gap-2">
            {(role === 'admin' ? [['➕', 'Add business', 'businesses'], ['📢', 'New banner', 'ads'], ['📂', 'Categories', 'categories'], ['📈', 'Analytics', 'analytics'], ['🎛️', 'Features', 'features'], ['🧑‍💼', 'Add admin', 'team']] : [['🛡️', 'Approval queue', 'queue'], ['📨', 'Enquiries', 'enquiries']]).map(([i, l, t]) => (
              <button key={t} onClick={() => go(t)} className="rounded-xl border border-slate-100 bg-slate-50 hover:bg-blue-50 hover:border-blue-200 p-3 text-left transition"><span className="text-lg">{i}</span><p className="text-xs font-semibold text-slate-700 mt-1">{l}</p></button>))}
          </div>
        </div>
        {role === 'admin' && <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <div className="flex items-center justify-between mb-4"><h3 className="font-bold text-slate-800">System health</h3><button onClick={() => go('system')} className="text-xs font-bold text-blue-600">Details →</button></div>
          {sys ? <>
            <div className="flex items-center gap-3 mb-4"><div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-xl ${okInt === sys.integrations.length ? 'bg-emerald-50' : 'bg-amber-50'}`}>{okInt === sys.integrations.length ? '✅' : '⚠️'}</div>
              <div><p className="font-bold text-slate-800">{okInt}/{sys.integrations.length} integrations ready</p><p className="text-xs text-slate-500">Storage: {sys.storage === 'file' ? 'local file ⚠️' : 'Postgres ✅'} · up {Math.round(sys.uptimeSec / 3600)}h</p></div></div>
            <div className="space-y-1.5">{sys.integrations.map((i: any) => <div key={i.key} className="flex items-center justify-between text-xs"><span className="text-slate-600">{i.name}</span><span className={`font-bold ${i.ok ? 'text-emerald-600' : 'text-amber-600'}`}>{i.ok ? 'Connected' : 'Not set'}</span></div>)}</div>
          </> : <p className="text-sm text-slate-400">Loading…</p>}
        </div>}
        {role === 'admin' && <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-bold text-slate-800 mb-4">Recent activity</h3>
          <div className="space-y-3 max-h-64 overflow-y-auto">{(logs || []).slice(0, 12).map((l: any) => (
            <div key={l._id} className="flex gap-3 text-xs"><span className="w-2 h-2 rounded-full bg-blue-500 mt-1.5 shrink-0" /><div><p className="font-semibold text-slate-700">{l.action.replace(/_/g, ' ')}</p><p className="text-slate-400">{new Date(l.createdAt).toLocaleString('en-IN')}</p></div></div>))}
            {logs && !logs.length && <p className="text-sm text-slate-400">No activity yet.</p>}</div>
        </div>}
      </div>
    </div>
  );
}

/* ─── Team & Admins ─── */
function Team() {
  const t = useFetch<any[]>('/admin/team'); const [f, setF] = useState<any>({ role: 'moderator' }); const [msg, setMsg] = useState('');
  const add = async (e: React.FormEvent) => { e.preventDefault(); try { setMsg((await api('/admin/team', { body: f })).message); setF({ role: 'moderator' }); t.reload(); } catch (er: any) { setMsg(er.message); } };
  const rm = async (id: string) => { if (!confirm('Remove admin access?')) return; try { await api(`/admin/team/${id}`, { method: 'DELETE' }); t.reload(); } catch (e: any) { alert(e.message); } };
  return (<div className="grid lg:grid-cols-[1fr_380px] gap-6 items-start">
    <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
      <div className="p-5 border-b border-slate-100"><h3 className="font-bold text-slate-800">Team members</h3><p className="text-xs text-slate-500">People who can sign in to this admin console</p></div>
      {t.data?.map((u) => (
        <div key={u._id} className="flex items-center gap-4 px-5 py-4 border-b border-slate-50 last:border-0">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 text-white font-bold flex items-center justify-center">{(u.name || 'A')[0].toUpperCase()}</div>
          <div className="flex-1"><p className="font-semibold text-slate-800">{u.name || 'Unnamed'} {u.superAdmin && <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full ml-1">OWNER</span>}</p><p className="text-xs text-slate-500">+91 {u.phone}{u.email ? ` · ${u.email}` : ''}</p></div>
          <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${u.role === 'admin' ? 'bg-blue-50 text-blue-700' : 'bg-violet-50 text-violet-700'}`}>{u.role === 'admin' ? 'Admin' : 'Moderator'}</span>
          {!u.superAdmin && <button onClick={() => rm(u._id)} className="text-xs text-red-500 hover:underline">Remove</button>}
        </div>))}
    </div>
    <form onSubmit={add} className="bg-white rounded-2xl border border-slate-100 p-5 space-y-3">
      <h3 className="font-bold text-slate-800">Add team member</h3>
      <input required className="input" placeholder="Full name" value={f.name || ''} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <input required className="input" inputMode="numeric" maxLength={10} placeholder="10-digit mobile" value={f.phone || ''} onChange={(e) => setF({ ...f, phone: e.target.value.replace(/\D/g, '') })} />
      <input type="email" className="input" placeholder="Email (optional, for alerts)" value={f.email || ''} onChange={(e) => setF({ ...f, email: e.target.value })} />
      <div className="grid grid-cols-2 gap-2">{[['moderator', 'Moderator', 'Approval queue, reviews, reports, enquiries'], ['admin', 'Admin', 'Full access to everything']].map(([v, l, d]) => (
        <button type="button" key={v} onClick={() => setF({ ...f, role: v })} className={`text-left rounded-xl border p-3 ${f.role === v ? 'border-blue-500 bg-blue-50' : 'border-slate-200'}`}><b className="text-sm">{l}</b><p className="text-[11px] text-slate-500 mt-0.5">{d}</p></button>))}</div>
      <button className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-xl">Add member</button>
      {msg && <p className="text-xs text-slate-600">{msg}</p>}
      <p className="text-[11px] text-slate-400">They sign in at /admin/login with their mobile + OTP.</p>
    </form>
  </div>);
}

/* ─── System & Migrations ─── */
function System() {
  const s = useFetch<any>('/admin/system'); const [msg, setMsg] = useState(''); const [email, setEmail] = useState('');
  const call = async (path: string, body: any = {}) => { try { const r = await api(path, { body }); setMsg(r.message || `Applied: ${(r.applied || []).map((x: any) => x.id).join(', ') || 'nothing pending'}`); s.reload(); } catch (e: any) { setMsg(e.message); } };
  const d = s.data; if (!d) return <div className="animate-pulse grid md:grid-cols-4 gap-4">{[0, 1, 2, 3].map((i) => <div key={i} className="h-24 bg-white rounded-2xl" />)}</div>;
  const pending = d.migrations.filter((m: any) => m.pending).length;
  const up = d.uptimeSec > 86400 ? `${Math.floor(d.uptimeSec / 86400)}d ${Math.floor((d.uptimeSec % 86400) / 3600)}h` : `${Math.floor(d.uptimeSec / 3600)}h ${Math.floor((d.uptimeSec % 3600) / 60)}m`;
  return (<div className="space-y-6">
    {msg && <div className="bg-blue-50 border border-blue-100 text-blue-800 text-sm rounded-xl p-3 flex justify-between">{msg}<button onClick={() => setMsg('')}>✕</button></div>}
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {[['Storage', d.storage === 'file' ? 'Local file' : 'PostgreSQL', d.storage === 'file' ? 'text-amber-600' : 'text-emerald-600'], ['Uptime', up, 'text-slate-900'], ['Memory', `${d.memoryMB} MB`, 'text-slate-900'], ['Node.js', d.node, 'text-slate-900']].map(([l, v, c]) => (
        <div key={l} className="bg-white rounded-2xl border border-slate-100 p-5"><p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{l}</p><p className={`text-xl font-black mt-2 ${c}`}>{v}</p></div>))}
    </div>
    {d.failedWrites > 0 && <div className="bg-red-50 border border-red-200 text-red-800 rounded-2xl p-4 text-sm"><b>⚠️ {d.failedWrites} database write(s) failed</b> since the server started (they were retried). Check the Render logs / Postgres status.</div>}
    {d.storage === 'file' && <div className="bg-red-50 border border-red-200 text-red-800 rounded-2xl p-4 text-sm"><b>⚠️ Data is not persistent.</b> Set <code>DATABASE_URL</code> (Render Postgres) — otherwise all data is lost when the server restarts.</div>}

    <div className="grid lg:grid-cols-2 gap-6">
      <div className="bg-white rounded-2xl border border-slate-100 p-5">
        <h3 className="font-bold text-slate-800 mb-4">Integrations & API keys</h3>
        <div className="space-y-3">{d.integrations.map((i: any) => (
          <div key={i.key} className="flex gap-3 items-start"><span className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm shrink-0 ${i.ok ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>{i.ok ? '✓' : '!'}</span>
            <div className="flex-1"><div className="flex justify-between"><b className="text-sm text-slate-800">{i.name}</b><span className={`text-[11px] font-bold ${i.ok ? 'text-emerald-600' : 'text-amber-600'}`}>{i.ok ? 'Connected' : 'Not configured'}</span></div>{!i.ok && <p className="text-xs text-slate-500 mt-0.5">{i.hint}</p>}</div></div>))}</div>
        <div className="flex gap-2 mt-5 pt-4 border-t border-slate-100"><input className="input" placeholder="Send test email to…" value={email} onChange={(e) => setEmail(e.target.value)} /><button onClick={() => call('/admin/system/test-email', { to: email })} className="bg-slate-900 text-white px-4 rounded-xl text-xs font-bold shrink-0">Test email</button></div>
      </div>
      <div className="bg-white rounded-2xl border border-slate-100 p-5">
        <div className="flex items-center justify-between mb-4"><h3 className="font-bold text-slate-800">Database migrations</h3>
          <button disabled={!pending} onClick={() => call('/admin/system/migrate')} className="bg-blue-600 disabled:bg-slate-200 disabled:text-slate-400 text-white px-4 py-2 rounded-xl text-xs font-bold">{pending ? `Run ${pending} pending` : 'All applied ✓'}</button></div>
        <div className="relative pl-5 space-y-4 before:absolute before:left-[7px] before:top-1 before:bottom-1 before:w-px before:bg-slate-200">
          {d.migrations.map((m: any) => (
            <div key={m.id} className="relative"><span className={`absolute -left-5 top-1 w-3.5 h-3.5 rounded-full ring-4 ring-white ${m.pending ? 'bg-amber-400' : 'bg-emerald-500'}`} />
              <div className="flex justify-between gap-2"><p className="text-sm font-semibold text-slate-800"><span className="font-mono text-xs text-slate-400 mr-2">{m.id}</span>{m.name}</p><span className={`text-[11px] font-bold shrink-0 ${m.pending ? 'text-amber-600' : 'text-emerald-600'}`}>{m.pending ? 'Pending' : 'Applied'}</span></div>
              {!m.pending && <p className="text-xs text-slate-400">{new Date(m.appliedAt).toLocaleString('en-IN')} · {m.result} · {m.ms}ms · by {m.by}</p>}
            </div>))}
        </div>
      </div>
    </div>

    <div className="grid lg:grid-cols-3 gap-6">
      <div className="bg-white rounded-2xl border border-slate-100 p-5 lg:col-span-2">
        <h3 className="font-bold text-slate-800 mb-4">Data overview</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">{Object.entries(d.counts).map(([k, v]: any) => (
          <div key={k} className="rounded-xl bg-slate-50 p-3"><p className="text-lg font-black text-slate-900">{v.toLocaleString('en-IN')}</p><p className="text-[11px] text-slate-500 capitalize">{k}</p></div>))}</div>
      </div>
      <div className="space-y-4">
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-bold text-slate-800 mb-1">Scheduled jobs</h3><p className="text-xs text-slate-500 mb-3">Plan & licence expiry check — every 6 hours</p>
          <p className="text-sm text-slate-700">Last run: <b>{d.jobs.expiry ? new Date(d.jobs.expiry.lastRun).toLocaleString('en-IN') : '—'}</b></p>
          {d.jobs.expiry && <p className="text-xs text-slate-500 mt-1">warned {d.jobs.expiry.result.warned} · downgraded {d.jobs.expiry.result.downgraded} · suspended {d.jobs.expiry.result.suspended}</p>}
          <button onClick={() => call('/admin/run-expiry-job')} className="mt-3 w-full bg-slate-100 hover:bg-slate-200 rounded-xl py-2 text-xs font-bold">Run now</button>
        </div>
        <div className="bg-white rounded-2xl border border-slate-100 p-5">
          <h3 className="font-bold text-slate-800 mb-3">Backup & maintenance</h3>
          <a href={`${API}/api/admin/system/backup?token=${getToken()}`} className="block text-center w-full bg-blue-600 text-white rounded-xl py-2.5 text-xs font-bold mb-3">⬇ Download full backup (JSON)</a>
          <div className="space-y-2">{d.tasks.map((t: any) => <button key={t.id} onClick={() => confirm(`${t.name}?`) && call(`/admin/system/task/${t.id}`)} className="w-full text-left text-xs rounded-xl border border-slate-200 hover:border-blue-300 px-3 py-2">{t.name}</button>)}</div>
        </div>
      </div>
    </div>
  </div>);
}

/* ─── Report / grievance card ─── */
function ReportCard({ r, act }: { r: any; act: (path: string, body: any) => void }) {
  const [reply, setReply] = useState('');
  const complaint = !!r.type; // grievance / issue raised from the Customer Support page (no listing attached)
  return (
    <div className="bg-white rounded-2xl p-5 border border-red-100">
      <div className="flex flex-wrap items-center gap-2"><b className="text-slate-800">{r.businessName}</b>
        <span className="text-[11px] font-bold bg-red-50 text-red-600 px-2 py-0.5 rounded-full">🚩 {r.reason}</span></div>
      <p className="text-sm text-slate-600 mt-2 whitespace-pre-line">{r.details || '—'}</p>
      {r.autoResponse && <p className="text-[11px] text-emerald-700 bg-emerald-50 rounded-lg px-2 py-1 mt-2">✔ Auto-reply sent {new Date(r.autoRepliedAt).toLocaleString('en-IN')}</p>}
      <p className="text-xs text-slate-400 mt-1">by {r.name || 'Customer'} {r.phone && `· +91 ${r.phone}`} · {new Date(r.createdAt).toLocaleString('en-IN')}</p>
      {!complaint && r.businessId && <a href={`/business/${r.businessId}`} target="_blank" className="text-xs text-blue-600 underline">Open listing</a>}
      {complaint && <input value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Reply to customer (required)" className="mt-3 w-full border border-slate-200 rounded-xl px-3 py-2 text-sm" />}
      <div className="flex flex-wrap gap-2 mt-3">
        {complaint ? <button onClick={() => act(`/admin/reports/${r._id}`, { action: 'resolve', response: reply })} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">✔ Resolve & reply</button>
          : <button onClick={() => act(`/admin/reports/${r._id}`, { action: 'suspend' })} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Suspend listing</button>}
        <button onClick={() => act(`/admin/reports/${r._id}`, { action: 'dismiss', response: reply })} className="bg-slate-100 text-slate-600 px-4 py-2 rounded-xl text-xs font-bold">Dismiss</button>
      </div>
    </div>
  );
}

/* ─── Bulk CSV import of pre-loaded (unclaimed) listings ─── */
function parseCSV(text: string) {
  const rows: string[][] = []; let cur: string[] = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (ch === '"') q = false; else cell += ch; }
    else if (ch === '"') q = true; else if (ch === ',') { cur.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; cur.push(cell); cell = ''; if (cur.some((c) => c.trim())) rows.push(cur); cur = []; }
    else cell += ch;
  }
  cur.push(cell); if (cur.some((c) => c.trim())) rows.push(cur);
  const [head, ...body] = rows; const keys = (head || []).map((h) => h.trim());
  return body.map((r) => Object.fromEntries(keys.map((k, i) => [k, (r[i] || '').trim()])));
}
function ImportBtn({ onDone }: { onDone: () => void }) {
  const [res, setRes] = useState<any>(null); const [busy, setBusy] = useState(false);
  const pick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; e.target.value = ''; if (!f) return;
    if (f.size > 1024 * 1024) return alert('File too large (max 1 MB)');
    setBusy(true);
    try { setRes(await api('/admin/import', { body: { rows: parseCSV(await f.text()) } })); onDone(); } catch (er: any) { setRes({ message: er.message, errors: [] }); }
    setBusy(false);
  };
  const tpl = () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['name,category,subCategory,city,address,phone,whatsapp,description,tags,lat,lng\nSri Krishna Cafe,food-dining,Cafes,Udupi,"Car Street, Udupi",9845012345,,Famous masala dosa,dosa;coffee,13.3409,74.7421\n'], { type: 'text/csv' })); a.download = 'pvrs-import-template.csv'; a.click(); };
  return (<>
    <label className="bg-white border border-slate-200 text-slate-700 px-4 py-3 rounded-xl text-sm font-bold cursor-pointer hover:bg-slate-50 shrink-0">{busy ? 'Importing…' : '⬆ Import CSV'}<input type="file" accept=".csv,text/csv" className="hidden" onChange={pick} /></label>
    {res && <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setRes(null)}><div className="bg-white rounded-2xl p-6 max-w-lg w-full max-h-[80vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
      <h3 className="font-bold text-lg mb-1">Import result</h3><p className="text-sm text-slate-700">{res.message}</p>
      {!!res.errors?.length && <ul className="mt-3 text-xs text-red-600 space-y-1 list-disc pl-4">{res.errors.map((x: string) => <li key={x}>{x}</li>)}</ul>}
      <div className="flex gap-2 mt-5"><button onClick={tpl} className="px-4 py-2 rounded-xl bg-slate-100 text-xs font-bold">⬇ Download template</button><button onClick={() => setRes(null)} className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold ml-auto">Close</button></div></div></div>}
    <button onClick={tpl} title="CSV template" className="hidden md:block text-xs text-blue-600 underline shrink-0">Template</button>
  </>);
}

/* ─── Auto-reply settings for grievances / issues ─── */
function AutoReplyPanel() {
  const cfg = useFetch<any>('/admin/auto-reply'); const [f, setF] = useState<any>(null); const [open, setOpen] = useState(false); const [msg, setMsg] = useState('');
  useEffect(() => { if (cfg.data) setF(cfg.data); }, [cfg.data]);
  if (!f) return null;
  const save = async () => { try { setMsg((await api('/admin/auto-reply', { method: 'PUT', body: f })).message); } catch (e: any) { setMsg(e.message); } };
  const run = async () => { try { setMsg((await api('/admin/auto-reply/run', { body: {} })).message); } catch (e: any) { setMsg(e.message); } };
  return (<div className="bg-white rounded-2xl p-5 border border-emerald-100">
    <button onClick={() => setOpen(!open)} className="w-full flex justify-between items-center text-left"><b className="text-slate-800">🤖 Automatic acknowledgement for grievances / issues</b><span className={`text-xs font-bold px-2 py-1 rounded-full ${f.enabled ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>{f.enabled ? `ON · after ${f.delayHours}h` : 'OFF'}</span></button>
    {open && <div className="mt-4 space-y-3">
      <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={f.enabled} onChange={(e) => setF({ ...f, enabled: e.target.checked })} /> Send automatically if no admin reply yet</label>
      <label className="text-sm block">Send after (hours, 0–168)<input type="number" min={0} max={168} value={f.delayHours} onChange={(e) => setF({ ...f, delayHours: e.target.value })} className="ml-2 w-24 border border-slate-200 rounded-lg px-2 py-1" /></label>
      <label className="text-sm block">Message to customer <span className="text-slate-400">(use {'{name}'}, {'{type}'}, {'{ref}'})</span>
        <textarea rows={4} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} className="mt-1 w-full border border-slate-200 rounded-xl px-3 py-2 text-sm" /></label>
      <div className="flex flex-wrap gap-2 items-center"><button onClick={save} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Save</button><button onClick={run} className="bg-slate-100 text-slate-600 px-4 py-2 rounded-xl text-xs font-bold">Send now to overdue items</button>{msg && <span className="text-xs text-slate-600">{msg}</span>}</div>
    </div>}
  </div>);
}
