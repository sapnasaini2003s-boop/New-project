// Data layer with a synchronous in-memory API.
// - If MONGODB_URI is reachable  -> every write is persisted to MongoDB (use MongoDB Atlas free tier in production).
// - Otherwise                     -> persisted to backend/data/db.json (local dev only).
// NOTE: Render/Vercel/Railway free disks are wiped on restart, so production MUST use MongoDB.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const FILE = path.join(__dirname, '..', 'data', 'db.json');
const COLLECTIONS = ['users', 'businesses', 'categories', 'ads', 'payments', 'leads', 'claims', 'offers', 'blogs', 'videos', 'notifications', 'audit', 'reviews', 'enquiries', 'favorites'];

let state = null;
let mongo = null; // { client, db }
const pending = new Set();

function blank() { const s = { settings: {} }; for (const c of COLLECTIONS) s[c] = []; return s; }
function load() {
  if (state) return state;
  state = blank();
  return state;
}

// ---------- persistence ----------
let timer = null;
function saveFile() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    try {
      fs.mkdirSync(path.dirname(FILE), { recursive: true });
      fs.writeFileSync(FILE + '.tmp', JSON.stringify(state, null, 2));
      fs.renameSync(FILE + '.tmp', FILE);
    } catch (e) { console.error('[db] file save failed:', e.message); }
  }, 50);
}
function track(p) { pending.add(p); p.catch((e) => console.error('[db] mongo write failed:', e.message)).finally(() => pending.delete(p)); }
const persist = {
  upsert(c, doc) { if (mongo) track(mongo.db.collection(c).replaceOne({ _id: doc._id }, doc, { upsert: true })); else saveFile(); },
  remove(c, _id) { if (mongo) track(mongo.db.collection(c).deleteOne({ _id })); else saveFile(); },
  settings() { if (mongo) track(mongo.db.collection('settings').replaceOne({ _id: 'site' }, { _id: 'site', ...state.settings }, { upsert: true })); else saveFile(); },
};

async function init() {
  const uri = process.env.MONGODB_URI;
  if (uri) {
    try {
      const { MongoClient } = require('mongodb');
      const client = new MongoClient(uri, { serverSelectionTimeoutMS: 6000 });
      await client.connect();
      const mdb = client.db(process.env.MONGODB_DB || undefined);
      mongo = { client, db: mdb };
      state = blank();
      for (const c of COLLECTIONS) state[c] = await mdb.collection(c).find({}).toArray();
      const s = await mdb.collection('settings').findOne({ _id: 'site' });
      if (s) { delete s._id; state.settings = s; }
      // One-time migration: if Mongo is empty but a local db.json exists, import it
      if (!state.categories.length && fs.existsSync(FILE)) {
        const old = JSON.parse(fs.readFileSync(FILE, 'utf8'));
        for (const c of COLLECTIONS) for (const d of old[c] || []) { state[c].push(d); persist.upsert(c, d); }
        state.settings = old.settings || {}; persist.settings();
        console.log('[db] migrated data/db.json -> MongoDB');
      }
      console.log(`[db] MongoDB connected (${mdb.databaseName}) — data is persistent`);
      return 'mongo';
    } catch (e) {
      console.error(`[db] MongoDB connection failed (${e.message}). Falling back to data/db.json`);
      mongo = null;
    }
  }
  try { const raw = JSON.parse(fs.readFileSync(FILE, 'utf8')); state = blank(); Object.assign(state, raw); for (const c of COLLECTIONS) state[c] = state[c] || []; state.settings = state.settings || {}; }
  catch { state = blank(); }
  console.log('[db] Using local file data/db.json');
  return 'file';
}

const id = (p) => `${p}_${crypto.randomBytes(6).toString('hex')}`;
const now = () => new Date().toISOString();

const db = {
  init,
  mode: () => (mongo ? 'mongo' : 'file'),
  mongo: () => mongo && mongo.db,
  all: (c) => load()[c],
  find: (c, fn) => load()[c].filter(fn),
  get: (c, _id) => load()[c].find((x) => x._id === _id),
  insert(c, doc, prefix = c.slice(0, 3)) {
    const d = { _id: id(prefix), createdAt: now(), updatedAt: now(), ...doc };
    load()[c].push(d); persist.upsert(c, d); return d;
  },
  update(c, _id, patch) {
    const d = db.get(c, _id); if (!d) return null;
    Object.assign(d, patch, { updatedAt: now() }); persist.upsert(c, d); return d;
  },
  remove(c, _id) {
    const s = load(); const i = s[c].findIndex((x) => x._id === _id);
    if (i === -1) return false; s[c].splice(i, 1); persist.remove(c, _id); return true;
  },
  settings: () => load().settings,
  setSettings(patch) { Object.assign(load().settings, patch); persist.settings(); return load().settings; },
  async reset() {
    state = blank();
    if (mongo) { for (const c of [...COLLECTIONS, 'settings']) await mongo.db.collection(c).deleteMany({}); } else saveFile();
  },
  async flush() {
    if (mongo) await Promise.allSettled([...pending]);
    else { clearTimeout(timer); fs.mkdirSync(path.dirname(FILE), { recursive: true }); fs.writeFileSync(FILE, JSON.stringify(load(), null, 2)); }
  },
  isEmpty: () => load().categories.length === 0,
  log(action, by, meta = {}) { db.insert('audit', { action, by, meta }, 'log'); },
};
module.exports = db;
