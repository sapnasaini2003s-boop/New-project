'use client';
import { useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useFetch, useUser } from '@/lib/api';
import BizCard from '@/components/BizCard';
export default function Favorites() {
  const { user, ready } = useUser(); const router = useRouter();
  useEffect(() => { if (ready && !user) router.replace('/login?next=/favorites'); }, [ready, user, router]);
  const { data } = useFetch<any[]>(user ? '/favorites' : null);
  return (<div className="max-w-7xl mx-auto px-3 md:px-4 py-6"><h1 className="text-2xl font-black mb-4">❤️ Saved Businesses</h1>
    {data && !data.length && <div className="card p-10 text-center text-gray-500">Nothing saved yet. <Link href="/" className="text-brand font-semibold">Explore businesses</Link></div>}
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">{data?.map((b) => <BizCard key={b._id} b={b} />)}</div></div>);
}
