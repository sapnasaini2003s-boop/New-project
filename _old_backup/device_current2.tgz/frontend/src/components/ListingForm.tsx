'use client';
import { useState } from 'react';
import { api, img, useFetch } from '@/lib/api';
import MenuEditor, { type MenuCat } from './MenuEditor';
import { HoursPicker, TagInput, defaultHours, summarize, type Hours } from './Hours';

const CITIES = ['Udupi', 'Manipal', 'Malpe', 'Mangaluru', 'Kundapura', 'Karkala'];

export default function ListingForm({ initial, premium, onDone }: { initial?: any; premium?: boolean; onDone: (msg: string) => void }) {
  const { data: cats } = useFetch<any[]>('/categories');
  const v = { ...(initial || {}), ...(initial?.pendingUpdates || {}) };
  const [f, setF] = useState<any>({
    name: v.name || '', category: v.category || '', subCategory: v.subCategory || '', city: v.city || 'Udupi', address: v.address || '',
    description: v.description || '', timings: v.timings || '', tags: (v.tags || []).join(', '),
    phone: v.contact?.phone || '', whatsapp: v.contact?.whatsapp || '', email: v.contact?.email || '',
    swiggy: v.orderOnline?.swiggy || '', zomato: v.orderOnline?.zomato || '',
    youtube: v.videos?.youtube || '', facebook: v.videos?.facebook || '', instagram: v.videos?.instagram || '',
    lat: v.lat ?? '', lng: v.lng ?? '', docType: v.documents?.type || 'Trade License', docNumber: v.documents?.number || '', docExpiry: v.documents?.expiry || '',
  });
  const [files, setFiles] = useState<any>({});
  const [hours, setHours] = useState<Hours>(v.hours || defaultHours());
  const [tags, setTags] = useState<string[]>(v.tags || []);
  const [phones, setPhones] = useState<string[]>(v.contact?.phones || []); const [wapps, setWapps] = useState<string[]>(v.contact?.whatsapps || []); const [emails, setEmails] = useState<string[]>(v.contact?.emails || []);
  const [menu, setMenu] = useState<MenuCat[]>(v.menu || []);
  const [more, setMore] = useState({ landline: v.contact?.landline || '', tollFree: v.contact?.tollFree || '', year: v.info?.year || '', awards: v.info?.awards || '', services: v.info?.services || '', ref: '' });
  const [pay, setPay] = useState<string[]>(v.info?.payments || []);
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const cat = cats?.find((c) => c.slug === f.category);
  const edit = !!initial;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr('');
    if (!edit && !files.document) return setErr('Verification document is mandatory');
    const fd = new FormData();
    ['name', 'category', 'subCategory', 'city', 'address', 'description', 'lat', 'lng', 'docType', 'docNumber', 'docExpiry'].forEach((k) => fd.append(k, f[k]));
    fd.append('hours', JSON.stringify(hours)); fd.append('timings', summarize(hours)); fd.append('tags', tags.join(','));
    const bad = [...phones, ...wapps].find((x) => !/^[6-9]\d{9}$/.test(x)); if (bad) return setErr(`"${bad}" is not a valid 10-digit mobile number`);
    const badE = emails.find((x) => !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(x)); if (badE) return setErr(`"${badE}" is not a valid email`);
    if (more.year && (+more.year < 1900 || +more.year > new Date().getFullYear())) return setErr('Year established looks wrong');
    fd.append('contact', JSON.stringify({ phone: f.phone, whatsapp: f.whatsapp, email: f.email, phones, whatsapps: wapps, emails, landline: more.landline, tollFree: more.tollFree }));
    if (/food|restaurant/.test(f.category)) fd.append('menu', JSON.stringify(menu.map((c) => ({ name: c.name, items: c.items.filter((i) => i.name.trim()).map((i) => ({ ...i, price: Number(i.price) || 0 })) })).filter((c) => c.name.trim() && c.items.length)));
    fd.append('info', JSON.stringify({ year: more.year, payments: pay, awards: more.awards, services: more.services }));
    if (!edit && more.ref) fd.append('ref', more.ref.trim());
    if (/food|restaurant/.test(f.category)) fd.append('orderOnline', JSON.stringify({ swiggy: f.swiggy, zomato: f.zomato }));
    if (premium) { fd.append('videos', JSON.stringify({ youtube: f.youtube, facebook: f.facebook, instagram: f.instagram })); fd.append('keepGallery', JSON.stringify(v.gallery || [])); }
    if (files.profileImage) fd.append('profileImage', files.profileImage[0]);
    if (files.document) fd.append('document', files.document[0]);
    if (premium && files.bannerImage) fd.append('bannerImage', files.bannerImage[0]);
    if (premium && files.gallery) Array.from(files.gallery as FileList).forEach((g) => fd.append('gallery', g));
    setBusy(true);
    try {
      const r = edit ? await api(`/vendor/listings/${initial._id}`, { method: 'PUT', form: fd }) : await api('/vendor/listings', { form: fd });
      onDone(r.message);
    } catch (e: any) { setErr(e.message); }
    setBusy(false);
  };
  // Phone photos are often 5-10 MB: shrink images in the browser (max 1600px, JPEG) before upload
  const shrink = async (list: FileList | null) => {
    if (!list) return list;
    const out = new DataTransfer();
    for (const file of Array.from(list)) {
      if (!file.type.startsWith('image/') || file.size < 800 * 1024) { out.items.add(file); continue; }
      try {
        const bmp = await createImageBitmap(file); const s = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
        const c = document.createElement('canvas'); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
        c.getContext('2d')!.drawImage(bmp, 0, 0, c.width, c.height);
        const blob: Blob | null = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.82));
        out.items.add(blob && blob.size < file.size ? new File([blob], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file);
      } catch { out.items.add(file); }
    }
    return out.files;
  };
  const useMyLocation = () => navigator.geolocation?.getCurrentPosition(
    (p) => setF((x: any) => ({ ...x, lat: p.coords.latitude.toFixed(6), lng: p.coords.longitude.toFixed(6) })),
    () => setErr('Location permission denied — you can leave this blank'), { timeout: 8000 });
  const file = (k: string, multiple = false, accept = '.jpg,.jpeg,.png,.webp', isReq = false) => (
    <input type="file" required={isReq} accept={accept} multiple={multiple} className="input" onChange={async (e) => { const l = e.target.files; setFiles({ ...files, [k]: k === 'document' ? l : await shrink(l) }); }} />
  );

  return (
    <form onSubmit={submit} className="space-y-5">
      <section className="card p-4 md:p-6 grid md:grid-cols-2 gap-4">
        <h2 className="md:col-span-2 font-bold">Business details</h2>
        <div className="md:col-span-2"><label className="label">Business name *</label><input required className="input" value={f.name} onChange={set('name')} /></div>
        <div><label className="label">Category *</label>
          <select required className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value, subCategory: '' })}>
            <option value="">Select</option>{cats?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select></div>
        <div><label className="label">Sub-category *</label>
          <select required className="input" value={f.subCategory} onChange={set('subCategory')}>
            <option value="">Select</option>{cat?.subs.map((s: string) => <option key={s}>{s}</option>)}
          </select></div>
        <div><label className="label">City *</label><select className="input" value={f.city} onChange={set('city')}>{CITIES.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label className="label">Address</label><input className="input" value={f.address} onChange={set('address')} /></div>
        <div className="md:col-span-2"><label className="label">Map location <span className="font-normal text-gray-400">— optional, enables “Nearest first” for customers</span></label>
          <div className="flex flex-wrap gap-2"><input className="input !w-36" inputMode="decimal" placeholder="Latitude" value={f.lat} onChange={set('lat')} /><input className="input !w-36" inputMode="decimal" placeholder="Longitude" value={f.lng} onChange={set('lng')} />
            <button type="button" onClick={useMyLocation} className="btn btn-ghost !text-xs">📍 Use my current location</button></div></div>
        <div className="md:col-span-2"><label className="label">Description</label><textarea rows={3} className="input" value={f.description} onChange={set('description')} /></div>
        <div className="md:col-span-2"><label className="label">Business hours <span className="font-normal text-gray-400">— set each day, tap the clock to pick a time</span></label><HoursPicker value={hours} onChange={setHours} />
          <p className="text-xs text-gray-500 mt-1.5">Shown as: {summarize(hours)}</p></div>
        <div className="md:col-span-2"><label className="label">Keywords <span className="font-normal text-gray-400">— press Enter or comma after each (helps customers find you)</span></label><TagInput value={tags} onChange={setTags} placeholder="e.g. dosa, south indian, family restaurant" /></div>
      </section>

      <section className="card p-4 md:p-6 grid md:grid-cols-3 gap-4">
        <h2 className="md:col-span-3 font-bold">Contact <span className="text-xs font-normal text-gray-500">(Call/WhatsApp buttons show publicly only on Premium plan)</span></h2>
        <div><label className="label">Phone</label><input type="tel" pattern="[0-9]{10}" title="10 digit mobile number" className="input" maxLength={10} value={f.phone} onChange={set('phone')} /></div>
        <div><label className="label">WhatsApp</label><input type="tel" pattern="[0-9]{10}" title="10 digit mobile number" className="input" maxLength={10} value={f.whatsapp} onChange={set('whatsapp')} /></div>
        <div><label className="label">Email *</label><input type="email" required className="input" value={f.email} onChange={set('email')} /></div>
        <div className="md:col-span-3 font-semibold text-sm pt-2">📞 More ways to reach you <span className="font-normal text-xs text-gray-500">(max 3 each · shown on Premium listings)</span></div>
        <div><label className="label">Backup / extra mobile numbers</label><TagInput value={phones} onChange={(x) => setPhones(x.map((s) => s.replace(/\D/g, '').slice(-10)).slice(0, 3))} placeholder="10-digit mobile, press Enter" /></div>
        <div><label className="label">Extra WhatsApp numbers</label><TagInput value={wapps} onChange={(x) => setWapps(x.map((s) => s.replace(/\D/g, '').slice(-10)).slice(0, 3))} placeholder="10-digit mobile, press Enter" /></div>
        <div><label className="label">Extra emails</label><TagInput value={emails} onChange={(x) => setEmails(x.slice(0, 3))} placeholder="name@example.com, press Enter" /></div>
        <div><label className="label">Landline</label><input className="input" placeholder="0820-2522222" pattern="\d{2,5}[- ]?\d{6,8}" title="e.g. 0820-2522222" value={more.landline} onChange={(e) => setMore({ ...more, landline: e.target.value })} /></div>
        <div><label className="label">Toll-free</label><input className="input" placeholder="1800-123-4567" pattern="1800[- ]?\d{3}[- ]?\d{3,4}" title="e.g. 1800-123-4567" value={more.tollFree} onChange={(e) => setMore({ ...more, tollFree: e.target.value })} /></div>
        {/food|restaurant/.test(f.category) && (<>
          <div className="md:col-span-3 font-semibold text-sm">🛵 Order Online links</div>
          <div><label className="label">Swiggy URL</label><input type="url" placeholder="https://" className="input" value={f.swiggy} onChange={set('swiggy')} /></div>
          <div><label className="label">Zomato URL</label><input type="url" placeholder="https://" className="input" value={f.zomato} onChange={set('zomato')} /></div>
        </>)}
      </section>

      {/food|restaurant/.test(f.category) && <section className="card p-4 md:p-6"><h2 className="font-bold">Order Online Menu <span className="text-xs font-normal text-gray-500">(optional — shown on a Menu tab)</span></h2><div className="mt-3"><MenuEditor value={menu} onChange={setMenu} /></div></section>}
      <section className="card p-4 md:p-6 grid md:grid-cols-2 gap-4">
        <h2 className="md:col-span-2 font-bold">Additional business info <span className="text-xs font-normal text-gray-500">(optional)</span></h2>
        <div><label className="label">Year established</label><input type="number" min={1900} max={new Date().getFullYear()} className="input" value={more.year} onChange={(e) => setMore({ ...more, year: e.target.value })} /></div>
        <div><label className="label">Payment modes accepted</label><div className="flex flex-wrap gap-2">{['Cash', 'UPI', 'Debit Card', 'Credit Card', 'Net Banking', 'Cheque'].map((p) => <button type="button" key={p} onClick={() => setPay(pay.includes(p) ? pay.filter((x) => x !== p) : [...pay, p])} className={`rounded-full border px-3 py-1 text-xs ${pay.includes(p) ? 'bg-brand text-white border-brand' : 'bg-white'}`}>{p}</button>)}</div></div>
        <div className="md:col-span-2"><label className="label">Services / specialities</label><input className="input" maxLength={300} value={more.services} onChange={(e) => setMore({ ...more, services: e.target.value })} /></div>
        <div className="md:col-span-2"><label className="label">Awards & certificates</label><input className="input" maxLength={300} value={more.awards} onChange={(e) => setMore({ ...more, awards: e.target.value })} /></div>
        {!edit && <div><label className="label">Referral code <span className="font-normal text-gray-400">(if a PVRS partner referred you)</span></label><input className="input uppercase" maxLength={12} value={more.ref} onChange={(e) => setMore({ ...more, ref: e.target.value.toUpperCase() })} /></div>}
      </section>

      <section className="card p-4 md:p-6 grid md:grid-cols-2 gap-4">
        <h2 className="md:col-span-2 font-bold">Media</h2>
        <div><label className="label">Profile image / logo (1 image) {!edit && '*'}</label>{v.profileImage && <img src={img(v.profileImage)} alt="" className="h-16 mb-2 rounded" />}{file('profileImage', false, '.jpg,.jpeg,.png,.webp', !edit)}</div>
        <div className={premium ? '' : 'opacity-50'}>
          <label className="label">Gallery images {!premium && '🔒 Premium'}</label>
          {premium ? file('gallery', true) : <p className="text-xs text-gray-500">Free plan allows only one profile image. Upgrade for gallery, header banner & videos.</p>}
        </div>
        {premium && (<>
          <div><label className="label">Header banner image</label>{file('bannerImage')}</div>
          <div><label className="label">YouTube video URL</label><input type="url" placeholder="https://" className="input" value={f.youtube} onChange={set('youtube')} /></div>
          <div><label className="label">Facebook Watch URL</label><input type="url" placeholder="https://" className="input" value={f.facebook} onChange={set('facebook')} /></div>
          <div><label className="label">Instagram Reel URL</label><input type="url" placeholder="https://" className="input" value={f.instagram} onChange={set('instagram')} /></div>
        </>)}
      </section>

      <section className="card p-4 md:p-6 grid md:grid-cols-2 gap-4 border-brand">
        <h2 className="md:col-span-2 font-bold">Upload Trade License / FSSAI / KMC Registration Certificate {!edit && '*'}</h2>
        <div><label className="label">Document type *</label>
          <select required className="input" value={f.docType} onChange={set('docType')}>{['Trade License', 'FSSAI', 'KMC Registration Certificate', 'Other Govt. Registration'].map((d) => <option key={d}>{d}</option>)}</select></div>
        <div><label className="label">Certificate number *</label><input required className="input" value={f.docNumber} onChange={set('docNumber')} /></div>
        <div><label className="label">Valid till (expiry date) *</label><input required type="date" className="input" value={f.docExpiry?.slice(0, 10)} onChange={set('docExpiry')} /></div>
        <div><label className="label">File (JPG, PNG or PDF, max 5MB) {!edit && '*'}</label>{file('document', false, '.jpg,.jpeg,.png,.pdf', !edit)}</div>
      </section>

      {err && <p className="text-red-600 text-sm font-medium">{err}</p>}
      <p className="text-xs text-gray-500">By submitting you accept the Business Terms of Use. All new listings and edits are reviewed by our admin before going live.</p>
      <button disabled={busy} className="btn btn-accent w-full md:w-auto">{busy ? 'Submitting…' : edit ? 'Submit changes for review' : 'Submit for verification'}</button>
    </form>
  );
}
