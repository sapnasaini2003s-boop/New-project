'use client';
import { useState } from 'react';
import { img, ytThumb } from '@/lib/api';
import { E } from '@/components/Icon';
import Banner from '@/components/Banner';
import VideoModal from '@/components/VideoModal';
const LABEL: Record<string, string> = { top_banner: 'Top banner (home, above hero)', middle_banner: 'Middle banner (home)', category_banner: 'Category page banner', promo: 'Promotional widget (home slider)', hero_video: 'Hero video ad (home)', offers_banner: 'Offers page header', videos_banner: 'Videos page header' };
// Admin: see exactly what a vendor's ad will look like (and play its video / open its link) before approving it.
export default function AdPreview({ ad, onClose }: { ad: any; onClose: () => void }) {
  const [play, setPlay] = useState<string | null>(null);
  const vid = ad.youtubeUrl || (ad.type === 'hero_video' ? ad.link : '');
  const isVideo = ad.type === 'hero_video' || !!ad.youtubeUrl;
  const row = (k: string, v: any) => v ? <div className="flex gap-2 text-sm"><span className="w-24 shrink-0 text-slate-400">{k}</span><span className="min-w-0 break-all text-slate-800">{v}</span></div> : null;
  const link = (u?: string) => u ? <a href={u.startsWith('http') ? u : '#'} target="_blank" rel="noreferrer" className="text-blue-600 underline">{u}</a> : null;
  return (<div className="fixed inset-0 z-50 bg-black/60 flex items-end md:items-center justify-center" onClick={onClose}>
    <div className="bg-white w-full md:max-w-2xl rounded-t-2xl md:rounded-2xl max-h-[92vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
      <div className="sticky top-0 bg-white px-4 py-3 border-b flex justify-between items-center z-10"><b>Preview — as it will appear live</b><button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100" aria-label="Close"><E c="✕" /></button></div>
      <div className="p-4 space-y-4">
        <div className="rounded-xl bg-slate-50 border p-3 pointer-events-none-parent">
          {isVideo ? (
            <button type="button" onClick={() => setPlay(vid)} className="relative block w-full max-w-sm mx-auto aspect-video rounded-2xl overflow-hidden shadow-md bg-slate-800 group">
              {ytThumb(vid) ? <img src={ytThumb(vid)} alt="" className="absolute inset-0 w-full h-full object-cover" /> : ad.image ? <img src={img(ad.image)} alt="" className="absolute inset-0 w-full h-full object-cover" /> : <span className="absolute inset-0 bg-gradient-to-br from-fuchsia-600 via-rose-500 to-amber-400" />}
              <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
              <span className="absolute inset-0 flex items-center justify-center"><span className="w-12 h-12 rounded-full bg-white/90 text-brand flex items-center justify-center pl-0.5"><E c="▶" /></span></span>
              <span className="absolute bottom-0 inset-x-0 p-3 text-white text-left"><b className="block text-sm line-clamp-1">{ad.title || 'Watch video'}</b>{ad.subtitle && <span className="text-xs text-white/80 line-clamp-1">{ad.subtitle}</span>}</span>
              <span className="absolute top-2 left-2 text-[9px] font-bold bg-black/50 text-white rounded px-1.5 py-0.5">AD</span>
            </button>
          ) : <div className="pointer-events-none"><Banner ads={[ad]} h="min-h-28" /></div>}
          {isVideo && <p className="text-center text-xs text-slate-500 mt-2">Tap the card to play the video</p>}
        </div>
        <div className="space-y-1.5">
          {row('Slot', LABEL[ad.type] || ad.type)}{row('Title', ad.title)}{row('Subtitle', ad.subtitle)}{row('Button', ad.cta)}
          {row('Link', link(ad.link))}{row('Video', link(ad.youtubeUrl))}
          {row('Duration', ad.days ? `${ad.days} days` : '')}{row('Dates', ad.startDate || ad.endDate ? `${ad.startDate?.slice(0, 10) || '—'} → ${ad.endDate?.slice(0, 10) || '—'}` : '')}
          {row('Paid', ad.amount ? `₹${ad.amount} (${ad.paymentStatus})` : '')}{row('By', ad.createdBy)}
        </div>
        {ad.image && <a href={img(ad.image)} target="_blank" rel="noreferrer" className="text-xs text-blue-600 underline block">Open full-size image ↗</a>}
      </div>
    </div>
    <VideoModal url={play} onClose={() => setPlay(null)} />
  </div>);
}
