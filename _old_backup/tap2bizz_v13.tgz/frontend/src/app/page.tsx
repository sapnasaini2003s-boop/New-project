'use client';
import { E, CatIcon } from '@/components/Icon';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useFetch, img, ytThumb, getCity } from '@/lib/api';
import BizCard from '@/components/BizCard';
import VideoModal from '@/components/VideoModal';

function Banner({ ads, h = 'min-h-24 md:min-h-28' }: { ads: any[]; h?: string }) {
  const [i, setI] = useState(0);
  useEffect(() => { if (ads.length < 2) return; const t = setInterval(() => setI((x) => (x + 1) % ads.length), 4000); return () => clearInterval(t); }, [ads.length]);
  if (!ads.length) return (
    <Link href="/advertise" className={`${h} rounded-xl border-2 border-dashed border-accent/50 bg-orange-50 flex items-center justify-center text-accent font-bold`}>Ad Space 970×90 — Book this slot</Link>
  );
  const a = ads[i % ads.length];
  return (
    <div className="relative">
      <Link href={a.link || '#'} className={`${h} rounded-xl overflow-hidden flex items-center justify-between px-4 md:px-10 py-3 pb-5 gap-3 text-white shadow`}
        style={{ background: a.image ? `url(${img(a.image)}) center/cover` : a.bg || 'linear-gradient(90deg,#0033aa,#0055FF)' }}>
        <div className={`min-w-0 ${a.image ? 'bg-black/40 p-2 rounded' : ''}`}>
          <h3 className="font-black text-base md:text-2xl tracking-wide line-clamp-2" style={{ color: a.bg?.includes('#eff6ff') ? '#0b1b3f' : undefined }}>{a.title}</h3>
          <p className="text-xs md:text-sm opacity-90 line-clamp-2" style={{ color: a.bg?.includes('#eff6ff') ? '#0055FF' : undefined }}>{a.subtitle}</p>
        </div>
        {!a.image && a.thumb && <img src={img(a.thumb)} alt="" loading="lazy" className="ml-auto w-20 h-14 md:w-44 md:h-20 rounded-lg object-cover shadow-md border border-white/40 shrink-0" onError={(e) => { e.currentTarget.style.display = 'none'; }} />}
        {a.cta && <span className="btn btn-accent !text-xs md:!text-sm shrink-0">{a.cta}</span>}
      </Link>
      {ads.length > 1 && <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 flex gap-1">{ads.map((_, k) => <span key={k} className={`w-1.5 h-1.5 rounded-full ${k === i % ads.length ? 'bg-white' : 'bg-white/50'}`} />)}</div>}
    </div>
  );
}


function PromoCarousel({ ads }: { ads: any[] }) {
  const [i, setI] = useState(0);
  useEffect(() => { if (ads.length < 2) return; const t = setInterval(() => setI((x) => (x + 1) % ads.length), 4000); return () => clearInterval(t); }, [ads.length]);
  if (!ads.length) return <Link href="/advertise" className="rounded-2xl min-h-[200px] p-6 flex flex-col justify-end bg-gradient-to-br from-[#0b3bd1] to-[#3b82f6] text-white"><b className="text-xl">Promote your business here</b><span className="text-sm text-blue-100">Promo widget · book from dashboard</span><span className="btn bg-white text-brand w-fit mt-3 !text-xs">Advertise</span></Link>;
  const a = ads[i % ads.length];
  return (
    <div className="relative h-full min-h-[200px]">
      <Link href={a.link || '#'} className="absolute inset-0 rounded-2xl overflow-hidden bg-gradient-to-br from-[#0b3bd1] to-[#2f6bff] text-white p-6 flex flex-col justify-center">
        {a.image && <img src={img(a.image)} alt="" className="absolute right-0 top-0 h-full w-3/5 object-cover [mask-image:linear-gradient(to_right,transparent,black_45%)]" />}
        <div className="relative z-10 max-w-[62%]">
          <h3 className="text-xl md:text-2xl font-black leading-tight line-clamp-2">{a.title}</h3>
          <p className="text-xs md:text-sm text-blue-100 line-clamp-2 mt-1.5">{a.subtitle}</p>
          <span className="btn btn-accent w-fit mt-4 !text-xs">{a.cta || 'EXPLORE NOW'}</span>
        </div>
      </Link>
      {ads.length > 1 && <div className="absolute bottom-3 left-6 flex gap-1 z-20">{ads.map((_, k) => <span key={k} className={`w-1.5 h-1.5 rounded-full ${k === i % ads.length ? 'bg-white' : 'bg-white/40'}`} />)}</div>}
    </div>
  );
}

export default function Home() {
  const router = useRouter();
  const [city, setCity] = useState('Udupi');
  useEffect(() => { setCity(getCity()); const f = () => setCity(getCity()); window.addEventListener('pvrs-city', f); return () => window.removeEventListener('pvrs-city', f); }, []);
  const { data: home } = useFetch<any>('/home');
  const { data: cats } = useFetch<any[]>('/categories');
  const { data: featured } = useFetch<any[]>('/featured');
  const [tab, setTab] = useState('Businesses');
  const [q, setQ] = useState('');
  const [video, setVideo] = useState<string | null>(null);
  const s = home?.settings || {}; const ads = home?.ads || {};
  const heroVid = ads.heroVideo?.[0];
  const cityList: string[] = (home?.settings?.cities as string[] | undefined)?.length ? home!.settings.cities : ['Udupi', 'Manipal', 'Malpe', 'Mangaluru', 'Kundapura', 'Karkala'];
  const setCityTo = (ct: string) => { try { localStorage.setItem('pvrs_city', ct); } catch { /* ignore */ } window.dispatchEvent(new Event('pvrs-city')); };
  const go = (e: React.FormEvent) => { e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}&city=${city}&type=${tab}`); };
  const heroTitle: string = s.hero?.title || 'Find Local Businesses Near You'; const tm = heroTitle.match(/^(.*?)(\s*\S+\s+\S+)$/); const t1 = tm ? tm[1] : heroTitle; const t2 = tm ? tm[2].trim() : '';
  const pills = (cats || []).flatMap((c: any) => c.subs.slice(0, 2).map((sub: string) => ({ sub, c })));

  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4">
      {/* Mobile sticky category ribbon */}
      <div className="md:hidden sticky top-[104px] z-30 bg-[#f5f7fb] -mx-3 px-3 py-2 flex gap-3 overflow-x-auto no-scrollbar">
        {(cats || []).map((c: any) => (
          <a key={c._id} href={`#cat-${c.slug}`} className="flex flex-col items-center min-w-[64px] text-[10px] font-medium text-gray-700">
            <span className="w-11 h-11 rounded-xl bg-white border flex items-center justify-center text-xl" style={{ color: c.color }}><CatIcon icon={c.icon} name={c.name} /></span>
            <span className="text-center leading-tight mt-1">{c.name.split(' ')[0]}</span>
          </a>
        ))}
      </div>

      {/* 2. Top banner carousel */}
      <section className="mt-3 md:hidden"><Banner ads={ads.top || []} /></section>

      {/* 3. Hero search + 4. hero video ad */}
      <section 
        className="mt-4 rounded-xl overflow-hidden relative text-white md:hidden"
        style={{
          background: `url('https://images.unsplash.com/photo-1601058268499-e52658b8ebf8?q=80&w=2000&auto=format&fit=crop') center/cover no-repeat`
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#00267a] via-[#0033aada] to-transparent"></div>
        <div className="relative z-10 p-4 md:p-12 grid grid-cols-1 md:grid-cols-5 gap-4 md:gap-8 items-center">
          <div className="md:col-span-3 min-w-0">
            <h1 className="text-2xl md:text-5xl font-extrabold leading-tight tracking-tight drop-shadow-lg">{s.hero?.title || 'Find Local Businesses Near You'}</h1>
            <p className="text-blue-50 mt-1.5 md:mt-3 text-xs md:text-base font-medium drop-shadow">{s.hero?.subtitle || 'Search. Connect. Grow. Udupi | Mangaluru | Beyond.'}</p>
            <form onSubmit={(e) => { e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}&city=${city}&type=${tab}`); }} className="md:hidden mt-3 bg-white rounded-xl p-1.5 flex items-center gap-1 shadow-xl"><span className="px-2 text-gray-500"><E c="🔍"/></span><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search businesses, services…" className="flex-1 min-w-0 text-gray-800 text-sm outline-none" /><button className="bg-brand text-white px-4 py-2 rounded-lg text-sm font-bold">Search</button></form>
            <div className="hidden md:block mt-8">
              <div className="flex gap-1 border-b border-white/20">
                {['Businesses', 'Products', 'Services'].map((t) => (
                  <button key={t} onClick={() => setTab(t)} className={`px-5 py-2.5 rounded-t-lg text-sm font-bold tracking-wide flex items-center gap-2 ${tab === t ? 'bg-white text-brand' : 'bg-black/30 hover:bg-black/50 text-white'}`}>
                    <E c={t === 'Businesses' ? '🏪' : t === 'Products' ? '🛍️' : '🔧'} /> {t}
                  </button>
                ))}
              </div>
              <form onSubmit={(e) => { e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}&city=${city}&type=${tab}`); }} className="bg-white p-2 rounded-b-lg rounded-tr-lg flex gap-2 shadow-2xl">
                <div className="flex items-center text-gray-500 px-3"><span className="text-lg"><E c="🔍"/></span></div>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="What are you looking for?" className="flex-1 text-gray-800 px-2 outline-none font-medium" />
                <div className="w-px bg-gray-200 my-2 mx-2"></div>
                <div className="flex items-center text-gray-500 px-2"><span className="text-brand"><E c="📍"/></span> {city}</div>
                <button className="bg-brand hover:bg-brand-dark text-white px-8 py-3 rounded-md font-bold transition">Search</button>
              </form>
            </div>
            <div className="mt-3 md:mt-5 flex md:flex-wrap gap-2 text-xs items-center overflow-x-auto no-scrollbar -mx-4 px-4 md:mx-0 md:px-0">
              <span className="text-white/80 font-medium tracking-wide shrink-0 hidden md:inline">Popular Searches:</span>
              {['Restaurant', 'Hospitals', 'Hotels', 'Salons', 'Builders', 'Car Service'].map((p: string) => <Link key={p} href={`/search?q=${encodeURIComponent(p)}`} className="border border-white/40 rounded-full px-3 py-1.5 hover:bg-white hover:text-brand bg-black/20 backdrop-blur-sm transition shrink-0">{p}</Link>)}
            </div>
          </div>
          <div className="md:col-span-2 hidden md:flex justify-end">
            {heroVid && (
              <button onClick={() => setVideo(heroVid.youtubeUrl)} className="relative w-full max-w-[320px] rounded-xl overflow-hidden aspect-[4/3] border-4 border-white/20 shadow-2xl group">
                {ytThumb(heroVid.youtubeUrl) ? <img src={ytThumb(heroVid.youtubeUrl)} alt="" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-500" /> : <div className="absolute inset-0 bg-blue-900"></div>}
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition"></div>
                <span className="absolute inset-0 flex items-center justify-center"><span className="w-14 h-14 rounded-full bg-black/70 flex items-center justify-center text-white text-2xl pl-1 ring-4 ring-white/30 group-hover:bg-brand transition"><E c="▶"/></span></span>
                <span className="absolute bottom-0 inset-x-0 p-4 pb-3 text-left bg-gradient-to-t from-black via-black/80 to-transparent">
                  <h4 className="font-bold text-white text-sm line-clamp-1">{heroVid.title || 'Discover Udupi & Mangaluru'}</h4>
                  <div className="flex justify-between items-end mt-1">
                     <span className="text-xs text-gray-300">A City of Opportunities</span>
                     <span className="text-[10px] font-bold uppercase tracking-wider text-white">Watch Video ⊕</span>
                  </div>
                </span>
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Desktop hero (light) */}
      <section className="hidden md:block mt-5 rounded-3xl overflow-hidden relative bg-gradient-to-br from-white via-[#eef4ff] to-[#d9e6ff] border border-blue-100 shadow-sm">
        <div className="absolute -right-24 -top-24 w-[420px] h-[420px] rounded-full bg-blue-200/30" /><div className="absolute left-1/3 -bottom-32 w-[360px] h-[360px] rounded-full bg-white/60" />
        <div className="relative grid grid-cols-5 gap-8 px-8 py-7 lg:px-12 lg:py-8 items-center">
          <div className="col-span-3 min-w-0">
            <h1 className="font-display text-3xl lg:text-[42px] !font-medium leading-[1.15] tracking-tight text-[#0b1b3f]">{t1}{t2 && <><br /><span className="text-brand">{t2}</span></>}</h1>
            <p className="text-slate-600 mt-2.5 text-base">{s.hero?.subtitle || 'Search. Connect. Grow. Udupi | Mangaluru | Beyond.'}</p>
            <div className="mt-5 flex gap-1 pl-1">{['Businesses', 'Products', 'Services'].map((x) => (
              <button key={x} onClick={() => setTab(x)} className={`px-4 py-2 rounded-t-xl text-[13px] font-semibold flex items-center gap-2 transition ${tab === x ? 'bg-white text-brand shadow-[0_-4px_14px_rgba(0,85,255,.08)]' : 'text-slate-500 hover:text-brand'}`}><E c={x === 'Businesses' ? '🏪' : x === 'Products' ? '🛍️' : '🔧'} /> {x}</button>))}</div>
            <form onSubmit={go} className="bg-white rounded-2xl rounded-tl-none p-2 flex items-center gap-2 shadow-xl shadow-blue-900/10 border border-blue-50">
              <span className="pl-3 text-slate-400"><E c="🔍" /></span>
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="What are you looking for?" className="flex-1 min-w-0 px-2 py-2.5 outline-none text-slate-800 placeholder:text-slate-400" />
              <span className="w-px h-8 bg-slate-200" />
              <label className="flex items-center gap-1.5 px-3 text-slate-700 font-medium text-sm"><span className="text-brand"><E c="📍" /></span><select value={city} onChange={(e) => setCityTo(e.target.value)} className="bg-transparent outline-none cursor-pointer">{cityList.map((ct) => <option key={ct}>{ct}</option>)}</select></label>
              <button className="bg-brand hover:bg-brand-dark text-white px-8 py-3 rounded-xl font-bold transition shadow-lg shadow-blue-600/25">Search</button>
            </form>
            <div className="mt-4 flex gap-2 items-center text-[13px] overflow-hidden"><span className="text-slate-500 font-medium shrink-0">Popular:</span>
              {((s.popularSearches as string[] | undefined)?.length ? s.popularSearches : ['Restaurant', 'Hospitals', 'Hotels', 'Salons', 'Car Service']).slice(0, 4).map((p: string) => <Link key={p} href={`/search?q=${encodeURIComponent(p)}`} className="shrink-0 px-3 py-1 rounded-full bg-white border border-slate-200 text-slate-600 hover:border-brand hover:text-brand transition">{p}</Link>)}</div>
          </div>
          <div className="col-span-2 flex justify-end pr-2">
            {heroVid ? (
              <button onClick={() => setVideo(heroVid.youtubeUrl)} className="relative w-full max-w-[330px] aspect-[16/10] rounded-3xl overflow-hidden shadow-2xl shadow-blue-900/25 ring-4 ring-white group text-left">
                {ytThumb(heroVid.youtubeUrl) ? <img src={ytThumb(heroVid.youtubeUrl)} alt="" className="absolute inset-0 w-full h-full object-cover scale-[1.35] group-hover:scale-[1.42] transition duration-700" /> : <div className="absolute inset-0 bg-gradient-to-br from-blue-700 to-blue-900" />}
                <span className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-black/10" />
                <span className="absolute inset-0 flex items-center justify-center"><span className="w-14 h-14 rounded-full bg-black/60 backdrop-blur flex items-center justify-center text-white text-2xl pl-1 ring-4 ring-white/70 group-hover:bg-brand transition"><E c="▶" /></span></span>
                <span className="absolute bottom-0 inset-x-0 p-3.5 flex items-end justify-between gap-2 text-white"><span><b className="block text-sm leading-tight">{heroVid.title || 'Discover Udupi & Mangaluru'}</b><span className="text-xs text-white/80">A City of Opportunities</span></span><span className="shrink-0 text-[11px] font-bold border border-white/70 rounded-full px-2.5 py-1 bg-black/30">Watch</span></span>
              </button>
            ) : (
              <Link href="/advertise" className="w-full max-w-[330px] aspect-[16/10] rounded-3xl bg-gradient-to-br from-brand to-[#3b82f6] text-white p-8 flex flex-col justify-end shadow-2xl shadow-blue-900/25 ring-4 ring-white"><b className="text-2xl leading-tight">Your video ad here</b><span className="text-sm text-blue-100 mt-1">Reach thousands of local customers on the home page.</span><span className="btn bg-white text-brand w-fit mt-4">Book now</span></Link>
            )}
          </div>
        </div>
      </section>
      {!!(ads.top || []).length && <section className="hidden md:block mt-5"><Banner ads={ads.top} /></section>}

      {/* 5. Top categories — tile grid */}
      <section className="mt-6">
        <div className="flex justify-between items-end mb-3">
          <div><h2 className="font-black text-lg md:text-xl text-[#0b1b3f]">Browse Categories</h2><p className="text-xs text-gray-500">Trusted local services in {city}</p></div>
          <Link href="/categories" className="text-brand text-sm font-bold hover:underline">View all →</Link>
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-2 md:gap-3">
          {(cats || []).map((c: any) => (
            <Link key={c._id} href={`/category/${c.slug}`} className="group bg-white rounded-2xl border border-gray-100 shadow-sm p-2.5 md:p-3 flex flex-col items-center text-center hover:border-brand/40 hover:shadow-lg hover:-translate-y-0.5 transition">
              <span className="w-11 h-11 md:w-14 md:h-14 rounded-xl flex items-center justify-center text-2xl md:text-3xl" style={{ background: c.color + '14', color: c.color }}><CatIcon icon={c.icon} name={c.name} /></span>
              <span className="text-xs md:text-sm font-semibold mt-2 leading-tight text-gray-700 group-hover:text-brand line-clamp-2">{c.name}</span>
            </Link>
          ))}
          <Link href="/categories" className="group bg-white rounded-xl border border-dashed border-gray-300 p-2.5 md:p-3 flex flex-col items-center justify-center text-center hover:border-brand">
            <span className="w-11 h-11 md:w-14 md:h-14 rounded-xl flex items-center justify-center text-xl bg-gray-50 text-gray-500">•••</span>
            <span className="text-xs md:text-sm font-semibold mt-2 text-gray-600 group-hover:text-brand">More</span>
          </Link>
        </div>
        {/* Mobile: 2-column capsule pills (spec) */}
        <div className="md:hidden grid grid-cols-2 gap-2 mt-3">
          {pills.slice(0, 10).map(({ sub, c }: any) => (
            <Link key={c.slug + sub} href={`/category/${c.slug}?sub=${encodeURIComponent(sub)}`} className="flex items-center gap-2 rounded-full border border-gray-200 bg-white px-3 py-2 text-xs font-medium text-gray-700">
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: c.color }} /><span className="truncate">{sub}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* 6. Promo ad + 7. Featured videos */}
      <section className="grid md:grid-cols-3 gap-4 mt-5">
        <PromoCarousel ads={ads.promo || []} />
        <div className="card p-4 md:col-span-2 min-w-0">
          <div className="flex justify-between mb-3"><h2 className="font-bold">Featured Videos</h2><Link href="/videos" className="text-brand text-sm font-semibold">View All →</Link></div>
          <div className="flex md:grid md:grid-cols-4 gap-3 md:gap-4 overflow-x-auto no-scrollbar snap-x snap-mandatory items-start scroll-px-0">
            {(home?.videos || []).map((v: any) => (
              <button key={v._id} onClick={() => setVideo(v.url)} className="w-[170px] md:w-auto md:nth-[n+5]:hidden shrink-0 snap-start text-left group">
                <div className="relative aspect-video rounded-xl overflow-hidden bg-gray-200">
                  {ytThumb(v.url) && <img src={ytThumb(v.url)} alt="" className="w-full h-full object-cover" />}
                  <span className="absolute inset-0 bg-black/25 group-hover:bg-black/10 transition" /><span className="absolute inset-0 flex items-center justify-center"><span className="w-11 h-11 rounded-full bg-black/60 text-white flex items-center justify-center pl-0.5 text-lg ring-2 ring-white/60"><E c="▶"/></span></span>
                </div>
                <p className="text-xs md:text-[13px] font-semibold mt-1.5 line-clamp-2 text-gray-800">{v.title}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Stats + 9. location banner */}
      <section className="grid md:grid-cols-3 gap-4 mt-5">
        <div className="card p-4 md:col-span-2 flex md:grid md:grid-cols-4 gap-3 overflow-x-auto no-scrollbar snap-x text-center min-w-0 md:divide-x divide-gray-100">
          {[['🏪', home?.stats?.businesses, 'Local Businesses'], ['👥', home?.stats?.customers, 'Happy Customers'], ['✅', home?.stats?.verified, 'Businesses'], ['❤️', home?.stats?.support, 'Local']].map(([i, v, l]) => (
            <div key={l} className="min-w-[120px] md:min-w-0 flex-1 shrink-0 snap-start flex flex-col items-center justify-center"><div className="text-2xl"><E c={i} /></div><div className="font-black text-sm md:text-xl">{v}</div><div className="text-[10px] md:text-xs text-gray-500">{l}</div></div>
          ))}
        </div>
        <div className="rounded-xl p-5 text-white min-h-[110px] flex flex-col justify-center" style={{ background: `linear-gradient(90deg,#0033aacc,#0055ff55), url(${img(s.locationBanner?.image)}) center/cover` }}>
          <h3 className="font-black text-xl">{s.locationBanner?.title}</h3><p className="text-sm">{s.locationBanner?.subtitle}</p>
        </div>
      </section>

      {/* 10. Featured (premium only, behaviour-ranked) */}
      <section className="mt-6">
        <div className="flex justify-between items-end mb-3">
          <div><h2 className="font-bold text-lg">Featured Businesses</h2><p className="text-xs text-gray-500">Premium verified businesses trending right now</p></div>
          <Link href="/search?featured=1" className="text-brand text-sm font-semibold">View All →</Link>
        </div>
        <div className="flex md:grid md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 overflow-x-auto no-scrollbar snap-x snap-mandatory items-stretch pb-1">
          {(featured || []).map((b: any) => <div key={b._id} className="w-[250px] md:w-auto shrink-0 snap-start flex"><BizCard b={b} /></div>)}
          {featured && !featured.length && <p className="text-sm text-gray-500">No featured businesses yet.</p>}
        </div>
      </section>

      {/* 11. Middle banner + vendor CTA */}
      <section className="grid md:grid-cols-5 gap-4 mt-6 items-stretch">
        <div className="md:col-span-2 min-w-0"><Banner ads={ads.middle || []} h="h-full min-h-[120px] md:min-h-[150px]" /></div>
        <div className="md:col-span-3 rounded-2xl p-6 md:p-7 bg-gradient-to-r from-brand to-[#3b82f6] text-white flex flex-col justify-center relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-52 h-52 rounded-full bg-white/10" />
          <h3 className="text-xl md:text-2xl font-black relative">{s.cta?.vendorTitle}</h3>
          <p className="text-sm text-blue-100 mt-1 relative max-w-md">{s.cta?.vendorText}</p>
          <Link href="/login?intent=vendor&next=/register-business" className="btn bg-white text-brand mt-4 w-fit relative">List Your Business – It&apos;s Free!</Link>
        </div>
      </section>

      {/* Business directory — Yellow-Pages style text index */}
      <section className="card mt-8 p-5 md:p-7">
        <div className="flex flex-wrap items-end justify-between gap-2 mb-5 pb-4 border-b">
          <div><h2 className="font-black text-lg md:text-xl text-[#0b1b3f]">Business Directory — {city}</h2><p className="text-xs text-gray-500">Browse every service by category</p></div>
          <div className="flex flex-wrap gap-1.5 text-xs">{((home?.settings?.cities as string[] | undefined)?.length ? home!.settings.cities : ['Udupi', 'Manipal', 'Malpe', 'Mangaluru', 'Kundapura', 'Karkala']).map((ct: string) => (
            <button key={ct} onClick={() => { localStorage.setItem('pvrs_city', ct); window.dispatchEvent(new Event('pvrs-city')); }} className={`px-3 py-1 rounded-full border ${ct === city ? 'bg-brand text-white border-brand' : 'bg-white text-gray-600 hover:border-brand'}`}>{ct}</button>))}</div>
        </div>
        <div className="columns-1 sm:columns-2 lg:columns-4 xl:columns-5 gap-8">
          {(cats || []).map((c: any) => (
            <div key={c._id} id={`cat-${c.slug}`} className="break-inside-avoid mb-6 scroll-mt-40">
              <Link href={`/category/${c.slug}`} className="flex items-center gap-2 font-bold text-gray-900 hover:text-brand mb-2">
                <span className="w-7 h-7 rounded-lg flex items-center justify-center text-base" style={{ background: c.color + '18', color: c.color }}><CatIcon icon={c.icon} name={c.name} /></span>{c.name}
              </Link>
              <ul className="space-y-1 pl-9">
                {c.subs.slice(0, 7).map((sub: string) => (
                  <li key={sub}><Link href={`/category/${c.slug}?sub=${encodeURIComponent(sub)}`} className="text-[13px] text-gray-600 hover:text-brand hover:underline">{sub}</Link></li>
                ))}
                {c.subs.length > 7 && <li><Link href={`/category/${c.slug}`} className="text-[13px] font-semibold text-brand">View all {c.subs.length} →</Link></li>}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Advertise strip */}
      <section className="mt-6 mb-8 rounded-2xl p-6 bg-orange-50 border border-orange-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div><h3 className="text-xl md:text-2xl font-black text-accent">{s.cta?.advertiseTitle}</h3><p className="text-sm text-gray-600 mt-1">{s.cta?.advertiseText}</p></div>
        <Link href="/advertise" className="btn btn-accent shrink-0">Explore Advertising Options</Link>
      </section>
      <VideoModal url={video} onClose={() => setVideo(null)} />
    </div>
  );
}
