'use client';
import Link from 'next/link';
import { useEffect, useState } from 'react';
// One-time notice: mobile OTP + approximate location are processed (see Privacy Policy)
export default function Consent() {
  const [show, setShow] = useState(false);
  useEffect(() => { try { if (!localStorage.getItem('pvrs_consent')) setShow(true); } catch {} }, []);
  if (!show) return null;
  const ok = () => { try { localStorage.setItem('pvrs_consent', '1'); } catch {} setShow(false); };
  return (<div className="fixed bottom-20 md:bottom-4 left-3 right-3 md:left-auto md:right-4 md:max-w-sm z-40 bg-white border shadow-xl rounded-2xl p-4 text-xs text-gray-600 slideup">
    We use your mobile number (for OTP login) and, if you allow it, your location to show nearby businesses. See our <Link href="/legal/privacy" className="text-brand font-semibold">Privacy Policy</Link>.
    <button onClick={ok} className="btn btn-brand !text-xs !py-2 w-full mt-3">Got it</button></div>);
}
