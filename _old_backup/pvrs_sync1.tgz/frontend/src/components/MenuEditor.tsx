'use client';
export type MenuCat = { name: string; items: { name: string; price: number | string; veg: boolean | null; desc?: string; image?: string }[] };

// Vendor-side editor for "Order Online Menu"
export default function MenuEditor({ value, onChange }: { value: MenuCat[]; onChange: (m: MenuCat[]) => void }) {
  const set = (i: number, c: MenuCat) => onChange(value.map((x, k) => (k === i ? c : x)));
  return (
    <div className="space-y-4">
      {value.map((c, i) => (
        <div key={i} className="border border-gray-200 rounded-xl p-4 bg-gray-50 shadow-sm">
          <div className="flex gap-2 mb-3">
            <input className="input !py-1.5 font-bold text-gray-800 flex-1" maxLength={40} placeholder="Category (e.g. Starters, Main Course)" value={c.name} onChange={(e) => set(i, { ...c, name: e.target.value })} />
            <button type="button" onClick={() => onChange(value.filter((_, k) => k !== i))} className="text-red-500 hover:bg-red-50 rounded-lg text-xs font-semibold px-3 transition-colors">Remove Category</button>
          </div>
          
          <div className="space-y-3">
            {c.items.map((it, j) => (
              <div key={j} className="border border-gray-200 rounded-lg p-3 space-y-2 bg-white relative pr-8">
                {/* Remove Item Button */}
                <button type="button" onClick={() => set(i, { ...c, items: c.items.filter((_, k) => k !== j) })} className="absolute top-3 right-2 text-red-400 hover:text-red-600 font-bold p-1 text-lg z-10" title="Remove item">✕</button>
                
                <div className="grid grid-cols-12 gap-2 w-full">
                  <div className="col-span-12 lg:col-span-6">
                    <input className="input !py-1.5 w-full font-medium" maxLength={80} placeholder="Item name (e.g. Paneer Tikka)" value={it.name} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, name: e.target.value } : x)) })} />
                  </div>
                  <div className="col-span-6 lg:col-span-3">
                    <input className="input !py-1.5 w-full" type="number" min={0} max={100000} placeholder="₹ Price" value={it.price} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, price: e.target.value } : x)) })} />
                  </div>
                  <div className="col-span-6 lg:col-span-3">
                    <select className="input !py-1.5 w-full text-sm" value={it.veg === null ? '' : String(it.veg)} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, veg: e.target.value === '' ? null : e.target.value === 'true' } : x)) })}>
                      <option value="">- Veg/NonVeg -</option>
                      <option value="true">Veg</option>
                      <option value="false">Non-veg</option>
                    </select>
                  </div>
                </div>
                
                <div className="grid grid-cols-12 gap-2 w-full">
                  <div className="col-span-12 lg:col-span-6">
                    <input className="input !py-1.5 w-full text-sm bg-gray-50 focus:bg-white" placeholder="Short description (optional)" value={it.desc || ''} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, desc: e.target.value } : x)) })} />
                  </div>
                  <div className="col-span-12 lg:col-span-6">
                    <input className="input !py-1.5 w-full text-sm bg-gray-50 focus:bg-white" placeholder="Image URL (optional)" value={it.image || ''} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, image: e.target.value } : x)) })} />
                  </div>
                </div>
              </div>
            ))}
            <button type="button" disabled={c.items.length >= 80} onClick={() => set(i, { ...c, items: [...c.items, { name: '', price: '', veg: null }] })} className="text-sm font-bold text-brand hover:underline flex items-center gap-1">+ Add dish to {c.name || 'Category'}</button>
          </div>
        </div>
      ))}
      <button type="button" disabled={value.length >= 25} onClick={() => onChange([...value, { name: '', items: [{ name: '', price: '', veg: null }] }])} className="btn bg-white border border-dashed border-gray-300 hover:border-brand hover:text-brand text-gray-600 font-semibold w-full">+ Add Menu Category</button>
    </div>
  );
}
