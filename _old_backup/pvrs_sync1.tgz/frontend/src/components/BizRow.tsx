'use client';
// Justdial / Yellow-Pages style horizontal result card
import Link from 'next/link';
import { img } from '@/lib/api';
import { track } from './BizCard';
import { openNow } from './Hours';

export default function BizRow({ b }: { b: any }) {
  return (
    <div className="card p-3 md:p-4 flex gap-3 md:gap-5 hover:shadow-lg transition">
      <Link href={`/business/${b._id}`} className="relative w-24 h-24 md:w-48 md:h-36 rounded-xl overflow-hidden bg-gradient-to-br from-blue-50 to-orange-50 shrink-0 flex items-center justify-center text-4xl">
        {b.profileImage ? <img src={img(b.profileImage)} alt={b.name} className="w-full h-full object-cover text-[0px]" onError={(e) => { e.currentTarget.style.display = "none"; }} /> : '🏪'}
        {b.plan === 'premium' && <span className="absolute top-1.5 left-1.5 bg-accent text-white text-[9px] md:text-[10px] font-bold px-1.5 py-0.5 rounded">PREMIUM</span>}
      </Link>
      <div className="flex-1 min-w-0 flex flex-col">
        <div className="flex items-start gap-2">
          <Link href={`/business/${b._id}`} className="font-bold text-base md:text-xl text-gray-900 hover:text-brand leading-tight line-clamp-2">{b.name}</Link>
          {b.verified && <span className="shrink-0 mt-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold px-1.5 py-0.5 rounded border border-emerald-200">✔ Verified</span>}
          {b.trustSeal && <span className="shrink-0 mt-0.5 bg-amber-50 text-amber-800 text-[10px] font-bold px-1.5 py-0.5 rounded border border-amber-200">🛡 Trust Seal</span>}
        </div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-xs md:text-sm">
          {b.rating > 0 && <span className="flex items-center gap-1"><span className="bg-emerald-600 text-white font-bold px-1.5 py-0.5 rounded text-xs">{Number(b.rating).toFixed(1)}★</span><span className="text-gray-500">{b.reviews} ratings</span></span>}
          <span className="text-gray-500">📍 {b.city}</span>
        </div>
        <p className="text-xs md:text-sm text-gray-600 mt-1.5">{b.subCategory}{(() => { const o = openNow(b.hours); return o && <span className={`ml-2 font-semibold ${o.open ? 'text-emerald-600' : 'text-red-500'}`}>· {o.label}</span>; })()}</p>
        {b.description && <p className="hidden md:block text-sm text-gray-500 mt-1 line-clamp-1">{b.description}</p>}
        {b.distanceKm != null && <p className="text-xs text-brand font-semibold mt-1">📍 {b.distanceKm} km away</p>}
        {b.contactLocked && <p className="text-xs text-gray-500 mt-1 font-mono tracking-wide">📞 XXXXXXXXXX <span title="Shown on Premium listings">🔒</span></p>}
        {b.unclaimed && <Link href={`/business/${b._id}#claim`} className="flash text-[11px] font-bold text-accent mt-1">⚠ Is this your business? Claim it now!</Link>}
        {(() => { const ph = [...(b.gallery || [])].slice(0, 3); return ph.length > 1 ? <div className="flex gap-1.5 mt-2 overflow-hidden">{ph.map((g: string) => <img key={g} src={img(g)} alt="" loading="lazy" className="h-14 md:h-16 w-1/3 max-w-[7rem] rounded-lg object-cover bg-gray-100" onError={(e) => { e.currentTarget.style.display = 'none'; }} />)}</div> : null; })()}
        <div className="flex flex-wrap gap-1.5 mt-2 text-[11px]">
          {b.rating >= 4.5 && <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-semibold">⭐ Top rated</span>}
          {b.info?.year && <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-700">{new Date().getFullYear() - Number(b.info.year)}+ yrs in business</span>}
          {b.orderOnline && <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700">✓ Delivery</span>}
          {b.hasMenu && <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700">🍽 Menu available</span>}
          {b.info?.payments?.includes('UPI') && <span className="px-2 py-0.5 rounded-full bg-purple-50 text-purple-700">UPI accepted</span>}
        </div>
        <div className="flex flex-wrap gap-2 mt-auto pt-2.5">
          {b.contact ? (<>
            <a href={`tel:${b.contact.phone}`} onClick={() => track(b._id, 'call')} className="btn btn-brand !py-1.5 !px-3 !text-xs md:!text-sm">📞 {b.contact.phone}</a>
            <a href={`https://wa.me/91${b.contact.whatsapp || b.contact.phone}`} target="_blank" onClick={() => track(b._id, 'whatsapp')} className="btn bg-green-500 hover:bg-green-600 text-white !py-1.5 !px-3 !text-xs md:!text-sm">💬 WhatsApp</a>
          </>) : <Link href={`/business/${b._id}#enquiry`} className="btn btn-accent !py-1.5 !px-3 !text-xs md:!text-sm">✉️ Send Enquiry</Link>}
          <Link href={`/business/${b._id}`} className="btn btn-ghost !py-1.5 !px-3 !text-xs md:!text-sm">View details</Link>
        </div>
      </div>
    </div>
  );
}
