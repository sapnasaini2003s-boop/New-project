'use client';
import { useState } from 'react';

export const DAYS: [string, string][] = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']];
export type Hours = Record<string, { open: boolean; from?: string; to?: string; allDay?: boolean }>;
export const defaultHours = (): Hours => Object.fromEntries(DAYS.map(([d]) => [d, { open: d !== 'sun', from: '09:00', to: '21:00' }]));

const t12 = (t?: string) => { if (!t) return ''; const [h, m] = t.split(':').map(Number); return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`; };
const range = (x: any) => (x?.allDay ? 'Open 24 hours' : x?.open ? `${t12(x.from)} – ${t12(x.to)}` : 'Closed');

// One-line summary saved as `timings` for old screens / search
export function summarize(h: Hours) {
  const groups: { days: string[]; r: string }[] = [];
  for (const [d, label] of DAYS) { const r = range(h[d]); const g = groups[groups.length - 1]; if (g && g.r === r) g.days.push(label.slice(0, 3)); else groups.push({ days: [label.slice(0, 3)], r }); }
  return groups.map((g) => `${g.days.length > 2 ? `${g.days[0]}–${g.days[g.days.length - 1]}` : g.days.join(', ')}: ${g.r}`).join(' · ');
}

// Is the business open right now (India time)?
export function openNow(h?: Hours) {
  if (!h) return null;
  const now = new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' }));
  const d = DAYS[(now.getDay() + 6) % 7][0]; const x = h[d]; if (!x?.open) return { open: false, label: 'Closed today' };
  if (x.allDay) return { open: true, label: 'Open 24 hours' };
  const mins = now.getHours() * 60 + now.getMinutes(); const [fh, fm] = x.from!.split(':').map(Number); const [th, tm] = x.to!.split(':').map(Number);
  const from = fh * 60 + fm; let to = th * 60 + tm; if (to <= from) to += 1440; // overnight
  const m = mins < from && to > 1440 ? mins + 1440 : mins;
  return m >= from && m < to ? { open: true, label: `Open now · closes ${t12(x.to)}` } : { open: false, label: mins < from ? `Opens at ${t12(x.from)}` : 'Closed now' };
}

/* Day-wise editor with clock pickers */
export function HoursPicker({ value, onChange }: { value: Hours; onChange: (h: Hours) => void }) {
  const set = (d: string, patch: any) => onChange({ ...value, [d]: { ...value[d], ...patch } });
  const copyAll = (src: string) => onChange(Object.fromEntries(DAYS.map(([d]) => [d, { ...value[src] }])));
  const preset = (fn: (d: string) => any) => onChange(Object.fromEntries(DAYS.map(([d]) => [d, fn(d)])));
  return (
    <div className="rounded-xl border bg-gray-50/50">
      <div className="flex flex-wrap gap-2 p-3 border-b text-xs">
        <span className="text-gray-500 font-semibold mr-1 self-center">Quick set:</span>
        <button type="button" onClick={() => preset((d) => ({ open: d !== 'sun', from: '09:00', to: '21:00' }))} className="px-2.5 py-1 rounded-full bg-white border hover:border-brand">Mon–Sat 9–9</button>
        <button type="button" onClick={() => preset(() => ({ open: true, from: '10:00', to: '22:00' }))} className="px-2.5 py-1 rounded-full bg-white border hover:border-brand">All days 10–10</button>
        <button type="button" onClick={() => preset(() => ({ open: true, from: '00:00', to: '23:59', allDay: true }))} className="px-2.5 py-1 rounded-full bg-white border hover:border-brand">24 × 7</button>
        <button type="button" onClick={() => copyAll('mon')} className="px-2.5 py-1 rounded-full bg-white border hover:border-brand">Copy Monday to all</button>
      </div>
      <div className="divide-y">
        {DAYS.map(([d, label]) => { const x = value[d] || { open: false }; return (
          <div key={d} className="flex flex-wrap items-center gap-3 px-3 py-2.5">
            <span className="w-24 text-sm font-semibold text-gray-700">{label}</span>
            <button type="button" onClick={() => set(d, { open: !x.open, from: x.from || '09:00', to: x.to || '21:00', allDay: false })}
              className={`relative w-11 h-6 rounded-full transition shrink-0 ${x.open ? 'bg-emerald-500' : 'bg-gray-300'}`} aria-label={`${label} open`}>
              <span className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all ${x.open ? 'left-[22px]' : 'left-0.5'}`} />
            </button>
            {!x.open ? <span className="text-sm text-gray-400">Closed</span> : x.allDay ? (
              <span className="text-sm font-medium text-emerald-700">Open 24 hours</span>
            ) : (
              <div className="flex items-center gap-2">
                <input type="time" value={x.from} onChange={(e) => set(d, { from: e.target.value })} className="input !w-auto !py-1.5" />
                <span className="text-gray-400 text-sm">to</span>
                <input type="time" value={x.to} onChange={(e) => set(d, { to: e.target.value })} className="input !w-auto !py-1.5" />
              </div>
            )}
            {x.open && <label className="ml-auto flex items-center gap-1.5 text-xs text-gray-500"><input type="checkbox" checked={!!x.allDay} onChange={(e) => set(d, e.target.checked ? { allDay: true, from: '00:00', to: '23:59' } : { allDay: false, from: '09:00', to: '21:00' })} />24 hrs</label>}
          </div>); })}
      </div>
    </div>
  );
}

/* Read-only weekly table for the business page */
export function HoursTable({ hours }: { hours: Hours }) {
  const today = DAYS[(new Date(new Date().toLocaleString('en-US', { timeZone: 'Asia/Kolkata' })).getDay() + 6) % 7][0];
  return (
    <table className="w-full text-sm">
      <tbody>{DAYS.map(([d, label]) => (
        <tr key={d} className={d === today ? 'font-bold text-gray-900' : 'text-gray-600'}>
          <td className="py-1">{label}{d === today && <span className="ml-1 text-[10px] text-brand">(today)</span>}</td>
          <td className={`py-1 text-right ${!hours[d]?.open ? 'text-red-500' : ''}`}>{range(hours[d])}</td>
        </tr>))}</tbody>
    </table>
  );
}

/* Keyword chips input */
export function TagInput({ value, onChange, placeholder }: { value: string[]; onChange: (v: string[]) => void; placeholder?: string }) {
  const [txt, setTxt] = useState('');
  const add = (raw: string) => { const parts = raw.split(',').map((s) => s.trim()).filter(Boolean); if (parts.length) onChange([...new Set([...value, ...parts])].slice(0, 15)); setTxt(''); };
  return (
    <div className="input !p-1.5 flex flex-wrap gap-1.5 items-center min-h-[46px] focus-within:border-brand">
      {value.map((t) => <span key={t} className="flex items-center gap-1 bg-blue-50 text-brand text-xs font-medium rounded-full pl-2.5 pr-1 py-1">{t}<button type="button" onClick={() => onChange(value.filter((x) => x !== t))} className="w-4 h-4 rounded-full hover:bg-blue-100 leading-none">×</button></span>)}
      <input value={txt} onChange={(e) => (e.target.value.endsWith(',') ? add(e.target.value) : setTxt(e.target.value))}
        onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(txt); } else if (e.key === 'Backspace' && !txt && value.length) onChange(value.slice(0, -1)); }}
        onBlur={() => txt && add(txt)} placeholder={value.length ? '' : placeholder} className="flex-1 min-w-[120px] outline-none text-sm px-1.5 bg-transparent" />
    </div>
  );
}
