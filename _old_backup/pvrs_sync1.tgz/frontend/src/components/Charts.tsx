'use client';
// Lightweight dependency-free SVG charts for the admin dashboard.
// Palette: validated categorical order (blue, orange, aqua, yellow); text always in ink tokens.
import { useMemo, useRef, useState } from 'react';

export const SERIES = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100'];
const fmt = (n: number) => (n >= 100000 ? `${(n / 100000).toFixed(1)}L` : n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(Math.round(n)));
const day = (iso: string) => new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

/* Multi-series line/area chart with crosshair + tooltip */
export function LineChart({ labels, series, height = 240, money = false }: { labels: string[]; series: { name: string; data: number[]; color: string }[]; height?: number; money?: boolean }) {
  const W = height < 200 ? 400 : 720, H = height, L = 36, R = 12, T = 12, B = 26;
  const [hover, setHover] = useState<number | null>(null);
  const ref = useRef<SVGSVGElement>(null);
  const max = Math.max(1, ...series.flatMap((s) => s.data));
  const nice = useMemo(() => { const p = Math.pow(10, Math.floor(Math.log10(max))); return Math.ceil(max / p) * p; }, [max]);
  const x = (i: number) => L + (i * (W - L - R)) / Math.max(1, labels.length - 1);
  const y = (v: number) => T + (H - T - B) * (1 - v / nice);
  const path = (d: number[]) => d.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join('');
  const move = (e: React.MouseEvent) => {
    const r = ref.current!.getBoundingClientRect(); const px = ((e.clientX - r.left) / r.width) * W;
    setHover(Math.max(0, Math.min(labels.length - 1, Math.round(((px - L) / (W - L - R)) * (labels.length - 1)))));
  };
  const ticks = [0, 0.25, 0.5, 0.75, 1].map((f) => nice * f);
  const step = Math.ceil(labels.length / 6);
  return (
    <div className="relative">
      <svg ref={ref} viewBox={`0 0 ${W} ${H}`} className="w-full h-auto" onMouseMove={move} onMouseLeave={() => setHover(null)} role="img">
        {ticks.map((t) => <g key={t}><line x1={L} x2={W - R} y1={y(t)} y2={y(t)} stroke="#eef0f3" /><text x={L - 6} y={y(t) + 4} textAnchor="end" fontSize="10" fill="#94a3b8">{fmt(t)}</text></g>)}
        {labels.map((l, i) => i % step === 0 && <text key={l} x={x(i)} y={H - 8} textAnchor="middle" fontSize="10" fill="#94a3b8">{day(l)}</text>)}
        {series.map((s, si) => (
          <g key={s.name}>
            {si === 0 && <path d={`${path(s.data)}L${x(s.data.length - 1)},${y(0)}L${x(0)},${y(0)}Z`} fill={s.color} opacity="0.08" />}
            <path d={path(s.data)} fill="none" stroke={s.color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
          </g>
        ))}
        {hover != null && <g>
          <line x1={x(hover)} x2={x(hover)} y1={T} y2={H - B} stroke="#cbd5e1" strokeDasharray="3 3" />
          {series.map((s) => <circle key={s.name} cx={x(hover)} cy={y(s.data[hover])} r="4.5" fill={s.color} stroke="#fff" strokeWidth="2" />)}
        </g>}
      </svg>
      {hover != null && (
        <div className="pointer-events-none absolute top-2 bg-slate-900 text-white text-xs rounded-lg px-3 py-2 shadow-xl" style={{ left: `${Math.min(75, (x(hover) / W) * 100)}%` }}>
          <div className="font-semibold mb-1">{day(labels[hover])}</div>
          {series.map((s) => <div key={s.name} className="flex items-center gap-2"><span className="w-2 h-2 rounded-full" style={{ background: s.color }} />{s.name}<b className="ml-auto pl-3">{money ? '₹' : ''}{s.data[hover].toLocaleString('en-IN')}</b></div>)}
        </div>
      )}
      {series.length > 1 && <div className="flex flex-wrap gap-4 mt-2 text-xs text-slate-600">{series.map((s) => <span key={s.name} className="flex items-center gap-1.5"><span className="w-3 h-[3px] rounded" style={{ background: s.color }} />{s.name}</span>)}</div>}
    </div>
  );
}

/* Horizontal bar list (ranked categories) */
export function BarList({ data, color = SERIES[0], unit = '' }: { data: { name: string; value: number }[]; color?: string; unit?: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  if (!data.length) return <p className="text-sm text-slate-400 py-6 text-center">No data yet</p>;
  return (
    <div className="space-y-2.5">
      {data.map((d) => (
        <div key={d.name} className="group" title={`${d.name}: ${d.value}${unit}`}>
          <div className="flex justify-between text-xs mb-1"><span className="text-slate-700 font-medium truncate pr-2">{d.name}</span><span className="text-slate-500 tabular-nums">{d.value.toLocaleString('en-IN')}{unit}</span></div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden"><div className="h-full rounded-full transition-all group-hover:opacity-80" style={{ width: `${(d.value / max) * 100}%`, background: color }} /></div>
        </div>
      ))}
    </div>
  );
}

/* Donut for a part-to-whole split (≤4 parts) */
export function Donut({ parts, label }: { parts: { name: string; value: number; color: string }[]; label: string }) {
  const total = parts.reduce((a, b) => a + b.value, 0) || 1; const R = 52, C = 2 * Math.PI * R; let off = 0;
  const [h, setH] = useState<number | null>(null);
  return (
    <div className="flex items-center gap-6">
      <svg viewBox="0 0 140 140" className="w-36 h-36 shrink-0 -rotate-90">
        <circle cx="70" cy="70" r={R} fill="none" stroke="#f1f5f9" strokeWidth="16" />
        {parts.map((p, i) => { const len = (p.value / total) * C; const el = <circle key={p.name} cx="70" cy="70" r={R} fill="none" stroke={p.color} strokeWidth={h === i ? 20 : 16} strokeDasharray={`${Math.max(0, len - 2)} ${C}`} strokeDashoffset={-off} onMouseEnter={() => setH(i)} onMouseLeave={() => setH(null)} className="transition-all cursor-pointer" />; off += len; return el; })}
        <text x="70" y="66" textAnchor="middle" fontSize="22" fontWeight="800" fill="#0f172a" transform="rotate(90 70 70)">{h != null ? parts[h].value : total}</text>
        <text x="70" y="84" textAnchor="middle" fontSize="10" fill="#64748b" transform="rotate(90 70 70)">{h != null ? parts[h].name : label}</text>
      </svg>
      <div className="space-y-2 text-sm">{parts.map((p) => <div key={p.name} className="flex items-center gap-2"><span className="w-3 h-3 rounded" style={{ background: p.color }} /><span className="text-slate-600">{p.name}</span><b className="text-slate-900 ml-2">{p.value}</b><span className="text-slate-400 text-xs">({Math.round((p.value / total) * 100)}%)</span></div>)}</div>
    </div>
  );
}

/* Tiny sparkline for KPI tiles */
export function Spark({ data, color = SERIES[0] }: { data: number[]; color?: string }) {
  const max = Math.max(1, ...data); const W = 100, H = 28;
  const d = data.map((v, i) => `${i ? 'L' : 'M'}${(i * W) / Math.max(1, data.length - 1)},${H - (v / max) * (H - 4) - 2}`).join('');
  return <svg viewBox={`0 0 ${W} ${H}`} className="w-24 h-7" preserveAspectRatio="none"><path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" /></svg>;
}
