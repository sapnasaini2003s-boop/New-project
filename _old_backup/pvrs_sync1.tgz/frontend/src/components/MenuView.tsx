'use client';
import { useMemo, useState } from 'react';
import type { MenuCat } from './MenuEditor';

const Dot = ({ veg }: { veg: boolean | null }) => veg === null ? <span className="w-3.5 h-3.5 shrink-0" /> : <span className={`w-3.5 h-3.5 shrink-0 border rounded-[3px] flex items-center justify-center ${veg ? 'border-green-600' : 'border-red-600'}`}><span className={`w-1.5 h-1.5 rounded-full ${veg ? 'bg-green-600' : 'bg-red-600'}`} /></span>;

export default function MenuView({ menu }: { menu: MenuCat[] }) {
  const [q, setQ] = useState(''); 
  const [showSearch, setShowSearch] = useState(false); 
  const [veg, setVeg] = useState(false); 
  const [non, setNon] = useState(false);
  const [open, setOpen] = useState<Record<number, boolean>>({}); 
  const [all, setAll] = useState<Record<number, boolean>>({}); 
  const [jump, setJump] = useState(false);

  const cats = useMemo(() => 
    menu.map((c) => ({ ...c, items: c.items.filter((i: any) => (!veg || i.veg === true) && (!non || i.veg === false) && (!q || i.name.toLowerCase().includes(q.toLowerCase()))) }))
        .filter((c) => c.items.length), 
    [menu, q, veg, non]
  );

  const chip = (on: boolean) => `px-3 py-1.5 rounded-full border text-xs font-medium flex items-center gap-1.5 transition-colors ${on ? 'border-brand bg-blue-50 text-brand' : 'border-gray-200 bg-white text-gray-700 hover:bg-gray-50'}`;

  return (
    <section className="card p-0 md:p-0 overflow-hidden relative border border-gray-200 shadow-sm">
      <div className="bg-gray-50 border-b border-gray-100 p-4 md:p-5">
        <h2 className="font-bold text-lg text-gray-900 mb-4">Order Online Menu</h2>
        <div className="flex gap-2 items-center flex-wrap">
          <button onClick={() => setShowSearch(!showSearch)} className={chip(showSearch)} aria-label="Search menu">🔍</button>
          <button onClick={() => { setVeg(!veg); if(!veg) setNon(false); }} className={chip(veg)}><Dot veg={true} /> Veg</button>
          <button onClick={() => { setNon(!non); if(!non) setVeg(false); }} className={chip(non)}><Dot veg={false} /> Non Veg</button>
        </div>
        
        <div className={`overflow-hidden transition-all duration-300 ${showSearch ? 'max-h-16 opacity-100 mt-3' : 'max-h-0 opacity-0 mt-0'}`}>
          <input 
            className="input w-full bg-white border-gray-200 focus:border-brand shadow-sm" 
            placeholder="🔍 Search dishes..." 
            value={q} 
            onChange={(e) => setQ(e.target.value)} 
          />
        </div>
      </div>

      <div className="p-4 md:p-5 bg-white">
        {!cats.length && <p className="text-sm text-gray-500 py-10 text-center flex flex-col items-center gap-2"><span className="text-3xl opacity-50">🍽️</span> No dishes found.</p>}
        {cats.map((c, i) => {
          const isOpen = open[i] !== false; 
          const lim = all[i] || q ? c.items.length : 4;
          return (
            <div key={c.name} id={`menu-${i}`} className="mb-6 last:mb-0">
              <button onClick={() => setOpen({ ...open, [i]: !isOpen })} className="w-full flex justify-between items-center py-2 mb-2 group">
                <span className="font-bold text-lg text-gray-800 group-hover:text-brand transition-colors">{c.name} <span className="text-gray-500 text-sm ml-1 font-medium">({c.items.length})</span></span>
                <span className={`text-gray-400 text-xs transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`}>▼</span>
              </button>
              
              <div className={`space-y-4 overflow-hidden transition-all duration-300 ${isOpen ? 'opacity-100 max-h-auto' : 'opacity-0 max-h-0 hidden'}`}>
                {c.items.slice(0, lim).map((it: any, k) => (
                  <div key={k} className="flex gap-4 items-start pb-4 border-b border-gray-100 last:border-0 last:pb-0">
                    <div className="mt-1">
                      <Dot veg={it.veg} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-800 text-[15px] leading-snug">{it.name}</p>
                      <p className="font-bold text-gray-700 text-sm mt-1">₹{it.price}</p>
                      {it.desc && <p className="text-xs text-gray-500 mt-1.5 leading-relaxed line-clamp-2">{it.desc}</p>}
                    </div>
                    {it.image && (
                      <div className="shrink-0 w-24 h-24 rounded-xl overflow-hidden shadow-sm relative bg-gray-50 border border-gray-100">
                        <img src={it.image} alt={it.name} className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>
                ))}
                {c.items.length > lim && (
                  <button onClick={() => setAll({ ...all, [i]: true })} className="w-full text-center py-2 text-sm font-semibold text-brand hover:bg-blue-50 rounded-lg transition-colors mt-2">
                    View all {c.items.length} items in {c.name}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {!!cats.length && (
        <div className="sticky bottom-4 flex justify-center mt-4 pointer-events-none z-10 pb-4">
          <div className="relative pointer-events-auto">
            {jump && (
              <div className="absolute bottom-14 left-1/2 -translate-x-1/2 bg-white border border-gray-200 shadow-2xl rounded-2xl p-2 w-64 max-h-[300px] overflow-y-auto z-20">
                <div className="text-xs font-bold text-gray-400 uppercase tracking-wider px-3 pt-2 pb-1 mb-1 border-b">Menu Categories</div>
                {cats.map((c, i) => (
                  <a key={c.name} href={`#menu-${i}`} onClick={() => { setOpen({ ...open, [i]: true }); setJump(false); }} className="flex justify-between items-center px-3 py-2.5 rounded-xl hover:bg-gray-100 text-sm font-medium text-gray-700 transition-colors">
                    <span className="truncate">{c.name}</span>
                    <span className="text-gray-400 text-xs ml-2">{c.items.length}</span>
                  </a>
                ))}
              </div>
            )}
            <button onClick={() => setJump(!jump)} className="bg-gray-900 hover:bg-black text-white rounded-full px-6 py-2.5 text-sm font-bold shadow-xl shadow-gray-900/20 flex items-center gap-2 transition-transform hover:scale-105">
              <span>≡</span> Menu
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
