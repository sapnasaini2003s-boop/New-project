'use client';
import { ytId } from '@/lib/api';
export default function VideoModal({ url, onClose }: { url: string | null; onClose: () => void }) {
  if (!url) return null;
  const id = ytId(url);
  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={onClose}>
      <div className="w-full max-w-3xl aspect-video bg-black rounded-xl overflow-hidden relative" onClick={(e) => e.stopPropagation()}>
        {id ? <iframe className="w-full h-full" src={`https://www.youtube.com/embed/${id}?autoplay=1`} allow="autoplay; encrypted-media" allowFullScreen />
          : <iframe className="w-full h-full" src={url} allowFullScreen />}
        <button onClick={onClose} className="absolute top-2 right-2 bg-white/90 rounded-full w-8 h-8 font-bold">✕</button>
      </div>
    </div>
  );
}
