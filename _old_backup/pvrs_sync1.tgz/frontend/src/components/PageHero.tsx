import Link from 'next/link';
// Shared page header: gradient band + breadcrumb + title
export default function PageHero({ title, subtitle, crumb, icon, children, tone = 'brand' }: { title: string; subtitle?: string; crumb?: string; icon?: string; children?: React.ReactNode; tone?: 'brand' | 'accent' | 'dark' }) {
  const bg = tone === 'accent' ? 'from-[#c2410c] via-accent to-[#fb923c]' : tone === 'dark' ? 'from-[#0b1b3f] via-[#13265a] to-[#1e3a8a]' : 'from-[#0033aa] via-brand to-[#3b82f6]';
  return (
    <section className={`relative overflow-hidden bg-gradient-to-br ${bg} text-white`}>
      <div className="absolute -right-24 -top-24 w-96 h-96 rounded-full bg-white/10" />
      <div className="absolute left-1/3 -bottom-32 w-80 h-80 rounded-full bg-white/5 blur-2xl" />
      <div className="relative max-w-7xl mx-auto px-4 py-8 md:py-12">
        <p className="text-xs text-white/70 mb-2"><Link href="/" className="hover:text-white">Home</Link> <span className="mx-1">›</span> {crumb || title}</p>
        <h1 className="text-2xl md:text-4xl font-black flex items-center gap-3">{icon && <span className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-white/15 flex items-center justify-center text-2xl md:text-3xl">{icon}</span>}{title}</h1>
        {subtitle && <p className="text-white/80 mt-2 max-w-2xl text-sm md:text-base">{subtitle}</p>}
        {children && <div className="mt-5">{children}</div>}
      </div>
    </section>
  );
}
