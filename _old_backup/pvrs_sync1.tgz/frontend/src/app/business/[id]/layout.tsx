import { Metadata } from 'next';

const API = process.env.NEXT_PUBLIC_API_URL || 'https://pvrs-backend.onrender.com';
async function fetchBiz(id: string) {
  try {
    const res = await fetch(`${API}/api/businesses/${id}`, { next: { revalidate: 300 } });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const { id } = await params;
  const b = await fetchBiz(id);
  if (!b) return { title: 'Business Not Found | PVRS HUB' };
  
  return {
    title: `${b.name} in ${b.city} | PVRS HUB`,
    description: b.description || `View details, contact, and reviews for ${b.name} in ${b.city} on PVRS HUB.`,
    keywords: [b.name, b.city, b.category, ...(b.tags || [])].filter(Boolean).join(', '),
    openGraph: {
      title: `${b.name} | PVRS HUB`,
      description: b.description || `Contact ${b.name} today.`,
      images: b.profileImage ? [b.profileImage.startsWith('http') ? b.profileImage : `${API}${b.profileImage}`] : [],
    }
  };
}

export default function BusinessLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
