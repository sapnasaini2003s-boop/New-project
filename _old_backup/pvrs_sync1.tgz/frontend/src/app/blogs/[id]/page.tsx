'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { img, useFetch } from '@/lib/api';
export default function Blog() {
  const { id } = useParams<{ id: string }>(); const { data: b } = useFetch<any>(`/blogs/${id}`);
  if (!b) return <div className="max-w-3xl mx-auto px-4 py-10 animate-pulse space-y-4"><div className="h-8 bg-gray-200 rounded w-3/4" /><div className="h-64 bg-gray-200 rounded-2xl" /></div>;
  return (<article className="max-w-3xl mx-auto px-4 py-8">
    <Link href="/blogs" className="text-sm text-brand font-semibold">← All articles</Link>
    <h1 className="text-3xl md:text-5xl font-black leading-tight mt-4">{b.title}</h1>
    <p className="text-sm text-gray-500 mt-3">{new Date(b.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })} · PVRS HUB</p>
    {b.image && <img src={img(b.image)} alt="" className="w-full rounded-3xl my-8 shadow-lg" />}
    {b.excerpt && <p className="text-xl text-gray-600 my-6 leading-relaxed border-l-4 border-accent pl-4">{b.excerpt}</p>}
    <div className="whitespace-pre-line text-gray-800 text-lg leading-8">{b.body}</div>
    <div className="mt-12 rounded-2xl p-6 bg-gradient-to-r from-brand to-[#3b82f6] text-white flex flex-wrap gap-4 items-center justify-between"><b className="text-lg">Own a local business? Get listed free.</b><Link href="/register-business" className="btn bg-white text-brand">List your business</Link></div>
  </article>);
}
