'use client';
export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (<div className="max-w-md mx-auto text-center py-24 px-4"><div className="text-6xl mb-4">⚠️</div><h1 className="text-2xl font-black">Something went wrong</h1>
    <p className="text-gray-500 mt-2 mb-6">Please try again. If the problem continues, check your internet connection.</p><button onClick={reset} className="btn btn-brand">Try again</button></div>);
}
