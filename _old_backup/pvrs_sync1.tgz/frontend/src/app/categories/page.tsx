'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useFetch } from '@/lib/api';
import PageHero from '@/components/PageHero';

export default function Categories() {
  const { data } = useFetch<any[]>('/categories');
  const [q, setQ] = useState('');
  const t = q.toLowerCase();
  const list = (data || []).map((c) => ({ ...c, shown: t ? c.subs.filter((s: string) => s.toLowerCase().includes(t)) : c.subs }))
    .filter((c) => !t || c.name.toLowerCase().includes(t) || c.shown.length);
  return (
    <div>
      <PageHero title="All Categories" icon="📂" subtitle={`${data?.length || 0} categories · ${(data || []).reduce((a, c) => a + c.subs.length, 0)} services across coastal Karnataka`}>
        <div className="max-w-xl bg-white rounded-xl flex items-center px-4 shadow-xl"><span className="text-gray-400">🔍</span><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find a service, e.g. plumber, PG, dentist…" className="flex-1 px-3 py-3.5 text-gray-800 outline-none" /></div>
      </PageHero>
      <div className="max-w-7xl mx-auto px-3 md:px-4 py-8">
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-4 mb-2">
          {(data || []).map((c) => <a key={c._id} href={`#${c.slug}`} className="shrink-0 flex items-center gap-2 bg-white border rounded-full px-3 py-1.5 text-xs font-semibold hover:border-brand hover:text-brand">{c.icon} {c.name}</a>)}
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {list.map((c) => (
            <div key={c._id} id={c.slug} className="card overflow-hidden scroll-mt-32 hover:shadow-lg transition">
              <Link href={`/category/${c.slug}`} className="flex items-center gap-4 p-5 border-b" style={{ background: `linear-gradient(90deg, ${c.color}14, transparent)` }}>
                <span className="w-14 h-14 rounded-2xl bg-white shadow-sm flex items-center justify-center text-3xl">{c.icon}</span>
                <span className="flex-1"><span className="block font-black text-lg text-gray-900">{c.name}</span><span className="text-xs text-gray-500">{c.subs.length} services</span></span>
                <span className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-brand shadow-sm">→</span>
              </Link>
              <ul className="p-4 grid grid-cols-2 gap-x-3 gap-y-1">
                {c.shown.map((s: string) => (
                  <li key={s}><Link href={`/category/${c.slug}?sub=${encodeURIComponent(s)}`} className="flex items-center gap-2 text-[13px] text-gray-600 hover:text-brand py-1"><span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ background: c.color }} /><span className="truncate">{s}</span></Link></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        {data && !list.length && <div className="card p-10 text-center text-gray-500">No category matches “{q}”.</div>}
      </div>
    </div>
  );
}
