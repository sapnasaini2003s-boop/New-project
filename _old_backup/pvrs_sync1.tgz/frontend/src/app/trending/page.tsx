'use client';
import Listing from '@/components/Listing';
export default function Trending() { return <Listing query="sort=trending" title="🔥 Trending Near You" />; }
