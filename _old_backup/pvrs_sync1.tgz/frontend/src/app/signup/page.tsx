import { redirect } from 'next/navigation';
export default function Signup() { redirect('/login?intent=vendor'); }
