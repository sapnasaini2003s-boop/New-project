'use client';
import Link from 'next/link';
import { useFetch } from '@/lib/api';
import PageHero from '@/components/PageHero';
export default function Advertise() {
  const { data: p } = useFetch<any>('/pricing');
  const plans = [
    { n: 'Free Listing', price: '₹0', per: 'forever', feats: ['Business page & search visibility', '1 profile image', 'Enquiry form leads', 'Verified badge after document check'], no: ['Call & WhatsApp buttons', 'Gallery & videos'], cta: 'Start free', tone: 'ghost' },
    { n: 'Premium', price: `₹${p?.premium?.toLocaleString('en-IN') ?? '—'}`, per: '/ year', feats: ['Call & WhatsApp buttons unlocked', 'Photo gallery + header banner', 'YouTube / Facebook / Instagram videos', 'Featured homepage slider', 'WhatsApp alert on every lead', 'Banner ad booking'], no: [], cta: 'Go Premium', tone: 'accent', best: true },
    { n: 'Banner Ads', price: `₹${p?.bannerPerDay ?? '—'}`, per: '/ day', feats: ['Top carousel or middle banner', 'Promotional widget', 'Hero video ad (2× price)', 'Book & pay from dashboard'], no: [], cta: 'Book a banner', tone: 'brand' },
  ];
  return (<div>
    <PageHero title="Grow with PVRS HUB" icon="📈" tone="dark" subtitle="Reach students, tourists and locals across Udupi, Manipal, Malpe & Mangaluru." >
      <div className="flex flex-wrap gap-6 text-sm">{[['5,000+', 'businesses'], ['100k+', 'monthly visitors'], ['24h', 'listing approval']].map(([v, l]) => <div key={l}><b className="text-2xl block">{v}</b><span className="text-white/70">{l}</span></div>)}</div>
    </PageHero>
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="grid md:grid-cols-3 gap-6 items-stretch">{plans.map((x) => (
        <div key={x.n} className={`card p-7 flex flex-col relative ${x.best ? 'border-2 border-accent shadow-2xl md:-translate-y-3' : ''}`}>
          {x.best && <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-white text-xs font-bold px-3 py-1 rounded-full">MOST POPULAR</span>}
          <h3 className="font-bold text-lg">{x.n}</h3>
          <p className="mt-3"><span className="text-4xl font-black">{x.price}</span> <span className="text-gray-500 text-sm">{x.per}</span></p>
          <ul className="text-sm space-y-2.5 mt-6 flex-1">{x.feats.map((f) => <li key={f} className="flex gap-2"><span className="text-emerald-500">✔</span>{f}</li>)}{x.no.map((f) => <li key={f} className="flex gap-2 text-gray-400"><span>✕</span>{f}</li>)}</ul>
          <Link href="/login?intent=vendor&next=/vendor/dashboard" className={`btn mt-7 !py-3 ${x.tone === 'accent' ? 'btn-accent' : x.tone === 'brand' ? 'btn-brand' : 'btn-ghost'}`}>{x.cta}</Link>
        </div>))}</div>
      <div className="grid md:grid-cols-3 gap-4 mt-12">{[['1', 'Register with mobile', 'Sign up with your number in 30 seconds.'], ['2', 'Upload your licence', 'Trade License / FSSAI / KMC certificate.'], ['3', 'Go live after review', 'Our team verifies & publishes within 24h.']].map(([n, t, d]) => (
        <div key={n} className="flex gap-4"><span className="w-10 h-10 rounded-full bg-brand text-white font-black flex items-center justify-center shrink-0">{n}</span><div><b>{t}</b><p className="text-sm text-gray-500">{d}</p></div></div>))}</div>
      <p className="text-center text-xs text-gray-500 mt-10">Secure payments via Razorpay — UPI (GPay, PhonePe, Paytm), NetBanking & Cards.</p>
    </div>
  </div>);
}
