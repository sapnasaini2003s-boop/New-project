import type { MetadataRoute } from 'next';
const SITE = process.env.NEXT_PUBLIC_SITE_URL || 'https://new-project-two-eta-97.vercel.app';
export default function robots(): MetadataRoute.Robots {
  return { rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/vendor', '/login', '/favorites'] }], sitemap: `${SITE}/sitemap.xml` };
}
