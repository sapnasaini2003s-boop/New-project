import Link from 'next/link';
export default function NotFound() {
  return (<div className="max-w-md mx-auto text-center py-24 px-4"><div className="text-6xl mb-4">🧭</div><h1 className="text-2xl font-black">Page not found</h1>
    <p className="text-gray-500 mt-2 mb-6">The page you are looking for doesn&apos;t exist or has been moved.</p><Link href="/" className="btn btn-brand">Back to home</Link></div>);
}
