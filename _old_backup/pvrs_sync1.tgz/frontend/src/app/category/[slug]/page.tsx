'use client';
import { Suspense, useState } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import { useFetch } from '@/lib/api';
import Listing from '@/components/Listing';

function Inner() {
  const { slug } = useParams<{ slug: string }>();
  const sp = useSearchParams();
  const [sub, setSub] = useState(sp.get('sub') || '');
  const { data: cats } = useFetch<any[]>('/categories');
  const cat = cats?.find((c) => c.slug === slug);
  return <Listing key={sub} query={`category=${slug}${sub ? `&sub=${encodeURIComponent(sub)}` : ''}`} title={`${cat?.icon || ''} ${sub || cat?.name || ''}`} subs={cat?.subs} sub={sub} onSub={setSub} />;
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
