import type { MetadataRoute } from 'next';
import { API } from '@/lib/api';
const SITE = process.env.NEXT_PUBLIC_SITE_URL || 'https://new-project-two-eta-97.vercel.app';
export const revalidate = 3600;
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const fixed = ['', '/categories', '/offers', '/trending', '/videos', '/blogs', '/advertise', '/register-business', '/legal/about', '/legal/disclaimer', '/legal/privacy', '/legal/terms'].map((p) => ({ url: SITE + p, changeFrequency: 'weekly' as const }));
  try {
    const [b, c] = await Promise.all([fetch(`${API}/api/businesses`).then((r) => r.json()), fetch(`${API}/api/categories`).then((r) => r.json())]);
    return [...fixed, ...c.map((x: any) => ({ url: `${SITE}/category/${x.slug}`, changeFrequency: 'weekly' as const })), ...b.map((x: any) => ({ url: `${SITE}/business/${x._id}`, changeFrequency: 'weekly' as const }))];
  } catch { return fixed; }
}
