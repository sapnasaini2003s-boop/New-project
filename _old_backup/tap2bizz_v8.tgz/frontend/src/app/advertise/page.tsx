'use client';
import { E } from '@/components/Icon';
import Link from 'next/link';
import { useFetch } from '@/lib/api';
import { Price, Ribbon, pct } from '@/components/Price';
import PageHero from '@/components/PageHero';
import { DEFAULT_PLANS } from '@/lib/plans';
export default function Advertise() {
  const { data: p } = useFetch<any>('/pricing');
  const src: any[] = Array.isArray(p?.plans) && p.plans.length ? p.plans : DEFAULT_PLANS;
  const plans: any[] = src.map((x) => {
    const k = x.key || 'custom';
    const price = k === 'free' ? 0 : k === 'premium' ? p?.premium : k === 'banner' ? p?.bannerPerDay : x.price;
    const mrp = k === 'premium' ? p?.premiumMrp : k === 'banner' ? p?.bannerMrp : k === 'custom' ? x.mrp : 0;
    const per = x.per || (k === 'free' ? 'forever' : k === 'premium' ? '/year' : k === 'banner' ? '/day' : '');
    return { ...x, price, mrp, per, tone: x.best ? 'accent' : k === 'banner' ? 'brand' : 'ghost', href: x.link || '/login?intent=vendor&next=/vendor/dashboard' };
  });
  return (<div>
    <PageHero title="Grow with Tap2Bizz" icon="📈" tone="dark" subtitle="Reach students, tourists and locals across Udupi, Manipal, Malpe & Mangaluru." >
      <div className="flex flex-wrap gap-6 text-sm">{[['5,000+', 'businesses'], ['100k+', 'monthly visitors'], ['24h', 'listing approval']].map(([v, l]) => <div key={l}><b className="text-2xl block">{v}</b><span className="text-white/70">{l}</span></div>)}</div>
    </PageHero>
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className={`grid gap-6 items-stretch ${plans.length >= 4 ? 'md:grid-cols-2 lg:grid-cols-4' : plans.length === 2 ? 'md:grid-cols-2 max-w-3xl mx-auto' : 'md:grid-cols-3'}`}>{plans.map((x) => (
        <div key={x.n} className={`card p-7 flex flex-col relative ${x.best ? 'border-2 border-accent shadow-2xl md:-translate-y-3' : ''}`}>
          {x.best && <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-accent text-white text-[10px] font-bold px-3 py-1 rounded-b-full">MOST POPULAR</span>}
          <Ribbon off={pct(x.price, x.mrp)} />
          <h3 className="font-bold text-lg">{x.n}</h3>
          <div className="mt-3">{x.price == null ? <b className="text-4xl">—</b> : <Price price={x.price} mrp={x.mrp} unit={x.per === 'forever' ? '' : x.per || ''} big="text-4xl" badge={false} />}{x.per === 'forever' && <span className="text-gray-500 text-sm">forever</span>}</div>
          <ul className="text-sm space-y-2.5 mt-6 flex-1">{x.feats.map((f: string) => <li key={f} className="flex gap-2"><span className="text-emerald-500"><E c="✔"/></span>{f}</li>)}{x.no.map((f: string) => <li key={f} className="flex gap-2 text-gray-400"><span><E c="✕"/></span>{f}</li>)}</ul>
          <Link href={x.href} className={`btn mt-7 !py-3 ${x.tone === 'accent' ? 'btn-accent' : x.tone === 'brand' ? 'btn-brand' : 'btn-ghost'}`}>{x.cta}</Link>
        </div>))}</div>
      <div className="grid md:grid-cols-3 gap-4 mt-12">{[['1', 'Register with mobile', 'Sign up with your number in 30 seconds.'], ['2', 'Upload your licence', 'Trade License / FSSAI / KMC certificate.'], ['3', 'Go live after review', 'Our team verifies & publishes within 24h.']].map(([n, t, d]) => (
        <div key={n} className="flex gap-4"><span className="w-10 h-10 rounded-full bg-brand text-white font-black flex items-center justify-center shrink-0">{n}</span><div><b>{t}</b><p className="text-sm text-gray-500">{d}</p></div></div>))}</div>
      <p className="text-center text-xs text-gray-500 mt-10">Secure payments via Razorpay — UPI (GPay, PhonePe, Paytm), NetBanking & Cards.</p>
    </div>
  </div>);
}
