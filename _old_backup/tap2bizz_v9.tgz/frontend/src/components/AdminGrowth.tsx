'use client';
import { E, T } from '@/components/Icon';
import { useState } from 'react';
import { api, useFetch } from '@/lib/api';

const ST = ['new', 'contacted', 'won', 'lost'];
const stCol: any = { new: 'bg-amber-100 text-amber-700', contacted: 'bg-blue-100 text-blue-700', won: 'bg-emerald-100 text-emerald-700', lost: 'bg-slate-100 text-slate-500' };

export function BoostersAdmin() {
  const [sub, setSub] = useState('leads');
  return (<div><div className="flex gap-2 mb-4">{[['leads', '📞 Sales leads'], ['cat', '📋 Category leads'], ['catalog', '🧩 Booster catalogue']].map(([k, l]) => <button key={k} onClick={() => setSub(k)} className={`px-4 py-2 rounded-xl text-xs font-bold ${sub === k ? 'bg-blue-600 text-white' : 'bg-white border border-slate-200 text-slate-500'}`}><T>{l}</T></button>)}</div>
    {sub === 'leads' ? <Leads /> : sub === 'cat' ? <CatLeads /> : <Catalog />}</div>);
}
function Leads() {
  const d = useFetch<any[]>('/admin/booster-requests'); const [f, setF] = useState('all'); const [notes, setNotes] = useState<any>({});
  const set = async (r: any, status: string) => { try { await api(`/admin/booster-requests/${r._id}`, { method: 'PUT', body: { status, adminNote: notes[r._id] ?? r.adminNote ?? '' } }); d.reload(); } catch (e: any) { alert(e.message); } };
  const rows = (d.data || []).filter((r) => f === 'all' || r.status === f || (f === 'website' && r.key === 'website'));
  return (<div><p className="text-sm text-slate-500 mb-3">Local businesses asking for add-ons — especially <b>Get Your Business Website</b> — land here as sales leads. Call them and update the status.</p>
    <div className="flex gap-2 mb-3 overflow-x-auto">{['all', 'website', ...ST].map((s) => <button key={s} onClick={() => setF(s)} className={`px-3 py-1.5 rounded-full text-xs font-bold capitalize whitespace-nowrap ${f === s ? 'bg-slate-800 text-white' : 'bg-white border border-slate-200 text-slate-500'}`}>{s === 'website' ? '🌐 website leads' : s}</button>)}</div>
    <div className="space-y-3">{rows.map((r) => (<div key={r._id} className="bg-white rounded-2xl p-4 border border-slate-100">
      <div className="flex flex-wrap justify-between gap-2"><div className="min-w-0"><b>{r.title}</b> <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${stCol[r.status]}`}>{r.status}</span><p className="text-sm text-slate-600 mt-1">{r.businessName} · <a className="text-blue-600 font-semibold" href={`tel:${r.phone}`}><E c="📞"/> {r.phone}</a></p>{r.note && <p className="text-xs text-slate-500 mt-1">“{r.note}”</p>}<p className="text-[11px] text-slate-400 mt-1">{new Date(r.createdAt).toLocaleString('en-IN')}</p></div>
        <div className="flex gap-1 flex-wrap items-start">{ST.filter((s) => s !== r.status).map((s) => <button key={s} onClick={() => set(r, s)} className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-50 hover:bg-slate-100 capitalize">{s}</button>)}</div></div>
      <input className="input mt-2 !text-xs" maxLength={500} placeholder="Internal note (call outcome, quote…)" defaultValue={r.adminNote || ''} onChange={(e) => setNotes({ ...notes, [r._id]: e.target.value })} onBlur={() => notes[r._id] !== undefined && set(r, r.status)} /></div>))}
      {!rows.length && <p className="text-slate-400 text-sm">No leads yet.</p>}</div></div>);
}
function Catalog() {
  const d = useFetch<any[]>('/admin/boosters'); const [e, setE] = useState<any>(null);
  const save = async (ev: React.FormEvent) => { ev.preventDefault(); try { const body = { ...e, price: Number(e.price), mrp: Number(e.mrp || 0), benefits: String(e.benefits || '').split('\n') }; if (e._id) await api(`/admin/boosters/${e._id}`, { method: 'PUT', body }); else await api('/admin/boosters', { body }); setE(null); d.reload(); } catch (er: any) { alert(er.message); } };
  const toggle = async (b: any) => { try { await api(`/admin/boosters/${b._id}`, { method: 'PUT', body: { ...b, active: !b.active } }); d.reload(); } catch (er: any) { alert(er.message); } };
  return (<div><div className="flex justify-between mb-3"><p className="text-sm text-slate-500">Prices, MRP, tags and benefits shown to vendors.</p><button onClick={() => setE({ key: '', title: '', tag: '', unit: 'day', price: '', mrp: '', kind: 'request', color: '#e0e7ff', benefits: '', order: 50, active: true })} className="btn btn-brand !text-xs">+ New booster</button></div>
    <div className="grid sm:grid-cols-2 gap-3">{d.data?.map((b) => (<div key={b._id} className={`bg-white rounded-2xl p-4 border border-slate-100 ${b.active ? '' : 'opacity-50'}`}><div className="flex justify-between gap-2"><div><b>{b.title}</b> {b.tag && <span className="text-[10px] bg-purple-100 text-purple-700 font-bold px-1.5 rounded">{b.tag}</span>}<p className="text-sm">₹{b.price}{b.mrp > b.price && <s className="text-slate-400 ml-1">₹{b.mrp}</s>} /{b.unit} · <span className="text-xs text-slate-500">{b.kind}</span></p></div>
      <div className="flex gap-1 shrink-0 items-start"><button onClick={() => setE({ ...b, benefits: (b.benefits || []).join('\n') })} className="text-xs font-bold text-blue-600">Edit</button><button onClick={() => toggle(b)} className="text-xs font-bold text-slate-500">{b.active ? 'Hide' : 'Show'}</button></div></div></div>))}</div>
    {e && <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-3" onClick={() => setE(null)}><form onSubmit={save} onClick={(x) => x.stopPropagation()} className="bg-white rounded-2xl p-5 w-full max-w-md space-y-2 max-h-[92vh] overflow-y-auto"><h3 className="font-bold">{e._id ? 'Edit' : 'New'} booster</h3>
      {!e._id && <input required className="input" placeholder="Key (e.g. google-ads)" value={e.key} onChange={(x) => setE({ ...e, key: x.target.value })} />}
      <input required className="input" placeholder="Title" value={e.title} onChange={(x) => setE({ ...e, title: x.target.value })} />
      <div className="grid grid-cols-2 gap-2"><input type="number" min={0} required className="input" placeholder="Price ₹" value={e.price} onChange={(x) => setE({ ...e, price: x.target.value })} /><input type="number" min={0} className="input" placeholder="MRP ₹" value={e.mrp} onChange={(x) => setE({ ...e, mrp: x.target.value })} />
        <select className="input" value={e.unit} onChange={(x) => setE({ ...e, unit: x.target.value })}>{['day', 'month', 'year', 'certificate'].map((u) => <option key={u}>{u}</option>)}</select>
        <select className="input" value={e.kind} onChange={(x) => setE({ ...e, kind: x.target.value })}><option value="request">request (call back)</option><option value="activate">activate (pay online)</option><option value="link">link (banner ads)</option></select>
        <input className="input" maxLength={20} placeholder="Tag (Recommended)" value={e.tag} onChange={(x) => setE({ ...e, tag: x.target.value })} /><input type="color" className="input !p-1 h-10" value={e.color} onChange={(x) => setE({ ...e, color: x.target.value })} /></div>
      <textarea rows={4} className="input" placeholder="Benefits — one per line (max 6)" value={e.benefits} onChange={(x) => setE({ ...e, benefits: x.target.value })} />
      <div className="flex gap-2"><button className="btn btn-brand flex-1">Save</button><button type="button" onClick={() => setE(null)} className="btn btn-ghost">Cancel</button></div></form></div>}
  </div>);
}

export function PartnerAdmin() {
  const d = useFetch<any>('/admin/partner'); const [pct, setPct] = useState<string | null>(null);
  if (!d.data) return null; const cfg = d.data.cfg;
  const save = async (enabled: boolean) => { try { await api('/admin/partner', { method: 'PUT', body: { enabled, pct: Number(pct ?? cfg.pct) } }); setPct(null); d.reload(); } catch (e: any) { alert(e.message); } };
  const pay = async (c: any) => { try { await api(`/admin/commissions/${c._id}`, { method: 'PUT', body: { status: c.status === 'paid' ? 'pending' : 'paid' } }); d.reload(); } catch (e: any) { alert(e.message); } };
  const owed = d.data.commissions.filter((c: any) => c.status !== 'paid').reduce((s: number, c: any) => s + c.amount, 0);
  return (<div className="space-y-4"><div className="bg-white rounded-2xl p-4 border border-slate-100 flex flex-wrap items-end gap-3"><div><label className="label">Commission % on referred Premium purchases</label><input type="number" min={0} max={50} className="input w-32" value={pct ?? cfg.pct} onChange={(e) => setPct(e.target.value)} /></div>
    <button onClick={() => save(cfg.enabled)} className="btn btn-brand !text-xs">Save</button><button onClick={() => save(!cfg.enabled)} className={`btn !text-xs ${cfg.enabled ? 'btn-ghost' : 'btn-accent'}`}>{cfg.enabled ? 'Pause programme' : 'Enable programme'}</button><span className="ml-auto text-sm font-bold">Pending payout: ₹{owed}</span></div>
    <div className="bg-white rounded-2xl border border-slate-100 overflow-x-auto"><table className="w-full text-sm"><thead className="bg-slate-50 text-left"><tr><th className="p-3">Partner</th><th>Business</th><th>Amount</th><th>Status</th><th /></tr></thead><tbody>{d.data.commissions.map((c: any) => <tr key={c._id} className="border-t"><td className="p-3">{c.partner}</td><td>{c.businessName}</td><td>₹{c.amount} ({c.pct}%)</td><td>{c.status}</td><td><button onClick={() => pay(c)} className="text-xs font-bold text-blue-600 pr-3">{c.status === 'paid' ? 'Undo' : 'Mark paid'}</button></td></tr>)}
      {!d.data.commissions.length && <tr><td colSpan={5} className="p-4 text-slate-400">No commissions yet.</td></tr>}</tbody></table></div></div>);
}

export function OfferCard({ o, act }: { o: any; act: (path: string, body: any) => void }) {
  return (<div className="bg-white rounded-2xl p-5 border border-slate-100 flex flex-wrap justify-between gap-3"><div className="min-w-0"><b>{o.title}</b>{o.code && <span className="ml-2 text-xs font-mono bg-slate-100 px-2 rounded">{o.code}</span>}<p className="text-sm text-slate-600">{o.subtitle}</p><p className="text-xs text-slate-400 mt-1">{o.businessName} · till {o.expiry}</p></div>
    <div className="flex gap-2 items-start"><button onClick={() => act(`/admin/offers-review/${o._id}`, { action: 'approve' })} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold"><E c="✔"/> Approve</button><button onClick={() => act(`/admin/offers-review/${o._id}`, { action: 'reject' })} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold"><E c="✕"/> Reject</button></div></div>);
}

function CatLeads() {
  const d = useFetch<any[]>('/admin/category-leads');
  const set = async (r: any, status: string) => { try { await api(`/admin/category-leads/${r._id}`, { method: 'PUT', body: { status } }); d.reload(); } catch (e: any) { alert(e.message); } };
  return (<div><p className="text-sm text-slate-500 mb-3">Visitors who tapped “Get the list of Top …” on a category page. Send them the list.</p>
    <div className="bg-white rounded-2xl border border-slate-100 overflow-x-auto"><table className="w-full text-sm"><thead className="bg-slate-50 text-left"><tr><th className="p-3">Category</th><th>Name</th><th>Mobile</th><th>City</th><th>Status</th></tr></thead><tbody>{d.data?.map((r) => <tr key={r._id} className="border-t"><td className="p-3">{r.topic}</td><td>{r.name}</td><td><a className="text-blue-600" href={`tel:${r.phone}`}>{r.phone}</a></td><td>{r.city}</td>
      <td><select value={r.status} onChange={(e) => set(r, e.target.value)} className="border rounded-lg text-xs p-1">{ST.map((s) => <option key={s}>{s}</option>)}</select></td></tr>)}{!d.data?.length && <tr><td colSpan={5} className="p-4 text-slate-400">No requests yet.</td></tr>}</tbody></table></div></div>);
}

const OST = ['new', 'confirmed', 'ready', 'delivered', 'cancelled'];
const OCOL: Record<string, string> = { new: 'bg-blue-50 text-blue-700 border-blue-200', confirmed: 'bg-amber-50 text-amber-700 border-amber-200', ready: 'bg-violet-50 text-violet-700 border-violet-200', delivered: 'bg-emerald-50 text-emerald-700 border-emerald-200', cancelled: 'bg-red-50 text-red-600 border-red-200' };
export function OrdersAdmin() {
  const d = useFetch<any[]>('/admin/orders'); const [f, setF] = useState('all'); const [q, setQ] = useState('');
  const set = async (o: any, status: string) => { try { await api(`/admin/orders/${o._id}`, { method: 'PUT', body: { status } }); d.reload(); } catch (e: any) { alert(e.message); } };
  const all = d.data || [];
  const rows = all.filter((o) => (f === 'all' || o.status === f) && (!q || JSON.stringify([o.orderNo, o.businessName, o.name, o.phone]).toLowerCase().includes(q.toLowerCase())));
  const cnt = (s: string) => all.filter((o) => o.status === s).length;
  const paid = all.filter((o) => o.status === 'delivered').reduce((s, o) => s + (o.total || 0), 0);
  return (<div>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">{[['Total orders', all.length, 'text-slate-800'], ['New', cnt('new'), 'text-blue-600'], ['Delivered', cnt('delivered'), 'text-emerald-600'], ['Delivered value', `₹${paid}`, 'text-slate-800']].map(([l, v, c]) =>
      <div key={String(l)} className="bg-white rounded-2xl border border-slate-100 p-4"><p className="text-xs text-slate-500">{l}</p><p className={`text-2xl font-extrabold mt-1 ${c}`}>{v}</p></div>)}</div>
    <div className="flex flex-wrap gap-2 mb-4 items-center"><input className="input !w-full md:!w-64" placeholder="Search order / business / phone" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar">{['all', ...OST].map((s) => <button key={s} onClick={() => setF(s)} className={`px-3.5 py-1.5 rounded-full text-xs font-bold capitalize whitespace-nowrap ${f === s ? 'bg-slate-800 text-white' : 'bg-white border border-slate-200 text-slate-500'}`}>{s}{s !== 'all' && <span className="opacity-60"> {cnt(s)}</span>}</button>)}</div></div>
    <div className="grid lg:grid-cols-2 gap-3">
      {rows.map((o) => <div key={o._id} className="bg-white rounded-2xl border border-slate-100 p-4 hover:shadow-sm transition">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0"><div className="flex items-center gap-2 flex-wrap"><b className="text-slate-800">#{o.orderNo}</b><span className={`text-[11px] font-bold px-2 py-0.5 rounded-full border capitalize ${OCOL[o.status] || ''}`}>{o.status}</span>{o.type && <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 capitalize">{o.type}</span>}</div>
            <p className="text-sm font-semibold text-slate-700 mt-1 truncate">{o.businessName}</p><p className="text-[11px] text-slate-400">{new Date(o.createdAt).toLocaleString('en-IN')} · via {o.via}</p></div>
          {o.total > 0 && <b className="text-lg text-slate-800 shrink-0 text-right">₹{o.total}{o.code && <span className="block text-[11px] font-semibold text-emerald-600">{o.code} · {o.offerLabel} (−₹{o.discount})</span>}</b>}
        </div>
        <div className="flex flex-wrap gap-1.5 mt-3">{(o.items || []).map((i: any, k: number) => <span key={k} className="text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1">{i.name} <b>× {i.qty}</b></span>)}</div>
        {(o.address || o.note) && <p className="text-xs text-slate-500 mt-2">{o.address && <>📍 {o.address} </>}{o.note && <>· “{o.note}”</>}</p>}
        <div className="flex items-center justify-between gap-2 mt-3 pt-3 border-t border-slate-100 flex-wrap">
          <div className="text-sm"><b className="text-slate-700">{o.name}</b> <a className="text-blue-600 ml-1" href={`tel:${o.phone}`}>{o.phone}</a> <a className="text-emerald-600 ml-2 text-xs font-semibold" target="_blank" href={`https://wa.me/91${o.phone}`}>WhatsApp</a></div>
          <select value={o.status} onChange={(e) => set(o, e.target.value)} className="border border-slate-200 rounded-lg text-xs px-2 py-1.5 bg-slate-50 capitalize">{OST.map((s) => <option key={s}>{s}</option>)}</select>
        </div>
      </div>)}
    </div>
    {!rows.length && <div className="bg-white rounded-2xl border border-slate-100 p-10 text-center text-slate-400">No orders yet.</div>}
  </div>);
}
