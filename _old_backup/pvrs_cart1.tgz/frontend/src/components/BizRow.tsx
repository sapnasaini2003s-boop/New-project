'use client';
// Justdial / Yellow-Pages style horizontal result card
import Link from 'next/link';
import { img } from '@/lib/api';
import { track } from './BizCard';
import { openNow } from './Hours';

export default function BizRow({ b }: { b: any }) {
  return (
    <div className="card p-3 md:p-4 flex gap-3 md:gap-5 hover:shadow-lg transition">
      <Link href={`/business/${b._id}`} className="relative w-24 h-24 md:w-48 md:h-36 rounded-xl overflow-hidden bg-gradient-to-br from-blue-50 to-orange-50 shrink-0 flex items-center justify-center text-4xl">
        {b.profileImage ? <img src={img(b.profileImage)} alt={b.name} className="w-full h-full object-cover text-[0px]" onError={(e) => { e.currentTarget.style.display = "none"; }} /> : '🏪'}
        {b.plan === 'premium' && <span className="absolute top-1.5 left-1.5 bg-accent text-white text-[9px] md:text-[10px] font-bold px-1.5 py-0.5 rounded">PREMIUM</span>}
      </Link>
      <div className="flex-1 min-w-0 flex flex-col">
        <div className="flex items-start gap-2">
          <Link href={`/business/${b._id}`} className="font-bold text-base md:text-xl text-gray-900 hover:text-brand leading-tight line-clamp-2">{b.name}</Link>
          {b.verified && <span className="shrink-0 mt-0.5 bg-emerald-50 text-emerald-700 text-[10px] font-bold px-1.5 py-0.5 rounded border border-emerald-200">✔ Verified</span>}
          {b.trustSeal && <span className="shrink-0 mt-0.5 bg-amber-50 text-amber-800 text-[10px] font-bold px-1.5 py-0.5 rounded border border-amber-200">🛡 Trust Seal</span>}
        </div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1.5 text-xs md:text-sm">
          {b.rating > 0 && <span className="flex items-center gap-1"><span className="bg-emerald-600 text-white font-bold px-1.5 py-0.5 rounded text-xs">{Number(b.rating).toFixed(1)}★</span><span className="text-gray-500">{b.reviews} ratings</span></span>}
          <span className="text-gray-500">📍 {b.city}</span>
        </div>
        <p className="text-xs md:text-sm text-gray-600 mt-1.5">{b.subCategory}{(() => { const o = openNow(b.hours); return o && <span className={`ml-2 font-semibold ${o.open ? 'text-emerald-600' : 'text-red-500'}`}>· {o.label}</span>; })()}</p>
        {b.description && <p className="hidden md:block text-sm text-gray-500 mt-1 line-clamp-1">{b.description}</p>}
        {b.distanceKm != null && <p className="text-xs text-brand font-semibold mt-1">📍 {b.distanceKm} km away</p>}
        {b.contactLocked && <p className="text-xs text-gray-500 mt-1 font-mono tracking-wide">📞 XXXXXXXXXX <span title="Shown on Premium listings">🔒</span></p>}
        {b.unclaimed && <Link href={`/business/${b._id}#claim`} className="flash text-[11px] font-bold text-accent mt-1">⚠ Is this your business? Claim it now!</Link>}
        {(() => { const ph = [...(b.gallery || [])].slice(0, 3); return ph.length > 1 ? <div className="flex gap-1.5 mt-2 overflow-hidden">{ph.map((g: string) => <img key={g} src={img(g)} alt="" loading="lazy" className="h-14 md:h-16 w-1/3 max-w-[7rem] rounded-lg object-cover bg-gray-100" onError={(e) => { e.currentTarget.style.display = 'none'; }} />)}</div> : null; })()}
        <div className="flex flex-wrap gap-1.5 mt-2 text-[11px]">
          {b.rating >= 4.5 && <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-semibold">⭐ Top rated</span>}
          {b.info?.year && <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-700">{new Date().getFullYear() - Number(b.info.year)}+ yrs in business</span>}
          {b.orderOnline && <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700">✓ Delivery</span>}
          {b.hasMenu && <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700">🍽 Menu available</span>}
          {b.info?.payments?.includes('UPI') && <span className="px-2 py-0.5 rounded-full bg-purple-50 text-purple-700">UPI accepted</span>}
        </div>
        <div className="flex flex-wrap gap-2 mt-auto pt-2.5">
          {b.contact ? (<>
            <a href={`tel:${b.contact.phone}`} onClick={() => track(b._id, 'call')} className="btn btn-brand !py-1.5 !px-3 !text-xs md:!text-sm flex items-center justify-center gap-1.5"><svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 md:w-4 md:h-4"><path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 00-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg> {b.contact.phone}</a>
            <a href={`https://wa.me/91${b.contact.whatsapp || b.contact.phone}`} target="_blank" onClick={() => track(b._id, 'whatsapp')} className="btn bg-green-500 hover:bg-green-600 text-white !py-1.5 !px-3 !text-xs md:!text-sm flex items-center justify-center gap-1.5"><svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 md:w-4 md:h-4"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg> WhatsApp</a>
          </>) : <Link href={`/business/${b._id}#enquiry`} className="btn btn-accent !py-1.5 !px-3 !text-xs md:!text-sm">✉️ Send Enquiry</Link>}
          <Link href={`/business/${b._id}`} className="btn btn-ghost !py-1.5 !px-3 !text-xs md:!text-sm">View details</Link>
        </div>
      </div>
    </div>
  );
}
