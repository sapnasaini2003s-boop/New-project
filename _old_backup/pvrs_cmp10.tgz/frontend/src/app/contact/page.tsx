'use client';
import { useState } from 'react';
import { api, useConfig } from '@/lib/api';
import PageHero from '@/components/PageHero';
export default function Contact() {
  const { f: cf } = useConfig();
  const [f, setF] = useState<any>({ type: 'general' }); const [msg, setMsg] = useState(''); const [ok, setOk] = useState(false); const [busy, setBusy] = useState(false);
  const send = async (e: React.FormEvent) => { e.preventDefault(); setBusy(true); try { setMsg((await api('/contact', { body: f })).message); setOk(true); setF({ type: 'general' }); } catch (er: any) { setMsg(er.message); setOk(false); } setBusy(false); };
  return (<div>
    <PageHero title="Contact & Help" icon="💬" subtitle="Questions about listings, advertising or a complaint? We usually reply within 24 hours." />
    <div className="max-w-6xl mx-auto px-4 py-10 grid lg:grid-cols-[1fr_1.3fr] gap-8">
      <div className="space-y-4">
        {[['📧', 'Email support', 'support@yourdomain.in', 'mailto:support@yourdomain.in'], ['⚖️', 'Grievance Officer (IT Act)', 'legal@yourdomain.in', 'mailto:legal@yourdomain.in'], ['📢', 'Advertising', 'See plans & pricing', '/advertise'], ['📍', 'Office', 'Udupi, Karnataka, India', '#']].map(([i, t, d, h]) => (
          <a key={t} href={h} className="card p-5 flex gap-4 items-center hover:shadow-md hover:border-brand/30 transition"><span className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-2xl">{i}</span><span><b className="block text-gray-900">{t}</b><span className="text-sm text-gray-500">{d}</span></span></a>))}
        <div className="card p-5 bg-orange-50 border-orange-200 text-sm text-orange-900"><b>Takedown requests</b> are acknowledged within 24 hours and resolved within 15 days, as per IT (Intermediary Guidelines) Rules 2021.</div>
      </div>
      <form onSubmit={send} className="card p-6 md:p-8 shadow-sm space-y-4">
        <h2 className="text-xl font-black">Send us a message</h2>
        <div className={`grid gap-2 ${cf.complaintForm ? 'grid-cols-3' : 'grid-cols-2'}`}>{[['general', '💬 General'], ['advertise', '📢 Advertising'], ...(cf.complaintForm ? [['complaint', '🚩 Complaint']] : [])].map(([v, l]) => (
          <button type="button" key={v} onClick={() => setF({ ...f, type: v })} className={`rounded-xl border py-2.5 text-xs md:text-sm font-semibold ${f.type === v ? 'border-brand bg-blue-50 text-brand' : 'text-gray-600'}`}>{l}</button>))}</div>
        <div className="grid md:grid-cols-2 gap-3">
          <div><label className="label">Your name</label><input required className="input" value={f.name || ''} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div><label className="label">Mobile</label><input className="input" inputMode="numeric" maxLength={10} value={f.phone || ''} onChange={(e) => setF({ ...f, phone: e.target.value.replace(/\D/g, '') })} /></div>
        </div>
        <div><label className="label">Message</label><textarea required rows={5} className="input" value={f.message || ''} onChange={(e) => setF({ ...f, message: e.target.value })} /></div>
        <button disabled={busy} className="btn btn-brand w-full !py-3">{busy ? 'Sending…' : 'Send message'}</button>
        {msg && <p className={`text-sm text-center ${ok ? 'text-emerald-600' : 'text-red-600'}`}>{msg}</p>}
      </form>
    </div>
  </div>);
}
