'use client';
import { useState } from 'react';
import { api, img, useFetch } from '@/lib/api';
import { HoursPicker, TagInput, defaultHours, summarize, type Hours } from './Hours';

const CITIES = ['Udupi', 'Manipal', 'Malpe', 'Mangaluru', 'Kundapura', 'Karkala'];

export default function ListingForm({ initial, premium, onDone }: { initial?: any; premium?: boolean; onDone: (msg: string) => void }) {
  const { data: cats } = useFetch<any[]>('/categories');
  const v = { ...(initial || {}), ...(initial?.pendingUpdates || {}) };
  const [f, setF] = useState<any>({
    name: v.name || '', category: v.category || '', subCategory: v.subCategory || '', city: v.city || 'Udupi', address: v.address || '',
    description: v.description || '', timings: v.timings || '', tags: (v.tags || []).join(', '),
    phone: v.contact?.phone || '', whatsapp: v.contact?.whatsapp || '', email: v.contact?.email || '',
    swiggy: v.orderOnline?.swiggy || '', zomato: v.orderOnline?.zomato || '',
    youtube: v.videos?.youtube || '', facebook: v.videos?.facebook || '', instagram: v.videos?.instagram || '',
    docType: v.documents?.type || 'Trade License', docNumber: v.documents?.number || '', docExpiry: v.documents?.expiry || '',
  });
  const [files, setFiles] = useState<any>({});
  const [hours, setHours] = useState<Hours>(v.hours || defaultHours());
  const [tags, setTags] = useState<string[]>(v.tags || []);
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });
  const cat = cats?.find((c) => c.slug === f.category);
  const edit = !!initial;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr('');
    if (!edit && !files.document) return setErr('Verification document is mandatory');
    const fd = new FormData();
    ['name', 'category', 'subCategory', 'city', 'address', 'description', 'docType', 'docNumber', 'docExpiry'].forEach((k) => fd.append(k, f[k]));
    fd.append('hours', JSON.stringify(hours)); fd.append('timings', summarize(hours)); fd.append('tags', tags.join(','));
    fd.append('contact', JSON.stringify({ phone: f.phone, whatsapp: f.whatsapp, email: f.email }));
    if (/food|restaurant/.test(f.category)) fd.append('orderOnline', JSON.stringify({ swiggy: f.swiggy, zomato: f.zomato }));
    if (premium) { fd.append('videos', JSON.stringify({ youtube: f.youtube, facebook: f.facebook, instagram: f.instagram })); fd.append('keepGallery', JSON.stringify(v.gallery || [])); }
    if (files.profileImage) fd.append('profileImage', files.profileImage[0]);
    if (files.document) fd.append('document', files.document[0]);
    if (premium && files.bannerImage) fd.append('bannerImage', files.bannerImage[0]);
    if (premium && files.gallery) Array.from(files.gallery as FileList).forEach((g) => fd.append('gallery', g));
    setBusy(true);
    try {
      const r = edit ? await api(`/vendor/listings/${initial._id}`, { method: 'PUT', form: fd }) : await api('/vendor/listings', { form: fd });
      onDone(r.message);
    } catch (e: any) { setErr(e.message); }
    setBusy(false);
  };
  const file = (k: string, multiple = false, accept = '.jpg,.jpeg,.png,.webp', isReq = false) => (
    <input type="file" required={isReq} accept={accept} multiple={multiple} className="input" onChange={(e) => setFiles({ ...files, [k]: e.target.files })} />
  );

  return (
    <form onSubmit={submit} className="space-y-5">
      <section className="card p-4 md:p-6 grid md:grid-cols-2 gap-4">
        <h2 className="md:col-span-2 font-bold">Business details</h2>
        <div className="md:col-span-2"><label className="label">Business name *</label><input required className="input" value={f.name} onChange={set('name')} /></div>
        <div><label className="label">Category *</label>
          <select required className="input" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value, subCategory: '' })}>
            <option value="">Select</option>{cats?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select></div>
        <div><label className="label">Sub-category *</label>
          <select required className="input" value={f.subCategory} onChange={set('subCategory')}>
            <option value="">Select</option>{cat?.subs.map((s: string) => <option key={s}>{s}</option>)}
          </select></div>
        <div><label className="label">City *</label><select className="input" value={f.city} onChange={set('city')}>{CITIES.map((c) => <option key={c}>{c}</option>)}</select></div>
        <div><label className="label">Address</label><input className="input" value={f.address} onChange={set('address')} /></div>
        <div className="md:col-span-2"><label className="label">Description</label><textarea rows={3} className="input" value={f.description} onChange={set('description')} /></div>
        <div className="md:col-span-2"><label className="label">Business hours <span className="font-normal text-gray-400">— set each day, tap the clock to pick a time</span></label><HoursPicker value={hours} onChange={setHours} />
          <p className="text-xs text-gray-500 mt-1.5">Shown as: {summarize(hours)}</p></div>
        <div className="md:col-span-2"><label className="label">Keywords <span className="font-normal text-gray-400">— press Enter or comma after each (helps customers find you)</span></label><TagInput value={tags} onChange={setTags} placeholder="e.g. dosa, south indian, family restaurant" /></div>
      </section>

      <section className="card p-4 md:p-6 grid md:grid-cols-3 gap-4">
        <h2 className="md:col-span-3 font-bold">Contact <span className="text-xs font-normal text-gray-500">(Call/WhatsApp buttons show publicly only on Premium plan)</span></h2>
        <div><label className="label">Phone</label><input type="tel" pattern="[0-9]{10}" title="10 digit mobile number" className="input" maxLength={10} value={f.phone} onChange={set('phone')} /></div>
        <div><label className="label">WhatsApp</label><input type="tel" pattern="[0-9]{10}" title="10 digit mobile number" className="input" maxLength={10} value={f.whatsapp} onChange={set('whatsapp')} /></div>
        <div><label className="label">Email</label><input type="email" className="input" value={f.email} onChange={set('email')} /></div>
        {/food|restaurant/.test(f.category) && (<>
          <div className="md:col-span-3 font-semibold text-sm">🛵 Order Online links</div>
          <div><label className="label">Swiggy URL</label><input type="url" placeholder="https://" className="input" value={f.swiggy} onChange={set('swiggy')} /></div>
          <div><label className="label">Zomato URL</label><input type="url" placeholder="https://" className="input" value={f.zomato} onChange={set('zomato')} /></div>
        </>)}
      </section>

      <section className="card p-4 md:p-6 grid md:grid-cols-2 gap-4">
        <h2 className="md:col-span-2 font-bold">Media</h2>
        <div><label className="label">Profile image / logo (1 image) {!edit && '*'}</label>{v.profileImage && <img src={img(v.profileImage)} alt="" className="h-16 mb-2 rounded" />}{file('profileImage', false, '.jpg,.jpeg,.png,.webp', !edit)}</div>
        <div className={premium ? '' : 'opacity-50'}>
          <label className="label">Gallery images {!premium && '🔒 Premium'}</label>
          {premium ? file('gallery', true) : <p className="text-xs text-gray-500">Free plan allows only one profile image. Upgrade for gallery, header banner & videos.</p>}
        </div>
        {premium && (<>
          <div><label className="label">Header banner image</label>{file('bannerImage')}</div>
          <div><label className="label">YouTube video URL</label><input type="url" placeholder="https://" className="input" value={f.youtube} onChange={set('youtube')} /></div>
          <div><label className="label">Facebook Watch URL</label><input type="url" placeholder="https://" className="input" value={f.facebook} onChange={set('facebook')} /></div>
          <div><label className="label">Instagram Reel URL</label><input type="url" placeholder="https://" className="input" value={f.instagram} onChange={set('instagram')} /></div>
        </>)}
      </section>

      <section className="card p-4 md:p-6 grid md:grid-cols-2 gap-4 border-brand">
        <h2 className="md:col-span-2 font-bold">Upload Trade License / FSSAI / KMC Registration Certificate {!edit && '*'}</h2>
        <div><label className="label">Document type *</label>
          <select required className="input" value={f.docType} onChange={set('docType')}>{['Trade License', 'FSSAI', 'KMC Registration Certificate', 'Other Govt. Registration'].map((d) => <option key={d}>{d}</option>)}</select></div>
        <div><label className="label">Certificate number *</label><input required className="input" value={f.docNumber} onChange={set('docNumber')} /></div>
        <div><label className="label">Valid till (expiry date) *</label><input required type="date" className="input" value={f.docExpiry?.slice(0, 10)} onChange={set('docExpiry')} /></div>
        <div><label className="label">File (JPG, PNG or PDF, max 5MB) {!edit && '*'}</label>{file('document', false, '.jpg,.jpeg,.png,.pdf', !edit)}</div>
      </section>

      {err && <p className="text-red-600 text-sm font-medium">{err}</p>}
      <p className="text-xs text-gray-500">By submitting you accept the Business Terms of Use. All new listings and edits are reviewed by our admin before going live.</p>
      <button disabled={busy} className="btn btn-accent w-full md:w-auto">{busy ? 'Submitting…' : edit ? 'Submit changes for review' : 'Submit for verification'}</button>
    </form>
  );
}
