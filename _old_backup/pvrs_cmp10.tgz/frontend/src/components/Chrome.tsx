'use client';
// Site-wide chrome: footer, mobile bottom app bar, right-edge sticky tabs
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';

import { useConfig } from '@/lib/api';

// Announcement / maintenance strip (Admin → Feature Controls)
export function TopBar() {
  const p = usePathname(); const { cfg, f } = useConfig();
  if (p.startsWith('/admin')) return null;
  if (f.maintenance) return <div className="bg-red-600 text-white text-center text-xs md:text-sm py-2 px-3 font-medium">🛠️ We&apos;re doing scheduled maintenance — browsing works, new submissions are paused for a while.</div>;
  if (cfg?.announcement) return <div className="bg-accent text-white text-center text-xs md:text-sm py-2 px-3 font-medium">{cfg.announcement}</div>;
  return null;
}

export function StickyTabs() {
  const p = usePathname(); if (p.startsWith('/admin')) return null;
  return (
    <div className="hidden md:flex fixed right-0 top-1/3 z-30 flex-col gap-1">
      <Link href="/advertise" className="bg-accent text-white text-xs font-bold px-2 py-4 rounded-l-lg shadow-lg [writing-mode:vertical-rl] rotate-180 hover:pr-3 transition-all">Advertise</Link>
      <Link href="/register-business" className="bg-brand text-white text-xs font-bold px-2 py-4 rounded-l-lg shadow-lg [writing-mode:vertical-rl] rotate-180 hover:pr-3 transition-all">Free Listing</Link>
    </div>
  );
}

export function BottomBar() {
  const p = usePathname(); const [more, setMore] = useState(false);
  if (p.startsWith('/admin')) return null;
  const items = [['🏠', 'Home', '/'], ['🔍', 'Search/B2B', '/search'], ['📰', 'News/Feed', '/blogs']];
  return (
    <>
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t grid grid-cols-4 text-[11px] font-medium shadow-[0_-2px_8px_rgba(0,0,0,.06)]">
        {items.map(([i, n, h]) => (
          <Link key={n} href={h} className={`flex flex-col items-center py-2 ${p === h ? 'text-brand' : 'text-gray-600'}`}><span className="text-lg">{i}</span>{n}</Link>
        ))}
        <button onClick={() => setMore(true)} className="flex flex-col items-center py-2 text-gray-600"><span className="text-lg">☰</span>More</button>
      </nav>
      {more && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/40" onClick={() => setMore(false)}>
          <div className="absolute bottom-0 inset-x-0 bg-white rounded-t-2xl p-4 slideup grid grid-cols-3 gap-3 text-sm" onClick={(e) => e.stopPropagation()}>
            {[['📂', 'Categories', '/categories'], ['🏷️', 'Offers', '/offers'], ['🔥', 'Trending', '/trending'], ['🎬', 'Videos', '/videos'], ['➕', 'Free Listing', '/register-business'], ['📢', 'Advertise', '/advertise'], ['👤', 'My Account', '/vendor/dashboard'], ['❤️', 'Saved', '/favorites'], ['⚖️', 'Legal', '/legal/disclaimer']].map(([i, n, h]) => (
              <Link key={n} href={h} onClick={() => setMore(false)} className="flex flex-col items-center gap-1 p-3 rounded-xl border hover:border-brand"><span className="text-2xl">{i}</span>{n}</Link>
            ))}
          </div>
        </div>
      )}
    </>
  );
}

export function Footer() {
  const p = usePathname(); if (p.startsWith('/admin')) return null;
  return (
    <footer className="bg-[#0b1b3f] text-gray-300 mt-10 pb-20 md:pb-0">
      <div className="max-w-7xl mx-auto px-4 py-10 grid md:grid-cols-4 gap-8 text-sm">
        <div>
          <div className="text-2xl font-black text-white">📍 PVRS <span className="text-accent">HUB</span></div>
          <p className="text-xs mt-2 text-gray-400">Udupi | Mangaluru | Our Local. Your Global.</p>
          <div className="flex gap-2 mt-4">{['f', 'ig', '▶', 'in'].map((s) => <a key={s} href="#" className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center hover:bg-brand">{s}</a>)}</div>
        </div>
        <div>
          <h4 className="text-white font-semibold mb-3">Company</h4>
          <ul className="space-y-1.5">
            <li><Link href="/legal/about" className="hover:text-white">About</Link></li>
            <li><Link href="/advertise" className="hover:text-white">Advertise</Link></li>
            <li><Link href="/blogs" className="hover:text-white">Blogs</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-semibold mb-3">Legal</h4>
          <ul className="space-y-1.5">
            <li><Link href="/legal/disclaimer" className="hover:text-white">Website Disclaimer</Link></li>
            <li><Link href="/legal/privacy" className="hover:text-white">Privacy Policy</Link></li>
            <li><Link href="/legal/terms" className="hover:text-white">Business Terms of Use</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-white font-semibold mb-3">Download Our App</h4>
          <div className="flex flex-col gap-2 w-44">
            <a href="#" className="border border-white/20 rounded-lg px-3 py-2 hover:bg-white/10">▶ Google Play</a>
            <a href="#" className="border border-white/20 rounded-lg px-3 py-2 hover:bg-white/10"> App Store</a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 text-center text-xs py-4 text-gray-400">© {new Date().getFullYear()} PVRS HUB. All Rights Reserved. | Made for Our Local Community ❤️ <span className="opacity-40 ml-2"><Link href="/contact" className="hover:underline">Help</Link> · <Link href="/legal/grievance" className="hover:underline">Grievance</Link></span></div>
    </footer>
  );
}
