'use client';
import { api } from './api';

function loadScript(): Promise<boolean> {
  return new Promise((res) => {
    if ((window as any).Razorpay) return res(true);
    const s = document.createElement('script'); s.src = 'https://checkout.razorpay.com/v1/checkout.js';
    s.onload = () => res(true); s.onerror = () => res(false); document.body.appendChild(s);
  });
}

// Opens Razorpay (UPI/GPay/PhonePe/Paytm, NetBanking, cards). Mock mode when backend has no keys.
export async function pay(body: { purpose: 'premium_plan' | 'banner_ad'; businessId?: string; adId?: string }, user: any): Promise<string> {
  const o = await api('/payments/order', { body });
  if (o.mock) {
    if (!confirm(`TEST MODE: Pay ₹${o.amount}? (Razorpay keys not configured)`)) throw new Error('Payment cancelled');
    return (await api('/payments/verify', { body: { paymentId: o.paymentId } })).message;
  }
  if (!(await loadScript())) throw new Error('Could not load Razorpay');
  return new Promise((resolve, reject) => {
    const rz = new (window as any).Razorpay({
      key: o.key, amount: o.amount * 100, currency: 'INR', name: 'PVRS HUB', order_id: o.orderId,
      description: body.purpose === 'premium_plan' ? 'Premium Listing Plan' : 'Homepage Banner Ad',
      prefill: { contact: '+91' + user?.phone, name: user?.name }, theme: { color: '#0055FF' },
      handler: async (r: any) => {
        try { resolve((await api('/payments/verify', { body: { paymentId: o.paymentId, ...r } })).message); } catch (e) { reject(e); }
      },
      modal: { ondismiss: () => reject(new Error('Payment cancelled')) },
    });
    rz.open();
  });
}
