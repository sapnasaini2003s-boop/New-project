'use client';
export type MenuCat = { name: string; items: { name: string; price: number | string; veg: boolean | null }[] };

// Vendor-side editor for "Order Online Menu" (categories → items with price & veg / non-veg)
export default function MenuEditor({ value, onChange }: { value: MenuCat[]; onChange: (m: MenuCat[]) => void }) {
  const set = (i: number, c: MenuCat) => onChange(value.map((x, k) => (k === i ? c : x)));
  return (
    <div className="space-y-3">
      {value.map((c, i) => (
        <div key={i} className="border rounded-xl p-3 bg-gray-50">
          <div className="flex gap-2"><input className="input !py-1.5 font-semibold" maxLength={40} placeholder="Category (e.g. Breads)" value={c.name} onChange={(e) => set(i, { ...c, name: e.target.value })} />
            <button type="button" onClick={() => onChange(value.filter((_, k) => k !== i))} className="text-red-500 text-xs px-2">Remove</button></div>
          <div className="mt-2 space-y-2">{c.items.map((it, j) => (
            <div key={j} className="flex gap-1.5 items-center">
              <input className="input !py-1.5 flex-1 min-w-0" maxLength={80} placeholder="Item name" value={it.name} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, name: e.target.value } : x)) })} />
              <input className="input !py-1.5 w-20" type="number" min={0} max={100000} placeholder="₹" value={it.price} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, price: e.target.value } : x)) })} />
              <select className="input !py-1.5 !w-24 text-xs" value={it.veg === null ? '' : String(it.veg)} onChange={(e) => set(i, { ...c, items: c.items.map((x, k) => (k === j ? { ...x, veg: e.target.value === '' ? null : e.target.value === 'true' } : x)) })}><option value="">—</option><option value="true">Veg</option><option value="false">Non-veg</option></select>
              <button type="button" onClick={() => set(i, { ...c, items: c.items.filter((_, k) => k !== j) })} className="text-gray-400 px-1">✕</button>
            </div>))}
            <button type="button" disabled={c.items.length >= 80} onClick={() => set(i, { ...c, items: [...c.items, { name: '', price: '', veg: null }] })} className="text-xs font-bold text-brand">+ Add item</button></div>
        </div>))}
      <button type="button" disabled={value.length >= 25} onClick={() => onChange([...value, { name: '', items: [{ name: '', price: '', veg: null }] }])} className="btn btn-ghost !text-xs">+ Add menu category</button>
    </div>
  );
}
