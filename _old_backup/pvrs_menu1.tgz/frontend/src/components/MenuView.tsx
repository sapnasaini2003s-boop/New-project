'use client';
import { useMemo, useState } from 'react';
import type { MenuCat } from './MenuEditor';

const Dot = ({ veg }: { veg: boolean | null }) => veg === null ? <span className="w-3.5 h-3.5 shrink-0" /> : <span className={`w-3.5 h-3.5 shrink-0 border rounded-[3px] flex items-center justify-center ${veg ? 'border-green-600' : 'border-red-600'}`}><span className={`w-1.5 h-1.5 rounded-full ${veg ? 'bg-green-600' : 'bg-red-600'}`} /></span>;

// Justdial-style "Order Online Menu": search, Veg / Non-Veg filter, collapsible categories with "View all", floating Menu jump button
export default function MenuView({ menu }: { menu: MenuCat[] }) {
  const [q, setQ] = useState(''); const [showSearch, setShowSearch] = useState(false); const [veg, setVeg] = useState(false); const [non, setNon] = useState(false);
  const [open, setOpen] = useState<Record<number, boolean>>({}); const [all, setAll] = useState<Record<number, boolean>>({}); const [jump, setJump] = useState(false);
  const cats = useMemo(() => menu.map((c) => ({ ...c, items: c.items.filter((i) => (!veg || i.veg === true) && (!non || i.veg === false) && (!q || i.name.toLowerCase().includes(q.toLowerCase()))) })).filter((c) => c.items.length), [menu, q, veg, non]);
  const chip = (on: boolean) => `px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-1.5 ${on ? 'border-brand bg-blue-50' : 'bg-white'}`;
  return (
    <section className="card p-4 md:p-5 relative">
      <h2 className="font-bold mb-3">Order Online Menu</h2>
      <div className="flex gap-2 items-center mb-3 flex-wrap">
        <button onClick={() => setShowSearch(!showSearch)} className={chip(showSearch)} aria-label="Search menu">🔍</button>
        <button onClick={() => setVeg(!veg)} className={chip(veg)}><Dot veg={true} /> Veg</button>
        <button onClick={() => setNon(!non)} className={chip(non)}><Dot veg={false} /> Non Veg</button>
        {showSearch && <input autoFocus className="input !py-1.5 flex-1 min-w-[10rem]" placeholder="Search dishes" value={q} onChange={(e) => setQ(e.target.value)} />}
      </div>
      {!cats.length && <p className="text-sm text-gray-500 py-6 text-center">No dishes match.</p>}
      {cats.map((c, i) => {
        const isOpen = open[i] !== false; const lim = all[i] || q ? c.items.length : 4;
        return (<div key={c.name} id={`menu-${i}`} className="border-t first:border-0">
          <button onClick={() => setOpen({ ...open, [i]: !isOpen })} className="w-full flex justify-between items-center py-3 font-bold text-sm text-left"><span>{c.name} <span className="text-gray-500">({c.items.length})</span></span><span className={`transition ${isOpen ? 'rotate-180' : ''}`}>⌃</span></button>
          {isOpen && <div className="pb-2">{c.items.slice(0, lim).map((it, k) => <div key={k} className="py-2.5 border-b last:border-0 flex gap-2 items-start"><Dot veg={it.veg} /><div><p className="text-sm">{it.name}</p><p className="text-sm font-semibold mt-0.5">₹{it.price}</p></div></div>)}
            {c.items.length > lim && <button onClick={() => setAll({ ...all, [i]: true })} className="w-full border rounded-lg py-1.5 text-xs font-medium mt-2">View all</button>}</div>}
        </div>);
      })}
      {!!cats.length && <div className="sticky bottom-20 md:bottom-4 flex justify-center mt-2 pointer-events-none"><div className="relative pointer-events-auto">
        {jump && <div className="absolute bottom-12 left-1/2 -translate-x-1/2 bg-white border shadow-xl rounded-xl p-2 w-56 max-h-64 overflow-y-auto text-sm">{cats.map((c, i) => <a key={c.name} href={`#menu-${i}`} onClick={() => { setOpen({ ...open, [i]: true }); setJump(false); }} className="flex justify-between px-3 py-2 rounded-lg hover:bg-gray-50"><span>{c.name}</span><span className="text-gray-400">{c.items.length}</span></a>)}</div>}
        <button onClick={() => setJump(!jump)} className="bg-gray-900 text-white rounded-full px-5 py-2.5 text-sm font-semibold shadow-lg">☰ Menu</button></div></div>}
    </section>
  );
}
