'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useFetch } from '@/lib/api';
import PageHero from '@/components/PageHero';
const PAGES = [['about', 'About us', 'ℹ️'], ['disclaimer', 'Disclaimer', '⚠️'], ['privacy', 'Privacy Policy', '🔒'], ['terms', 'Business Terms', '📜'], ['grievance', 'Grievance Officer', '⚖️']];
export default function LegalPage() {
  const { slug } = useParams<{ slug: string }>(); const { data, error } = useFetch<any>(`/pages/${slug}`);
  const cur = PAGES.find((p) => p[0] === slug);
  return (<div>
    <PageHero title={data?.title || cur?.[1] || 'Legal'} icon={cur?.[2]} tone="dark" crumb="Legal" subtitle={data?.updatedAt ? `Last updated ${new Date(data.updatedAt).toLocaleDateString('en-IN')}` : undefined} />
    <div className="max-w-6xl mx-auto px-4 py-8 grid md:grid-cols-[240px_1fr] gap-6 items-start">
      <nav className="card p-2 md:sticky md:top-32 flex md:flex-col gap-1 overflow-x-auto no-scrollbar">{PAGES.map(([k, l, i]) => (
        <Link key={k} href={`/legal/${k}`} className={`shrink-0 flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium ${k === slug ? 'bg-brand text-white' : 'text-gray-600 hover:bg-gray-50'}`}><span>{i}</span>{l}</Link>))}</nav>
      {error ? <div className="card p-10 text-center text-gray-500">Page not found</div> : !data ? <div className="card p-8 animate-pulse h-64" /> :
        <article className="card p-6 md:p-10"><div className="whitespace-pre-line text-[15px] leading-8 text-gray-800">{data.body}</div>
          <div className="mt-8 pt-6 border-t text-sm text-gray-500">Questions? Write to <a className="text-brand font-semibold" href="mailto:legal@yourdomain.in">legal@yourdomain.in</a></div></article>}
    </div>
  </div>);
}
