'use client';
import { Suspense, useRef, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { api, setSession } from '@/lib/api';

// Firebase Phone Auth is used when NEXT_PUBLIC_FIREBASE_API_KEY is set; otherwise backend test OTP (123456).
const FB = process.env.NEXT_PUBLIC_FIREBASE_API_KEY;

function LoginInner() {
  const sp = useSearchParams(); const router = useRouter();
  const [intent, setIntent] = useState(sp.get('intent') === 'vendor' ? 'vendor' : 'user');
  const [phone, setPhone] = useState(''); const [otp, setOtp] = useState(''); const [name, setName] = useState('');
  const [step, setStep] = useState(1); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const confirmRef = useRef<any>(null);

  const send = async () => {
    if (!/^[6-9]\d{9}$/.test(phone)) return setMsg('Enter a valid 10-digit mobile number');
    setBusy(true); setMsg('');
    try {
      if (FB) {
        const { initializeApp, getApps } = await import('firebase/app');
        const { getAuth, RecaptchaVerifier, signInWithPhoneNumber } = await import('firebase/auth');
        const app = getApps()[0] || initializeApp({ apiKey: FB, authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN, projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID, appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID });
        const auth = getAuth(app);
        const w = window as any;
        w.recaptcha = w.recaptcha || new RecaptchaVerifier(auth, 'recaptcha', { size: 'invisible' });
        confirmRef.current = await signInWithPhoneNumber(auth, '+91' + phone, w.recaptcha);
        setMsg(`OTP sent to +91 ${phone}`);
      } else {
        const r = await api('/auth/request-otp', { body: { phone } }); setMsg(r.message);
      }
      setStep(2);
    } catch (e: any) { setMsg(e.message); }
    setBusy(false);
  };

  const verify = async () => {
    setBusy(true); setMsg('');
    try {
      let firebaseToken;
      if (FB) { const cred = await confirmRef.current.confirm(otp); firebaseToken = await cred.user.getIdToken(); }
      const r = await api('/auth/verify-otp', { body: { phone, otp, name, intent, firebaseToken } });
      setSession(r.token, r.user);
      const next = sp.get('next');
      router.push(next || (r.user.role === 'admin' ? '/admin' : r.user.role === 'vendor' ? '/vendor/dashboard' : '/'));
    } catch (e: any) { setMsg(e.message); }
    setBusy(false);
  };

  return (
    <div className="max-w-md mx-auto px-4 py-10">
      <div className="card p-6">
        <h1 className="text-2xl font-black text-center">Login / Register</h1>
        <p className="text-center text-sm text-gray-500 mb-5">Secure login with your mobile number – no password needed</p>
        <div className="grid grid-cols-2 bg-gray-100 rounded-lg p-1 mb-5 text-sm font-semibold">
          <button onClick={() => setIntent('user')} className={`py-2 rounded-md ${intent === 'user' ? 'bg-white shadow text-brand' : ''}`}>Customer</button>
          <button onClick={() => setIntent('vendor')} className={`py-2 rounded-md ${intent === 'vendor' ? 'bg-white shadow text-accent' : ''}`}>Business Owner</button>
        </div>
        {step === 1 ? (<>
          <label className="label">Your name (new users)</label>
          <input className="input mb-3" value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" />
          <label className="label">Mobile number</label>
          <div className="flex gap-2"><span className="input !w-16 text-center">+91</span><input className="input" inputMode="numeric" maxLength={10} value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))} placeholder="10-digit mobile" /></div>
          <button disabled={busy} onClick={send} className="btn btn-brand w-full mt-4">{busy ? 'Sending…' : 'Get OTP'}</button>
        </>) : (<>
          <label className="label">Enter 6-digit OTP sent to +91 {phone}</label>
          <input className="input text-center tracking-[.5em] text-lg" inputMode="numeric" maxLength={6} value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))} />
          <button disabled={busy || otp.length !== 6} onClick={verify} className="btn btn-brand w-full mt-4">{busy ? 'Verifying…' : 'Verify & Continue'}</button>
          <button onClick={() => setStep(1)} className="text-xs text-brand w-full mt-3">Change number</button>
        </>)}
        {msg && <p className="text-sm text-center mt-3 text-gray-700">{msg}</p>}
        {intent === 'vendor' && <p className="text-xs text-gray-500 mt-4 text-center">Business accounts & listings go live only after admin verification.</p>}
        <div id="recaptcha" />
      </div>
    </div>
  );
}
export default function Login() { return <Suspense><LoginInner /></Suspense>; }
