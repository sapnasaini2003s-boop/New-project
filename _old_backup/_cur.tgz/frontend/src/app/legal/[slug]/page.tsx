'use client';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useFetch } from '@/lib/api';
const PAGES = [['disclaimer', 'Disclaimer'], ['privacy', 'Privacy Policy'], ['terms', 'Business Terms'], ['grievance', 'Grievance Officer'], ['about', 'About']];
export default function LegalPage() {
  const { slug } = useParams<{ slug: string }>(); const { data, error } = useFetch<any>(`/pages/${slug}`);
  return (<div className="max-w-4xl mx-auto px-4 py-6">
    <div className="flex gap-2 overflow-x-auto no-scrollbar mb-4">{PAGES.map(([k, l]) => <Link key={k} href={`/legal/${k}`} className={`shrink-0 btn !text-xs ${k === slug ? 'btn-brand' : 'btn-ghost'}`}>{l}</Link>)}</div>
    {error ? <p>Page not found</p> : <div className="card p-6"><h1 className="text-2xl font-black mb-4">{data?.title}</h1><div className="whitespace-pre-line text-sm leading-relaxed text-gray-800">{data?.body}</div></div>}
  </div>);
}
