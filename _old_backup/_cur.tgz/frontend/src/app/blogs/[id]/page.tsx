'use client';
import { useParams } from 'next/navigation';
import { img, useFetch } from '@/lib/api';
export default function Blog() {
  const { id } = useParams<{ id: string }>(); const { data: b } = useFetch<any>(`/blogs/${id}`);
  if (!b) return <p className="p-8 text-center text-gray-500">Loading…</p>;
  return (<article className="max-w-3xl mx-auto px-4 py-6">{b.image && <img src={img(b.image)} alt="" className="w-full rounded-xl mb-4" />}<h1 className="text-3xl font-black">{b.title}</h1><p className="text-xs text-gray-400 mb-4">{new Date(b.createdAt).toLocaleDateString()}</p><div className="whitespace-pre-line text-gray-800">{b.body}</div></article>);
}
