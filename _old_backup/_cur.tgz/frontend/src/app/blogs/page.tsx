'use client';
import Link from 'next/link';
import { img, useFetch } from '@/lib/api';
export default function Blogs() {
  const { data } = useFetch<any[]>('/blogs');
  return (<div className="max-w-5xl mx-auto px-3 md:px-4 py-6"><h1 className="text-2xl font-black mb-4">📰 News & Local Guides</h1>
    <div className="grid md:grid-cols-2 gap-4">{data?.map((b) => (
      <Link key={b._id} href={`/blogs/${b._id}`} className="card overflow-hidden hover:shadow-lg">{b.image && <img src={img(b.image)} alt="" className="w-full h-40 object-cover" />}<div className="p-4"><h3 className="font-bold">{b.title}</h3><p className="text-sm text-gray-600 mt-1">{b.excerpt}</p><p className="text-xs text-gray-400 mt-2">{new Date(b.createdAt).toLocaleDateString()}</p></div></Link>
    ))}</div></div>);
}
