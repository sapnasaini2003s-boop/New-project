'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { api, setSession } from '@/lib/api';

export default function AdminLogin() {
  const router = useRouter();
  const [phone, setPhone] = useState('9999999999');
  const [otp, setOtp] = useState('123456');
  const [step, setStep] = useState(1);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);

  const sendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setMsg('');
    try {
      const r = await api('/auth/request-otp', { body: { phone } });
      setMsg(r.message || 'OTP Sent (Check console or use 123456)');
      setStep(2);
    } catch (err: any) {
      setMsg(err.message || 'Error sending OTP');
    }
    setBusy(false);
  };

  const verifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setMsg('');
    try {
      const r = await api('/auth/verify-otp', { body: { phone, otp, intent: 'admin' } });
      if (r.user?.role !== 'admin') {
        throw new Error('Unauthorized: This number is not registered as an Admin.');
      }
      setSession(r.token, r.user);
      router.replace('/admin');
    } catch (err: any) {
      setMsg(err.message || 'Error verifying OTP');
    }
    setBusy(false);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 font-sans text-slate-200">
      <div className="max-w-md w-full bg-slate-800 rounded-2xl shadow-2xl overflow-hidden border border-slate-700">
        <div className="bg-slate-950 p-8 text-center border-b border-slate-700">
          <h1 className="text-3xl font-black tracking-wider text-brand">PVRS <span className="text-white">ADMIN</span></h1>
          <p className="text-slate-400 text-sm mt-2 uppercase tracking-widest font-semibold">Master Command Center</p>
        </div>
        
        <div className="p-8">
          {msg && <div className={`p-3 rounded-lg mb-6 text-sm font-medium ${msg.includes('Error') || msg.includes('Unauthorized') ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'bg-green-500/10 text-green-400 border border-green-500/20'}`}>{msg}</div>}
          
          {step === 1 ? (
            <form onSubmit={sendOtp} className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Admin Mobile Number</label>
                <div className="flex bg-slate-900 border border-slate-700 rounded-lg overflow-hidden focus-within:border-brand transition">
                  <span className="px-4 py-3 bg-slate-950 text-slate-400 border-r border-slate-700 font-medium">+91</span>
                  <input type="text" value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))} className="w-full bg-transparent px-4 py-3 outline-none text-white font-medium" placeholder="9999999999" required />
                </div>
              </div>
              <button type="submit" disabled={busy || phone.length !== 10} className="w-full bg-brand hover:bg-brand-dark text-white font-bold py-3.5 rounded-lg transition disabled:opacity-50">
                {busy ? 'Sending...' : 'Request OTP'}
              </button>
            </form>
          ) : (
            <form onSubmit={verifyOtp} className="space-y-5">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Enter Security OTP</label>
                <input type="text" value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))} className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 outline-none focus:border-brand transition text-center tracking-[0.5em] text-white text-xl font-medium" placeholder="••••••" required />
              </div>
              <button type="submit" disabled={busy || otp.length < 4} className="w-full bg-brand hover:bg-brand-dark text-white font-bold py-3.5 rounded-lg transition disabled:opacity-50">
                {busy ? 'Verifying...' : 'Secure Login'}
              </button>
              <button type="button" onClick={() => setStep(1)} className="w-full text-slate-400 text-sm font-medium hover:text-white transition mt-2">← Back to Phone</button>
            </form>
          )}
        </div>
        
        <div className="bg-slate-900/50 p-4 text-center text-xs text-slate-500 font-medium border-t border-slate-800">
          Restricted Area. Authorized Personnel Only.
        </div>
      </div>
    </div>
  );
}
