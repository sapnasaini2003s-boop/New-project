'use client';
import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { api, img, useFetch, useUser, ytId } from '@/lib/api';
import { track } from '@/components/BizCard';

function Embed({ url }: { url: string }) {
  const id = ytId(url);
  if (id) return <iframe className="w-full aspect-video rounded-lg" src={`https://www.youtube.com/embed/${id}`} allowFullScreen />;
  if (url.includes('facebook.com')) return <iframe className="w-full aspect-video rounded-lg" src={`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(url)}`} allowFullScreen />;
  if (url.includes('instagram.com')) { const clean = url.split('?')[0].replace(/\/$/, ''); return <iframe className="w-full h-[480px] rounded-lg" src={`${clean}/embed`} />; }
  return null;
}

export default function BusinessPage() {
  const { id } = useParams<{ id: string }>();
  const { data: b, error, loading } = useFetch<any>(`/businesses/${id}`);
  const { data: cats } = useFetch<any[]>('/categories');
  const { user } = useUser();
  const [sheet, setSheet] = useState(false);
  const [claimMsg, setClaimMsg] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const tracked = useRef(false);
  useEffect(() => { if (b && !tracked.current) { tracked.current = true; track(b._id, 'view'); } }, [b]);

  if (loading) return <p className="p-8 text-center text-gray-500">Loading…</p>;
  if (error || !b) return <div className="p-10 text-center"><h1 className="text-xl font-bold">Listing not found</h1><Link href="/" className="text-brand">Go home</Link></div>;
  const cat = cats?.find((c) => c.slug === b.category);
  const isFood = b.category === 'food-and-dining';
  const isMedical = b.category === 'medical-and-healthcare';

  const claim = async () => {
    const f = fileRef.current?.files?.[0]; if (!f) return setClaimMsg('Please attach a proof document');
    const fd = new FormData(); fd.append('businessId', b._id); fd.append('document', f); fd.append('name', user?.name || '');
    try { const r = await api('/vendor/claims', { form: fd }); setClaimMsg(r.message); } catch (e: any) { setClaimMsg(e.message); }
  };

  return (
    <div className="max-w-6xl mx-auto px-3 md:px-4 py-4">
      <p className="text-xs text-gray-500 mb-2"><Link href="/">Home</Link> › <Link href={`/category/${b.category}`}>{cat?.name}</Link> › {b.subCategory}</p>
      {b.bannerImage && <img src={img(b.bannerImage)} alt="" className="w-full h-40 md:h-64 object-cover rounded-xl mb-4" />}

      <div className="card p-4 md:p-6 flex flex-col md:flex-row gap-5">
        <div className="w-full md:w-48 h-48 rounded-xl overflow-hidden bg-gradient-to-br from-blue-50 to-orange-50 flex items-center justify-center text-6xl shrink-0">
          {b.profileImage ? <img src={img(b.profileImage)} alt={b.name} className="w-full h-full object-cover" /> : '🏪'}
        </div>
        <div className="flex-1">
          <div className="flex flex-wrap gap-2 items-center">
            <h1 className="text-2xl md:text-3xl font-black">{b.name}</h1>
            {b.verified && <span className="bg-green-600 text-white text-xs font-bold px-2 py-0.5 rounded">✔ Verified</span>}
            {b.plan === 'premium' && <span className="bg-accent text-white text-xs font-bold px-2 py-0.5 rounded">PREMIUM</span>}
          </div>
          {b.rating > 0 && <p className="mt-1 text-sm"><span className="bg-green-600 text-white px-2 rounded font-bold">{Number(b.rating).toFixed(1)}★</span> {b.reviews} ratings</p>}
          <p className="text-sm text-gray-600 mt-2">📍 {b.address ? `${b.address}, ` : ''}{b.city}</p>
          {b.timings && <p className="text-sm text-gray-600">🕒 {b.timings}</p>}
          <p className="text-sm text-gray-500">{cat?.icon} {b.subCategory}</p>

          <div className="flex flex-wrap gap-2 mt-4">
            {b.contact ? (<>
              <a href={`tel:${b.contact.phone}`} onClick={() => track(b._id, 'call')} className="btn btn-brand">📞 Call Now</a>
              <a href={`https://wa.me/91${b.contact.whatsapp || b.contact.phone}`} target="_blank" onClick={() => track(b._id, 'whatsapp')} className="btn bg-green-500 text-white hover:bg-green-600">💬 WhatsApp</a>
            </>) : (
              <span className="btn bg-gray-100 text-gray-500 cursor-not-allowed" title="Contact available on Premium listings">🔒 Contact details hidden</span>
            )}
            {isFood && b.orderOnline && <button onClick={() => { setSheet(true); track(b._id, 'order'); }} className="btn btn-accent">🛵 Order Online</button>}
          </div>
          {b.unclaimed && <a href="#claim" className="flash inline-block mt-3 text-sm font-bold text-accent">⚠ Is this your business? Claim it now!</a>}
        </div>
      </div>

      {b.description && <div className="card p-4 md:p-6 mt-4"><h2 className="font-bold mb-2">About</h2><p className="text-sm text-gray-700 whitespace-pre-line">{b.description}</p></div>}

      {b.gallery?.length > 0 && (
        <div className="card p-4 md:p-6 mt-4"><h2 className="font-bold mb-3">Photos</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">{b.gallery.map((g: string) => <img key={g} src={img(g)} alt="" className="w-full h-32 object-cover rounded-lg" />)}</div>
        </div>
      )}
      {b.videos && Object.values(b.videos).some(Boolean) && (
        <div className="card p-4 md:p-6 mt-4"><h2 className="font-bold mb-3">Videos</h2>
          <div className="grid md:grid-cols-2 gap-3">{Object.values(b.videos).filter(Boolean).map((u: any) => <Embed key={u} url={u} />)}</div>
        </div>
      )}

      {isMedical && (
        <div className="mt-4 p-4 rounded-xl bg-yellow-50 border border-yellow-300 text-xs text-yellow-900">
          <b>Three-Possibility Rule:</b> this medical information may be accurate, outdated, or incorrect. Always verify registration numbers, qualifications and medicine labels directly with the provider. <Link href="/legal/disclaimer" className="underline">Read disclaimer</Link>
        </div>
      )}

      {b.unclaimed && (
        <div id="claim" className="card p-4 md:p-6 mt-4 border-accent">
          <h2 className="font-bold text-accent">Claim this business</h2>
          <p className="text-sm text-gray-600 mt-1">Owners can verify with a Trade License / FSSAI / KMC certificate. After admin approval you can manage this page and upgrade to Premium to reveal Call & WhatsApp buttons.</p>
          {user ? (
            <div className="flex flex-col md:flex-row gap-2 mt-3">
              <input ref={fileRef} type="file" accept=".jpg,.jpeg,.png,.pdf" className="input" />
              <button onClick={claim} className="btn btn-accent">Submit Claim</button>
            </div>
          ) : <Link href={`/login?intent=vendor&next=/business/${b._id}%23claim`} className="btn btn-accent mt-3">Login with mobile OTP to claim</Link>}
          {claimMsg && <p className="text-sm mt-2 font-medium">{claimMsg}</p>}
        </div>
      )}

      {/* Order Online bottom sheet */}
      {sheet && (
        <div className="fixed inset-0 z-50 bg-black/50" onClick={() => setSheet(false)}>
          <div className="absolute bottom-0 inset-x-0 md:max-w-md md:mx-auto bg-white rounded-t-2xl p-5 slideup" onClick={(e) => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
            <h3 className="font-bold text-lg">Order from {b.name}</h3>
            <p className="text-xs text-gray-500 mb-4">You will be redirected to the partner app</p>
            <div className="space-y-3">
              {b.orderOnline.swiggy && <a href={b.orderOnline.swiggy} target="_blank" className="flex items-center justify-between rounded-xl px-4 py-3 text-white font-bold" style={{ background: '#FC8019' }}><span className="text-lg">Swiggy</span><span>Order →</span></a>}
              {b.orderOnline.zomato && <a href={b.orderOnline.zomato} target="_blank" className="flex items-center justify-between rounded-xl px-4 py-3 text-white font-bold" style={{ background: '#E23744' }}><span className="text-lg italic">zomato</span><span>Order →</span></a>}
            </div>
            <button onClick={() => setSheet(false)} className="btn btn-ghost w-full mt-4">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
