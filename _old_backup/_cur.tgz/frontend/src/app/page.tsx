'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useFetch, img, ytThumb, getCity } from '@/lib/api';
import BizCard from '@/components/BizCard';
import VideoModal from '@/components/VideoModal';

function Banner({ ads, h = 'h-24 md:h-28' }: { ads: any[]; h?: string }) {
  const [i, setI] = useState(0);
  useEffect(() => { if (ads.length < 2) return; const t = setInterval(() => setI((x) => (x + 1) % ads.length), 4000); return () => clearInterval(t); }, [ads.length]);
  if (!ads.length) return (
    <Link href="/advertise" className={`${h} rounded-xl border-2 border-dashed border-accent/50 bg-orange-50 flex items-center justify-center text-accent font-bold`}>Ad Space 970×90 — Book this slot</Link>
  );
  const a = ads[i % ads.length];
  return (
    <div className="relative">
      <Link href={a.link || '#'} className={`${h} rounded-xl overflow-hidden flex items-center justify-between px-5 md:px-10 text-white shadow`}
        style={{ background: a.image ? `url(${img(a.image)}) center/cover` : a.bg || 'linear-gradient(90deg,#0033aa,#0055FF)' }}>
        <div className={a.image ? 'bg-black/40 p-2 rounded' : ''}>
          <h3 className="font-black text-lg md:text-2xl tracking-wide" style={{ color: a.bg?.includes('#eff6ff') ? '#0b1b3f' : undefined }}>{a.title}</h3>
          <p className="text-xs md:text-sm opacity-90" style={{ color: a.bg?.includes('#eff6ff') ? '#0055FF' : undefined }}>{a.subtitle}</p>
        </div>
        {a.cta && <span className="btn btn-accent !text-xs md:!text-sm shrink-0">{a.cta}</span>}
      </Link>
      {ads.length > 1 && <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 flex gap-1">{ads.map((_, k) => <span key={k} className={`w-1.5 h-1.5 rounded-full ${k === i % ads.length ? 'bg-white' : 'bg-white/50'}`} />)}</div>}
    </div>
  );
}

export default function Home() {
  const router = useRouter();
  const [city, setCity] = useState('Udupi');
  useEffect(() => { setCity(getCity()); const f = () => setCity(getCity()); window.addEventListener('pvrs-city', f); return () => window.removeEventListener('pvrs-city', f); }, []);
  const { data: home } = useFetch<any>('/home');
  const { data: cats } = useFetch<any[]>('/categories');
  const { data: featured } = useFetch<any[]>('/featured');
  const [tab, setTab] = useState('Businesses');
  const [q, setQ] = useState('');
  const [video, setVideo] = useState<string | null>(null);
  const s = home?.settings || {}; const ads = home?.ads || {};
  const heroVid = ads.heroVideo?.[0];
  const pills = (cats || []).flatMap((c: any) => c.subs.slice(0, 3).map((sub: string) => ({ sub, c })));

  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4">
      {/* Mobile sticky category ribbon */}
      <div className="md:hidden sticky top-[104px] z-30 bg-[#f5f7fb] -mx-3 px-3 py-2 flex gap-3 overflow-x-auto no-scrollbar">
        {(cats || []).map((c: any) => (
          <a key={c._id} href={`#cat-${c.slug}`} className="flex flex-col items-center min-w-[64px] text-[10px] font-medium text-gray-700">
            <span className="w-11 h-11 rounded-xl bg-white border flex items-center justify-center text-xl">{c.icon}</span>
            <span className="text-center leading-tight mt-1">{c.name.split(' ')[0]}</span>
          </a>
        ))}
      </div>

      {/* 2. Top banner carousel */}
      <section className="mt-3"><Banner ads={ads.top || []} /></section>

      {/* 3. Hero search + 4. hero video ad */}
      <section 
        className="mt-4 rounded-xl overflow-hidden relative text-white"
        style={{
          background: `url('https://images.unsplash.com/photo-1601058268499-e52658b8ebf8?q=80&w=2000&auto=format&fit=crop') center/cover no-repeat`
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-[#00267a] via-[#0033aada] to-transparent"></div>
        <div className="relative z-10 p-6 md:p-12 grid md:grid-cols-5 gap-8 items-center">
          <div className="md:col-span-3">
            <h1 className="text-3xl md:text-5xl font-black leading-tight tracking-tight drop-shadow-lg">{s.hero?.title || 'Find Local Businesses Near You'}</h1>
            <p className="text-blue-50 mt-3 text-sm md:text-base font-medium drop-shadow">{s.hero?.subtitle || 'Search. Connect. Grow. Udupi | Mangaluru | Beyond.'}</p>
            <div className="hidden md:block mt-8">
              <div className="flex gap-1 border-b border-white/20">
                {['Businesses', 'Products', 'Services'].map((t) => (
                  <button key={t} onClick={() => setTab(t)} className={`px-5 py-2.5 rounded-t-lg text-sm font-bold tracking-wide flex items-center gap-2 ${tab === t ? 'bg-white text-brand' : 'bg-black/30 hover:bg-black/50 text-white'}`}>
                    {t === 'Businesses' ? '🏪' : t === 'Products' ? '🛍️' : '🔧'} {t}
                  </button>
                ))}
              </div>
              <form onSubmit={(e) => { e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}&city=${city}&type=${tab}`); }} className="bg-white p-2 rounded-b-lg rounded-tr-lg flex gap-2 shadow-2xl">
                <div className="flex items-center text-gray-500 px-3"><span className="text-lg">🔍</span></div>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="What are you looking for?" className="flex-1 text-gray-800 px-2 outline-none font-medium" />
                <div className="w-px bg-gray-200 my-2 mx-2"></div>
                <div className="flex items-center text-gray-500 px-2"><span className="text-brand">📍</span> {city}</div>
                <button className="bg-brand hover:bg-brand-dark text-white px-8 py-3 rounded-md font-bold transition">Search</button>
              </form>
            </div>
            <div className="mt-5 flex flex-wrap gap-2 text-xs items-center">
              <span className="text-white/80 font-medium tracking-wide">Popular Searches:</span>
              {['Restaurant', 'Hospitals', 'Hotels', 'Salons', 'Builders', 'Car Service'].map((p: string) => <Link key={p} href={`/search?q=${encodeURIComponent(p)}`} className="border border-white/40 rounded-full px-3 py-1.5 hover:bg-white hover:text-brand bg-black/20 backdrop-blur-sm transition">{p}</Link>)}
            </div>
          </div>
          <div className="md:col-span-2 flex justify-end">
            {heroVid && (
              <button onClick={() => setVideo(heroVid.youtubeUrl)} className="relative w-full max-w-[320px] rounded-xl overflow-hidden aspect-[4/3] border-4 border-white/20 shadow-2xl group">
                {ytThumb(heroVid.youtubeUrl) ? <img src={ytThumb(heroVid.youtubeUrl)} alt="" className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition duration-500" /> : <div className="absolute inset-0 bg-blue-900"></div>}
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition"></div>
                <span className="absolute inset-0 flex items-center justify-center"><span className="w-14 h-14 rounded-full bg-black/70 flex items-center justify-center text-white text-2xl pl-1 ring-4 ring-white/30 group-hover:bg-brand transition">▶</span></span>
                <span className="absolute bottom-0 inset-x-0 p-4 pb-3 text-left bg-gradient-to-t from-black via-black/80 to-transparent">
                  <h4 className="font-bold text-white text-sm line-clamp-1">{heroVid.title || 'Discover Udupi & Mangaluru'}</h4>
                  <div className="flex justify-between items-end mt-1">
                     <span className="text-xs text-gray-300">A City of Opportunities</span>
                     <span className="text-[10px] font-bold uppercase tracking-wider text-white">Watch Video ⊕</span>
                  </div>
                </span>
              </button>
            )}
          </div>
        </div>
      </section>

      {/* 5. Top categories */}
      <section className="card mt-6 p-4 md:p-6 shadow-sm">
        <div className="flex justify-between items-center mb-6 border-b pb-3">
           <h2 className="font-bold text-xl text-[#0b1b3f]">Browse Top Categories</h2>
           <Link href="/categories" className="text-brand text-sm font-bold flex items-center gap-1 hover:underline">View All Categories <span className="text-lg">→</span></Link>
        </div>
        <div className="hidden md:grid grid-cols-10 gap-3">
          {(cats || []).slice(0, 9).map((c: any) => (
            <Link key={c._id} href={`/category/${c.slug}`} className="flex flex-col items-center text-center group">
              <span className="w-[72px] h-[72px] rounded-full flex items-center justify-center text-3xl shadow-sm border border-gray-100 bg-white group-hover:-translate-y-1.5 group-hover:shadow-md transition duration-300" style={{ color: c.color }}>
                {c.icon}
              </span>
              <span className="text-[11px] font-bold mt-3 leading-tight group-hover:text-brand text-gray-700 max-w-[80px]">{c.name}</span>
            </Link>
          ))}
          <Link href="/categories" className="flex flex-col items-center text-center group">
            <span className="w-[72px] h-[72px] rounded-full flex items-center justify-center text-2xl shadow-sm border border-gray-100 bg-gray-50 text-gray-400 group-hover:-translate-y-1.5 group-hover:shadow-md group-hover:bg-gray-100 transition duration-300">
               •••
            </span>
            <span className="text-[11px] font-bold mt-3 leading-tight group-hover:text-brand text-gray-700">More<br/>Categories</span>
          </Link>
        </div>
        {/* 2-col (mobile) → 8-col (desktop) capsule grid */}
        <div className="grid grid-cols-2 md:grid-cols-8 gap-3 mt-8 pt-6 border-t border-gray-100">
          {pills.map(({ sub, c }: any) => (
            <Link key={c.slug + sub} href={`/category/${c.slug}?sub=${encodeURIComponent(sub)}`} className="flex items-center gap-2 border border-gray-200 rounded-full px-4 py-2.5 text-xs font-semibold hover:border-brand hover:text-brand bg-white hover:shadow-sm transition">
              <span style={{ color: c.color }}>{c.icon}</span><span className="truncate">{sub}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* 6. Promo ad + 7. Featured videos */}
      <section className="grid md:grid-cols-3 gap-4 mt-5">
        {ads.promo?.[0] ? (
          <Link href={ads.promo[0].link || '#'} className="card overflow-hidden relative min-h-[200px] bg-orange-50 p-5 flex flex-col justify-end" style={ads.promo[0].image ? { background: `linear-gradient(90deg,#fff7ed 45%,transparent), url(${img(ads.promo[0].image)}) right/cover` } : {}}>
            <h3 className="text-xl font-black text-gray-900 max-w-[60%]">{ads.promo[0].title}</h3>
            <p className="text-xs text-gray-600 max-w-[60%]">{ads.promo[0].subtitle}</p>
            <span className="btn btn-accent w-fit mt-3 !text-xs">{ads.promo[0].cta || 'EXPLORE'}</span>
          </Link>
        ) : <Banner ads={[]} h="h-full min-h-[200px]" />}
        <div className="card p-4 md:col-span-2">
          <div className="flex justify-between mb-3"><h2 className="font-bold">Featured Videos</h2><Link href="/videos" className="text-brand text-sm font-semibold">View All →</Link></div>
          <div className="flex gap-3 overflow-x-auto no-scrollbar">
            {(home?.videos || []).map((v: any) => (
              <button key={v._id} onClick={() => setVideo(v.url)} className="min-w-[150px] text-left">
                <div className="relative aspect-video rounded-lg overflow-hidden bg-gray-200">
                  {ytThumb(v.url) && <img src={ytThumb(v.url)} alt="" className="w-full h-full object-cover" />}
                  <span className="absolute inset-0 flex items-center justify-center text-white text-2xl">▶</span>
                </div>
                <p className="text-xs font-semibold mt-1 line-clamp-2">{v.title}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Stats + 9. location banner */}
      <section className="grid md:grid-cols-3 gap-4 mt-5">
        <div className="card p-4 md:col-span-2 grid grid-cols-4 text-center">
          {[['🏪', home?.stats?.businesses, 'Local Businesses'], ['👥', home?.stats?.customers, 'Happy Customers'], ['✅', home?.stats?.verified, 'Businesses'], ['❤️', home?.stats?.support, 'Local']].map(([i, v, l]) => (
            <div key={l}><div className="text-2xl">{i}</div><div className="font-black text-sm md:text-xl">{v}</div><div className="text-[10px] md:text-xs text-gray-500">{l}</div></div>
          ))}
        </div>
        <div className="rounded-xl p-5 text-white min-h-[110px] flex flex-col justify-center" style={{ background: `linear-gradient(90deg,#0033aacc,#0055ff55), url(${s.locationBanner?.image}) center/cover` }}>
          <h3 className="font-black text-xl">{s.locationBanner?.title}</h3><p className="text-sm">{s.locationBanner?.subtitle}</p>
        </div>
      </section>

      {/* 10. Featured (premium only, behaviour-ranked) */}
      <section className="mt-6">
        <div className="flex justify-between items-end mb-3">
          <div><h2 className="font-bold text-lg">Featured Businesses</h2><p className="text-xs text-gray-500">Premium verified businesses trending right now</p></div>
          <Link href="/search?featured=1" className="text-brand text-sm font-semibold">View All →</Link>
        </div>
        <div className="flex md:grid md:grid-cols-5 gap-3 overflow-x-auto no-scrollbar">
          {(featured || []).map((b: any) => <div key={b._id} className="min-w-[220px] md:min-w-0"><BizCard b={b} /></div>)}
          {featured && !featured.length && <p className="text-sm text-gray-500">No featured businesses yet.</p>}
        </div>
      </section>

      {/* 11. Middle banner */}
      <section className="mt-6"><Banner ads={ads.middle || []} /></section>

      {/* Sub-category buckets */}
      <section className="grid md:grid-cols-2 gap-4 mt-6">
        {(cats || []).map((c: any) => (
          <div key={c._id} id={`cat-${c.slug}`} className="card p-4 scroll-mt-40">
            <div className="flex justify-between mb-3"><h3 className="font-bold">{c.icon} {c.name}</h3><Link href={`/category/${c.slug}`} className="text-xs text-brand font-semibold">See all</Link></div>
            <div className="grid grid-cols-3 gap-2">
              {c.subs.slice(0, 6).map((sub: string) => (
                <Link key={sub} href={`/category/${c.slug}?sub=${encodeURIComponent(sub)}`} className="rounded-lg p-2 text-center text-[11px] font-medium hover:shadow border" style={{ background: c.color + '0f' }}>
                  <div className="text-xl">{c.icon}</div>{sub}
                </Link>
              ))}
            </div>
          </div>
        ))}
      </section>

      {/* 12 + 13 CTAs */}
      <section className="grid md:grid-cols-2 gap-4 mt-6">
        <div className="rounded-xl p-6 bg-gradient-to-r from-brand to-[#3b82f6] text-white">
          <h3 className="text-xl md:text-2xl font-black">{s.cta?.vendorTitle}</h3>
          <p className="text-sm text-blue-100 mt-1">{s.cta?.vendorText}</p>
          <Link href="/login?intent=vendor&next=/register-business" className="btn bg-white text-brand mt-4">List Your Business – It&apos;s Free!</Link>
        </div>
        <div className="rounded-xl p-6 bg-orange-50 border border-orange-200">
          <h3 className="text-xl md:text-2xl font-black text-accent">{s.cta?.advertiseTitle}</h3>
          <p className="text-sm text-gray-600 mt-1">{s.cta?.advertiseText}</p>
          <Link href="/advertise" className="btn btn-accent mt-4">Explore Advertising Options</Link>
        </div>
      </section>
      <VideoModal url={video} onClose={() => setVideo(null)} />
    </div>
  );
}
