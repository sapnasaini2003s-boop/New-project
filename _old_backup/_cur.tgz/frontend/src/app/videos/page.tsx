'use client';
import { useState } from 'react';
import { useFetch, ytThumb } from '@/lib/api';
import VideoModal from '@/components/VideoModal';
export default function Videos() {
  const { data } = useFetch<any[]>('/videos'); const [v, setV] = useState<string | null>(null);
  return (<div className="max-w-6xl mx-auto px-3 md:px-4 py-6"><h1 className="text-2xl font-black mb-4">🎬 Videos</h1>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{data?.map((x) => (
      <button key={x._id} onClick={() => setV(x.url)} className="text-left card overflow-hidden"><div className="relative aspect-video bg-gray-200">{ytThumb(x.url) && <img src={ytThumb(x.url)} alt="" className="w-full h-full object-cover" />}<span className="absolute inset-0 flex items-center justify-center text-3xl text-white">▶</span></div><p className="p-2 text-sm font-semibold">{x.title}</p></button>
    ))}</div><VideoModal url={v} onClose={() => setV(null)} /></div>);
}
