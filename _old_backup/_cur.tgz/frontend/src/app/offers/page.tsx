'use client';
import { useFetch } from '@/lib/api';
export default function Offers() {
  const { data } = useFetch<any[]>('/offers');
  return (<div className="max-w-6xl mx-auto px-3 md:px-4 py-6"><h1 className="text-2xl font-black mb-4">🏷️ Local Offers & Deals</h1>
    <div className="grid md:grid-cols-3 gap-4">{data?.map((o, i) => (
      <div key={o._id} className="rounded-xl p-5 text-white" style={{ background: ['#FF6600', '#0055FF', '#16a34a'][i % 3] }}>
        <p className="text-xs opacity-80">{o.businessName} · {o.city}</p><h3 className="text-2xl font-black">{o.title}</h3><p className="text-sm">{o.subtitle}</p>
        {o.code && <p className="mt-3 inline-block border-2 border-dashed border-white/70 rounded px-3 py-1 font-mono font-bold">{o.code}</p>}<p className="text-xs mt-2 opacity-80">{o.expiry}</p>
      </div>))}</div>{data && !data.length && <p className="text-gray-500">No offers right now.</p>}</div>);
}
