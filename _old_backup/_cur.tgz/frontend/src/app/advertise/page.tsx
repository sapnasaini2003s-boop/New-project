'use client';
import Link from 'next/link';
import { useFetch } from '@/lib/api';
export default function Advertise() {
  const { data: p } = useFetch<any>('/pricing');
  const plans = [
    ['Free Listing', '₹0', ['Business page', '1 profile image', 'Search & category visibility', 'Contact buttons hidden'], 'btn-ghost'],
    ['Premium', `₹${p?.premium ?? '—'}/yr`, ['Call & WhatsApp buttons unlocked', 'Photo gallery + header banner', 'YouTube / FB / Instagram videos', 'Featured homepage slider', 'WhatsApp lead alerts', 'Banner ad booking'], 'btn-accent'],
    ['Banner Ads', `₹${p?.bannerPerDay ?? '—'}/day`, ['Top carousel / middle banner', 'Promotional widget', 'Hero video ad (2×)', 'Pay-per-day from dashboard', 'Premium vendors only'], 'btn-brand'],
  ] as const;
  return (<div className="max-w-6xl mx-auto px-4 py-8">
    <h1 className="text-3xl font-black text-center">Grow with <span className="text-brand">PVRS</span> <span className="text-accent">HUB</span></h1>
    <p className="text-center text-gray-600 mt-2">Reach students, tourists and locals across Udupi, Manipal, Malpe & Mangaluru.</p>
    <div className="grid md:grid-cols-3 gap-5 mt-8">{plans.map(([n, price, feats, btn]) => (
      <div key={n} className={`card p-6 flex flex-col ${n === 'Premium' ? 'border-accent border-2 shadow-lg' : ''}`}>
        <h3 className="font-bold text-lg">{n}</h3><p className="text-3xl font-black my-3">{price}</p>
        <ul className="text-sm space-y-2 flex-1">{feats.map((f) => <li key={f}>✔ {f}</li>)}</ul>
        <Link href="/login?intent=vendor&next=/vendor/dashboard" className={`btn ${btn} mt-5`}>Get started</Link>
      </div>))}</div>
    <p className="text-center text-xs text-gray-500 mt-6">Payments via Razorpay — UPI (GPay, PhonePe, Paytm), NetBanking, Cards. All content goes live after admin verification.</p>
  </div>);
}
