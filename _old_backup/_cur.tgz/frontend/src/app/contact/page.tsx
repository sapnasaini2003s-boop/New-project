'use client';
import { useState } from 'react';
import { api } from '@/lib/api';
export default function Contact() {
  const [f, setF] = useState<any>({ type: 'general' }); const [msg, setMsg] = useState('');
  const send = async (e: React.FormEvent) => { e.preventDefault(); try { setMsg((await api('/contact', { body: f })).message); setF({ type: 'general' }); } catch (e: any) { setMsg(e.message); } };
  return (<div className="max-w-4xl mx-auto px-4 py-6 grid md:grid-cols-2 gap-6">
    <div><h1 className="text-2xl font-black">Contact & Help</h1><p className="text-sm text-gray-600 mt-2">Questions about listings, advertising or a complaint? Write to us.</p>
      <div className="card p-4 mt-4 text-sm space-y-1"><p>📧 support@yourdomain.in</p><p>⚖️ Grievance / takedown: <a className="text-brand" href="mailto:legal@yourdomain.in">legal@yourdomain.in</a></p><p>📍 Udupi, Karnataka</p></div></div>
    <form onSubmit={send} className="card p-5 space-y-3">
      <select className="input" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="general">General</option><option value="advertise">Advertising</option><option value="complaint">Complaint / Takedown</option></select>
      <input required className="input" placeholder="Your name" value={f.name || ''} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <input className="input" placeholder="Mobile" value={f.phone || ''} onChange={(e) => setF({ ...f, phone: e.target.value })} />
      <textarea required rows={4} className="input" placeholder="Message" value={f.message || ''} onChange={(e) => setF({ ...f, message: e.target.value })} />
      <button className="btn btn-brand w-full">Send</button>{msg && <p className="text-sm text-center">{msg}</p>}
    </form></div>);
}
