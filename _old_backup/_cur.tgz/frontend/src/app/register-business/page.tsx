'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import ListingForm from '@/components/ListingForm';
import { useUser } from '@/lib/api';

export default function Register() {
  const { user, ready } = useUser(); const router = useRouter(); const [done, setDone] = useState('');
  useEffect(() => { if (ready && !user) router.replace('/login?intent=vendor&next=/register-business'); }, [ready, user, router]);
  if (!user) return null;
  return (
    <div className="max-w-4xl mx-auto px-3 md:px-4 py-6">
      <h1 className="text-2xl font-black">List Your Business – Free</h1>
      <p className="text-sm text-gray-500 mb-5">Your listing goes live after our team verifies your documents (usually within 24 hours).</p>
      {done ? (
        <div className="card p-8 text-center"><div className="text-5xl">✅</div><p className="font-bold mt-3">{done}</p><Link href="/vendor/dashboard" className="btn btn-brand mt-4">Go to Dashboard</Link></div>
      ) : <ListingForm onDone={setDone} />}
    </div>
  );
}
