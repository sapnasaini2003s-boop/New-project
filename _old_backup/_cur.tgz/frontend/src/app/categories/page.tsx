'use client';
import Link from 'next/link';
import { useFetch } from '@/lib/api';
export default function Categories() {
  const { data } = useFetch<any[]>('/categories');
  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4 py-6">
      <h1 className="text-2xl font-black mb-4">All Categories</h1>
      <div className="grid md:grid-cols-3 gap-4">
        {(data || []).map((c) => (
          <div key={c._id} className="card p-4">
            <Link href={`/category/${c.slug}`} className="font-bold text-lg hover:text-brand">{c.icon} {c.name}</Link>
            <div className="grid grid-cols-2 gap-2 mt-3">
              {c.subs.map((s: string) => <Link key={s} href={`/category/${c.slug}?sub=${encodeURIComponent(s)}`} className="border rounded-full px-3 py-1.5 text-xs hover:border-brand hover:text-brand truncate">{s}</Link>)}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
