'use client';
import { useEffect, useState } from 'react';
import { useFetch, getCity } from '@/lib/api';
import BizCard from './BizCard';

// Shared results grid with city filter
export default function Listing({ query, title, subs, sub, onSub }: { query: string; title: string; subs?: string[]; sub?: string; onSub?: (s: string) => void }) {
  const [city, setCity] = useState('');
  useEffect(() => { setCity(getCity()); }, []);
  const [allCities, setAll] = useState(false);
  const qs = query + (city && !allCities ? `&city=${city}` : '');
  const { data, loading } = useFetch<any[]>(`/businesses?${qs}`, []);
  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4 py-5">
      <div className="flex flex-wrap justify-between items-center gap-2 mb-3">
        <h1 className="text-xl md:text-2xl font-black">{title}</h1>
        <label className="text-xs flex items-center gap-2"><input type="checkbox" checked={allCities} onChange={(e) => setAll(e.target.checked)} /> All cities (not only {city})</label>
      </div>
      {subs && (
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-3">
          <button onClick={() => onSub?.('')} className={`shrink-0 rounded-full border px-3 py-1.5 text-xs ${!sub ? 'bg-brand text-white border-brand' : 'bg-white'}`}>All</button>
          {subs.map((s) => <button key={s} onClick={() => onSub?.(s)} className={`shrink-0 rounded-full border px-3 py-1.5 text-xs ${sub === s ? 'bg-brand text-white border-brand' : 'bg-white'}`}>{s}</button>)}
        </div>
      )}
      {loading ? <p className="text-gray-500">Loading…</p> : !data?.length ? (
        <div className="card p-8 text-center text-gray-500">No businesses found. Try &quot;All cities&quot; or another search.</div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">{data.map((b) => <BizCard key={b._id} b={b} />)}</div>
      )}
    </div>
  );
}
