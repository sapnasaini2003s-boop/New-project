'use client';
import Link from 'next/link';
import { api, img } from '@/lib/api';

export const track = (businessId: string, type: string) => api('/leads', { body: { businessId, type } }).catch(() => {});

export default function BizCard({ b }: { b: any }) {
  return (
    <div className="card overflow-hidden hover:shadow-lg transition flex flex-col border border-gray-200">
      <Link href={`/business/${b._id}`} className="block relative h-40 bg-gradient-to-br from-gray-100 to-gray-50">
        {(b.profileImage || b.image) ? <img src={img(b.profileImage || b.image)} alt={b.name} className="w-full h-full object-cover" /> : <div className="h-full flex items-center justify-center text-4xl opacity-50">🏪</div>}
        <div className="absolute top-2 left-2 flex gap-1">
          {b.badge === 'featured' && <span className="bg-yellow-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Featured</span>}
          {b.badge === 'premium' && <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Premium</span>}
          {b.badge === 'verified' && <span className="bg-green-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Verified</span>}
        </div>
        {!b.badge && b.plan === 'premium' && <span className="absolute top-2 left-2 bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Premium</span>}
      </Link>
      <div className="p-4 flex-1 flex flex-col">
        <Link href={`/business/${b._id}`} className="font-bold text-gray-900 text-[15px] truncate hover:text-brand">{b.name}</Link>
        <p className="text-[11px] text-gray-500 mt-0.5">{b.city} • {b.subCategory}</p>
        {b.rating > 0 && <p className="text-xs mt-2 flex items-center gap-1"><span className="bg-green-600 text-white px-1.5 py-0.5 rounded font-bold">{Number(b.rating).toFixed(1)} ★</span> <span className="text-gray-500">({b.reviews})</span></p>}
        {b.unclaimed && <Link href={`/business/${b._id}#claim`} className="flash mt-2 text-[11px] font-bold text-accent">⚠️ Claim it now!</Link>}
        <div className="mt-auto pt-4">
          {b.contact ? (
            <div className="flex gap-2">
              <a href={`tel:${b.contact.phone}`} onClick={() => track(b._id, 'call')} className="flex-1 btn btn-ghost border-green-200 text-green-700 hover:bg-green-50 hover:border-green-300 !py-2 !text-[11px] uppercase tracking-wide">📞 Call</a>
              <a href={`https://wa.me/91${b.contact.whatsapp || b.contact.phone}`} target="_blank" onClick={() => track(b._id, 'whatsapp')} className="flex-1 btn !py-2 !text-[11px] uppercase tracking-wide bg-green-500 text-white hover:bg-green-600">💬 WhatsApp</a>
            </div>
          ) : (
            <Link href={`/business/${b._id}`} className="btn btn-brand w-full !py-2 !text-[11px] uppercase tracking-wide">Send Enquiry</Link>
          )}
        </div>
      </div>
    </div>
  );
}
