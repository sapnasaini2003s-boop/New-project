'use client';
import { T } from '@/components/Icon';
import { E } from '@/components/Icon';
import { useState } from 'react';
import Link from 'next/link';
import { useFetch } from '@/lib/api';
import PageHero from '@/components/PageHero';
import HeaderBanner from '@/components/HeaderBanner';
const TONES = [['#FF6600', '#ff8a3d'], ['#0055FF', '#3b82f6'], ['#059669', '#34d399'], ['#7c3aed', '#a78bfa']];
export default function Offers() {
  const { data: home } = useFetch<any>('/home'); const { data } = useFetch<any[]>('/offers'); const [copied, setCopied] = useState('');
  const copy = (c: string) => { navigator.clipboard?.writeText(c); setCopied(c); setTimeout(() => setCopied(''), 1500); };
  return (<div>
    <PageHero title="Local Offers & Deals" icon="🏷️" tone="accent" subtitle="Exclusive discounts from verified businesses near you." />
    <HeaderBanner ads={home?.ads?.offers || []} />
    <div className="max-w-6xl mx-auto px-4 py-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">{data?.map((o, i) => { const [a, b] = TONES[i % TONES.length]; return (
        <div key={o._id} className="rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition bg-white border">
          <div className="px-4 py-3 text-white relative" style={{ background: `linear-gradient(135deg, ${a}, ${b})` }}>
            <div className="absolute right-3 top-2 text-3xl opacity-20">%</div>
            <p className="text-[10px] uppercase tracking-wider opacity-90">{o.businessName}</p>
            <h3 className="text-xl font-black leading-tight">{o.title}</h3><p className="text-xs opacity-90">{o.subtitle}</p>
          </div>
          <div className="relative border-t-2 border-dashed border-gray-200 px-4 py-2.5 flex items-center justify-between gap-2">
            <span className="absolute -left-2.5 -top-2.5 w-5 h-5 rounded-full bg-[#f5f7fb]" /><span className="absolute -right-2.5 -top-2.5 w-5 h-5 rounded-full bg-[#f5f7fb]" />
            <div><p className="text-[11px] text-gray-400"><E c="📍"/> {o.city} · {o.expiry}</p>{o.code && <p className="font-mono font-black text-sm tracking-widest text-gray-900">{o.code}</p>}{o.discountType && <p className="text-[11px] font-bold text-emerald-600">{o.discountType === 'percent' ? `${o.discountValue}% OFF` : `₹${o.discountValue} OFF`}{o.minOrder > 0 ? ` · min ₹${o.minOrder}` : ''} · applies at checkout</p>}</div>
            {o.businessId && <Link href={`/business/${o.businessId}?tab=menu`} className="btn btn-accent !text-[11px] !px-3 !py-1.5 mr-1">Order now</Link>}{o.code && <button onClick={() => copy(o.code)} className="btn btn-ghost !text-[11px] !px-3 !py-1.5">{copied === o.code ? <T>✓ Copied</T> : 'Copy code'}</button>}
          </div>
        </div>); })}</div>
      {data && !data.length && <div className="card p-12 text-center text-gray-500"><div className="text-5xl mb-2"><E c="🏷"/></div>No offers right now — check back soon.</div>}
    </div>
  </div>);
}
