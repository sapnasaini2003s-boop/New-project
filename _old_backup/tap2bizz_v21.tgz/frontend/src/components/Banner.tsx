'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { img } from '@/lib/api';
export default function Banner({ ads, h = 'min-h-24 md:min-h-28', hideEmpty = false }: { ads: any[]; h?: string; hideEmpty?: boolean }) {
  if (hideEmpty && !ads.length) return null;
  const [i, setI] = useState(0);
  useEffect(() => { if (ads.length < 2) return; const t = setInterval(() => setI((x) => (x + 1) % ads.length), 4000); return () => clearInterval(t); }, [ads.length]);
  if (!ads.length) return (
    <Link href="/advertise" className={`${h} rounded-xl border-2 border-dashed border-accent/50 bg-orange-50 flex items-center justify-center text-accent font-bold`}>Ad Space 970×90 — Book this slot</Link>
  );
  const a = ads[i % ads.length];
  return (
    <div className="relative">
      <Link href={a.link || '#'} className={`${h} rounded-xl overflow-hidden flex items-center justify-between px-4 md:px-10 py-3 pb-5 gap-3 text-white shadow`}
        style={{ background: a.image ? `url(${img(a.image)}) center/cover` : a.bg || 'linear-gradient(90deg,#0033aa,#0055FF)' }}>
        <div className={`min-w-0 ${a.image ? 'bg-black/40 p-2 rounded' : ''}`}>
          <h3 className="font-black text-base md:text-2xl tracking-wide line-clamp-2" style={{ color: a.bg?.includes('#eff6ff') ? '#0b1b3f' : undefined }}>{a.title}</h3>
          <p className="text-xs md:text-sm opacity-90 line-clamp-2" style={{ color: a.bg?.includes('#eff6ff') ? '#0055FF' : undefined }}>{a.subtitle}</p>
        </div>
        {!a.image && a.thumb && <img src={img(a.thumb)} alt="" loading="lazy" className="ml-auto w-20 h-14 md:w-44 md:h-20 rounded-lg object-cover shadow-md border border-white/40 shrink-0" onError={(e) => { e.currentTarget.style.display = 'none'; }} />}
        {a.cta && <span className="btn btn-accent !text-xs md:!text-sm shrink-0">{a.cta}</span>}
      </Link>
      {ads.length > 1 && <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 flex gap-1">{ads.map((_, k) => <span key={k} className={`w-1.5 h-1.5 rounded-full ${k === i % ads.length ? 'bg-white' : 'bg-white/50'}`} />)}</div>}
    </div>
  );
}


