'use client';
import { E } from '@/components/Icon';
import { ytId } from '@/lib/api';
export default function VideoModal({ url, onClose }: { url: string | null; onClose: () => void }) {
  if (!url) return null;
  const id = ytId(url); const ig = url.match(/instagram\.com\/(reel|reels|p|tv)\/([\w-]+)/i);
  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4" onClick={onClose}>
      <div className={`w-full bg-black rounded-xl overflow-hidden relative ${ig ? "max-w-[400px] h-[85vh] max-h-[720px]" : "max-w-3xl aspect-video"}`} onClick={(e) => e.stopPropagation()}>
        {ig ? <iframe className="w-full h-full bg-white" src={`https://www.instagram.com/${ig[1].toLowerCase() === 'reels' ? 'reel' : ig[1].toLowerCase()}/${ig[2]}/embed`} allow="autoplay; encrypted-media; clipboard-write" allowFullScreen />
          : id ? <iframe className="w-full h-full" src={`https://www.youtube.com/embed/${id}?autoplay=1`} allow="autoplay; encrypted-media" allowFullScreen />
          : <iframe className="w-full h-full" src={url} allowFullScreen />}
        <button onClick={onClose} className="absolute top-2 right-2 bg-white/90 rounded-full w-8 h-8 font-bold"><E c="✕"/></button>
      </div>
    </div>
  );
}
