'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { img } from '@/lib/api';
// Wide header banner for the Offers / Videos pages — managed in Admin → Ads & Banners (slot: "Offers page" / "Videos page"). Renders nothing when no banner is live.
export default function HeaderBanner({ ads }: { ads: any[] }) {
  const [i, setI] = useState(0);
  useEffect(() => { if (ads.length < 2) return; const t = setInterval(() => setI((x) => (x + 1) % ads.length), 4500); return () => clearInterval(t); }, [ads.length]);
  if (!ads.length) return null;
  const a = ads[i % ads.length]; const bg = a.image ? `url(${img(a.image)}) center/cover no-repeat` : a.bg || 'linear-gradient(110deg,#0033aa,#0055ff 60%,#4f8cff)';
  const Inner = (
    <div className="relative rounded-2xl overflow-hidden shadow-lg shadow-blue-900/10 ring-1 ring-black/5 min-h-[150px] md:min-h-[210px] flex items-center" style={{ background: bg }}>
      <div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/30 to-transparent" />
      <div className="relative px-5 md:px-10 py-5 max-w-[640px] text-white">
        <h2 className="text-xl md:text-4xl font-extrabold leading-tight drop-shadow line-clamp-2">{a.title}</h2>
        {a.subtitle && <p className="mt-1.5 text-sm md:text-lg text-white/90 line-clamp-2">{a.subtitle}</p>}
        {a.cta && <span className="inline-block mt-3 md:mt-4 bg-white text-brand font-bold text-sm md:text-base px-5 py-2 rounded-full shadow">{a.cta} →</span>}
      </div>
      {ads.length > 1 && <div className="absolute bottom-2.5 inset-x-0 flex justify-center gap-1.5">{ads.map((_, k) => <button key={k} type="button" aria-label={`Banner ${k + 1}`} onClick={(e) => { e.preventDefault(); setI(k); }} className={`h-1.5 rounded-full transition-all ${k === i % ads.length ? 'w-5 bg-white' : 'w-1.5 bg-white/50'}`} />)}</div>}
    </div>
  );
  return <div className="max-w-6xl mx-auto px-4 pt-4">{a.link ? <Link href={a.link} className="block">{Inner}</Link> : Inner}</div>;
}
