'use client';
import Link from 'next/link';
import { useState } from 'react';
import { api, useUser } from '@/lib/api';
const ITEMS: [string, string, string, string][] = [['issue', '📝', 'Report an Issue', ''], ['list', '🏪', 'Want to list with us?', '/register-business'], ['txn', '💳', 'My transaction', '/vendor/dashboard'], ['grievance', '⚖️', 'Grievance Redressal', '']];
export default function Support() {
  const { user } = useUser(); const [modal, setModal] = useState<'login' | 'issue' | 'grievance' | null>(null);
  const [text, setText] = useState(''); const [msg, setMsg] = useState(''); const [busy, setBusy] = useState(false);
  const open = (k: string, href: string) => { if (href) { if (k === 'txn' && !user) return setModal('login'); window.location.href = href; return; } if (!user) return setModal('login'); setMsg(''); setText(''); setModal(k as any); };
  const submit = async () => { setBusy(true); try { setMsg((await api('/grievances', { body: { kind: modal, details: text } })).message); setText(''); } catch (e: any) { setMsg(e.message); } setBusy(false); };
  return (<div className="min-h-[70vh] bg-white">
    <div className="bg-brand text-white text-center py-3 font-semibold text-sm">Customer Support</div>
    <div className="max-w-xl mx-auto px-4 py-6">
      <h1 className="text-center font-bold text-lg mb-4">Hi! How can we help you today?</h1>
      <div className="divide-y border-t border-b">{ITEMS.map(([k, i, l, h]) => (
        <button key={k} onClick={() => open(k, h)} className="w-full flex items-center gap-4 py-4 text-left hover:bg-gray-50"><span className="text-2xl w-9">{i}</span><span className="flex-1 font-semibold">{l}</span><span className="text-gray-400">›</span></button>))}</div>
      <p className="text-xs text-gray-500 mt-6 text-center">Grievance Officer (IT Act): <a className="text-brand" href="mailto:legal@yourdomain.in">legal@yourdomain.in</a></p>
    </div>
    {modal && <div className="fixed inset-0 z-50 bg-black/50 flex items-end md:items-center justify-center" onClick={() => setModal(null)}>
      <div className="bg-white w-full md:max-w-md rounded-t-2xl md:rounded-2xl p-5 slideup" onClick={(e) => e.stopPropagation()}>
        {modal === 'login' ? <>
          <p className="mb-4">Please login to register a complaint.</p>
          <div className="flex gap-2"><button onClick={() => setModal(null)} className="btn btn-ghost flex-1">Close</button><Link href="/login?intent=user&next=/contact" className="btn btn-brand flex-1 text-center">Login</Link></div></> : <>
          <div className="flex justify-between items-center mb-2"><h3 className="font-bold">{modal === 'issue' ? 'Report an Issue' : 'Grievance Redressal'}</h3><button onClick={() => setModal(null)} className="text-xl">✕</button></div>
          <p className="text-xs text-gray-500 mb-3">{modal === 'grievance' ? 'In the event that you are not satisfied with the resolution provided by our team you can contact our grievance redressal officer.' : 'Tell us about the problem you faced.'}</p>
          <textarea rows={4} className="input mb-2" placeholder="Please write your query here, and our team will act on it in 24-48 hours" value={text} onChange={(e) => setText(e.target.value)} />
          {msg && <p className="text-sm text-brand mb-2">{msg}</p>}
          <div className="flex gap-2"><button onClick={() => setModal(null)} className="btn btn-ghost flex-1">Cancel</button><button disabled={busy || text.trim().length < 5} onClick={submit} className="btn btn-brand flex-1 disabled:opacity-50">Submit</button></div></>}
      </div></div>}
  </div>);
}
