import { Metadata } from 'next';

async function fetchBiz(id: string) {
  try {
    const res = await fetch(`https://pvrs-backend.onrender.com/api/businesses/${id}`, { next: { revalidate: 300 } });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const b = await fetchBiz(params.id);
  if (!b) return { title: 'Business Not Found | PVRS HUB' };
  
  return {
    title: `${b.name} in ${b.city} | PVRS HUB`,
    description: b.description || `View details, contact, and reviews for ${b.name} in ${b.city} on PVRS HUB.`,
    keywords: [b.name, b.city, b.category, ...(b.tags || [])].filter(Boolean).join(', '),
    openGraph: {
      title: `${b.name} | PVRS HUB`,
      description: b.description || `Contact ${b.name} today.`,
      images: b.profileImage ? [`https://pvrs-backend.onrender.com${b.profileImage}`] : [],
    }
  };
}

export default function BusinessLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
