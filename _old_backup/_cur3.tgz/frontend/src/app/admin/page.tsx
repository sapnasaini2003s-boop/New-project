﻿'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { api, img, privateFile, useFetch, useUser, logout } from '@/lib/api';

/* ─── Business Detail Modal ─── */
function ViewBusiness({ b, onClose }: { b: any; onClose: () => void }) {
  if (!b) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center p-4 overflow-y-auto" onClick={onClose}>
      <div className="bg-white rounded-3xl w-full max-w-3xl my-8 shadow-2xl overflow-hidden animate-in" onClick={(e) => e.stopPropagation()}>
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-slate-800 to-slate-900 text-white p-6 relative">
          <button onClick={onClose} className="absolute top-4 right-4 w-8 h-8 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center transition">✕</button>
          <div className="flex gap-4 items-start">
            <div className="w-20 h-20 rounded-2xl bg-white/10 overflow-hidden flex items-center justify-center shrink-0 shadow-lg">
              {(b.profileImage || b.image) ? <img src={img(b.profileImage || b.image)} alt="" className="w-full h-full object-cover" /> : <span className="text-4xl">🏪</span>}
            </div>
            <div>
              <h2 className="text-2xl font-black">{b.name}</h2>
              <p className="text-slate-300 text-sm mt-1">{b.category} › {b.subCategory}</p>
              <div className="flex gap-2 mt-2 flex-wrap">
                {b.plan === 'premium' && <span className="bg-amber-400 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-full">⭐ PREMIUM</span>}
                {b.verified && <span className="bg-emerald-400 text-emerald-900 text-[10px] font-bold px-2 py-0.5 rounded-full">✔ VERIFIED</span>}
                {b.badge && <span className="bg-blue-400 text-blue-900 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">{b.badge}</span>}
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${b.status === 'approved' ? 'bg-emerald-400 text-emerald-900' : b.status === 'pending' ? 'bg-amber-400 text-amber-900' : 'bg-red-400 text-red-900'}`}>{b.status?.toUpperCase()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[['⭐ Rating', b.rating ? Number(b.rating).toFixed(1) : 'N/A'], ['💬 Reviews', b.reviews || 0], ['👁 Views', b.views || 0], ['📞 Leads', b.leads || 0]].map(([label, val]) => (
              <div key={label} className="bg-slate-50 rounded-xl p-3 text-center">
                <p className="text-[11px] text-slate-400 font-medium">{label}</p>
                <p className="text-xl font-black text-slate-800 mt-0.5">{val}</p>
              </div>
            ))}
          </div>

          {/* Info Grid */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">📍 Location & Contact</h3>
              <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                <p><span className="text-slate-400 font-medium">City:</span> <span className="text-slate-700 font-semibold">{b.city || '—'}</span></p>
                <p><span className="text-slate-400 font-medium">Address:</span> <span className="text-slate-700">{b.address || '—'}</span></p>
                <p><span className="text-slate-400 font-medium">Phone:</span> <span className="text-slate-700 font-mono">{b.contact?.phone || '—'}</span></p>
                <p><span className="text-slate-400 font-medium">WhatsApp:</span> <span className="text-slate-700 font-mono">{b.contact?.whatsapp || '—'}</span></p>
                {b.timings && <p><span className="text-slate-400 font-medium">Timings:</span> <span className="text-slate-700">{b.timings}</span></p>}
              </div>
            </div>
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">💼 Plan & Subscription</h3>
              <div className="bg-slate-50 rounded-xl p-4 space-y-2 text-sm">
                <p><span className="text-slate-400 font-medium">Plan:</span> <span className={`font-bold ${b.plan === 'premium' ? 'text-amber-600' : 'text-slate-600'}`}>{b.plan?.toUpperCase()}</span></p>
                {b.planExpiry && <p><span className="text-slate-400 font-medium">Expiry:</span> <span className="text-slate-700">{new Date(b.planExpiry).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</span></p>}
                <p><span className="text-slate-400 font-medium">Unclaimed:</span> <span className="text-slate-700">{b.unclaimed ? 'Yes ⚠️' : 'No'}</span></p>
                {b.owner && <p><span className="text-slate-400 font-medium">Owner:</span> <span className="text-slate-700">{b.owner.name || '—'} (+91 {b.owner.phone})</span></p>}
                <p><span className="text-slate-400 font-medium">Created:</span> <span className="text-slate-700">{b.createdAt ? new Date(b.createdAt).toLocaleDateString('en-IN') : '—'}</span></p>
              </div>
            </div>
          </div>

          {/* Documents */}
          {b.documents && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">📄 Compliance Documents</h3>
              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm space-y-1">
                <p><span className="text-amber-600 font-medium">Type:</span> <span className="text-amber-900 font-semibold">{b.documents.type}</span></p>
                <p><span className="text-amber-600 font-medium">Number:</span> <span className="text-amber-900 font-mono">{b.documents.number || '—'}</span></p>
                <p><span className="text-amber-600 font-medium">Expiry:</span> <span className="text-amber-900">{b.documents.expiry || '—'}</span></p>
                {b.documents.file && <a href={privateFile(b.documents.file)} target="_blank" className="inline-block mt-2 bg-amber-100 hover:bg-amber-200 text-amber-800 px-4 py-2 rounded-lg text-xs font-bold transition">📎 View Document File</a>}
              </div>
            </div>
          )}

          {/* Description */}
          {b.description && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">📝 Description</h3>
              <p className="bg-slate-50 rounded-xl p-4 text-sm text-slate-600 whitespace-pre-line leading-relaxed">{b.description}</p>
            </div>
          )}

          {/* Order Online Links */}
          {b.orderOnline && Object.values(b.orderOnline).some(Boolean) && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider">🛵 Order Online Links</h3>
              <div className="flex gap-2">
                {b.orderOnline.swiggy && <a href={b.orderOnline.swiggy} target="_blank" className="bg-orange-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Swiggy →</a>}
                {b.orderOnline.zomato && <a href={b.orderOnline.zomato} target="_blank" className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Zomato →</a>}
              </div>
            </div>
          )}

          {/* Pending Updates */}
          {b.pendingUpdates && Object.keys(b.pendingUpdates).length > 0 && (
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-amber-700 uppercase tracking-wider">⚠️ Pending Edit Request</h3>
              <div className="bg-amber-50 border border-amber-200 rounded-xl overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-amber-100"><tr><th className="p-2.5 text-left text-amber-800">Field</th><th className="text-left text-amber-800">Current</th><th className="text-left text-amber-800">Requested</th></tr></thead>
                  <tbody>{Object.entries(b.pendingUpdates).map(([k, v]: any) => (
                    <tr key={k} className="border-t border-amber-200"><td className="p-2.5 font-semibold text-amber-900">{k}</td><td className="text-amber-700 p-2.5">{b[k] != null ? String(b[k]) : '—'}</td><td className="text-amber-900 font-medium p-2.5">{String(v)}</td></tr>
                  ))}</tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 flex justify-between items-center border-t border-slate-100">
          <p className="text-[11px] text-slate-400">ID: {b._id}</p>
          <div className="flex gap-2">
            <Link href={`/business/${b._id}`} target="_blank" className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-xs font-bold hover:bg-blue-100 transition">🌐 View Public Page</Link>
            <button onClick={onClose} className="bg-slate-200 text-slate-700 px-5 py-2 rounded-xl text-xs font-bold hover:bg-slate-300 transition">Close</button>
          </div>
        </div>
      </div>
    </div>
  );
}

const TABS = [
  ['overview', '📊', 'Overview'],
  ['queue', '🛡️', 'Approval Queue'],
  ['businesses', '🏪', 'Businesses'],
  ['users', '👥', 'Users'],
  ['ads', '📢', 'Ads & Banners'],
  ['categories', '📂', 'Categories'],
  ['content', '📝', 'Offers / Blogs / Videos'],
  ['settings', '⚙️', 'Homepage Settings'],
  ['legal', '⚖️', 'Legal Pages'],
  ['enquiries', '📨', 'Enquiries & Reviews'],
  ['payments', '💳', 'Payments'],
  ['logs', '🔔', 'Notifications & Logs'],
];

const Badge = ({ s }: { s: string }) => (
  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full inline-flex items-center gap-1 ${
    ({ pending: 'bg-amber-50 text-amber-700 ring-1 ring-amber-200', approved: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200', rejected: 'bg-red-50 text-red-700 ring-1 ring-red-200', suspended: 'bg-slate-100 text-slate-600 ring-1 ring-slate-200', expired: 'bg-slate-100 text-slate-500', paid: 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200', premium: 'bg-blue-50 text-blue-700 ring-1 ring-blue-200', blocked: 'bg-red-50 text-red-700 ring-1 ring-red-200' } as any)[s] || 'bg-slate-100 text-slate-600'
  }`}>
    <span className={`w-1.5 h-1.5 rounded-full ${
      ({ pending: 'bg-amber-500', approved: 'bg-emerald-500', rejected: 'bg-red-500', suspended: 'bg-slate-400', paid: 'bg-emerald-500', premium: 'bg-blue-500', blocked: 'bg-red-500' } as any)[s] || 'bg-slate-400'
    }`} />
    {s}
  </span>
);

export default function Admin() {
  const { user, ready } = useUser(); const router = useRouter();
  const [tab, setTab] = useState('overview'); const [nav, setNav] = useState(false);
  const queue = useFetch<any>(user?.role === 'admin' ? '/admin/queue' : null);
  useEffect(() => { if (ready && !user) router.replace('/admin/login'); }, [ready, user, router]);
  if (!user || user.role !== 'admin') return (
    <div className="p-10 text-center space-y-3 min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex flex-col items-center justify-center">
      <div className="bg-white rounded-2xl max-w-sm w-full p-8 shadow-2xl">
        <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4"><span className="text-3xl">🔒</span></div>
        <h2 className="text-xl font-black text-slate-800 mb-2">Access Denied</h2>
        <p className="text-sm text-gray-500 mb-6">{user ? `Logged in as +91 ${user.phone} (${user.role}). Admin access required.` : 'Please log in to continue.'}</p>
        <button onClick={() => { logout(); router.push('/admin/login'); }} className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white font-bold py-3 rounded-xl hover:shadow-lg transition">Go to Admin Login</button>
      </div>
    </div>
  );
  const c = queue.data?.counts || {}; const total = Object.values(c).reduce((a: any, b: any) => a + b, 0) as number;
  const currentTab = TABS.find((t) => t[0] === tab);

  return (
    <div className="min-h-screen flex bg-[#fafafa]">
      {/* Sidebar */}
      {nav && <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={() => setNav(false)} />}
      <aside className={`${nav ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 fixed md:static inset-y-0 left-0 z-40 w-[260px] bg-gradient-to-b from-[#0f172a] to-[#1e293b] text-slate-300 flex flex-col transition-transform duration-200`}>
        <div className="p-5 pb-2">
          <div className="flex items-center gap-2.5 mb-1">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center text-white font-black text-sm shadow-lg shadow-blue-500/30">P</div>
            <div><span className="text-lg font-black text-white tracking-wide">PVRS</span> <span className="text-lg font-black text-blue-400">HUB</span></div>
          </div>
          <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-semibold ml-[46px] -mt-1">Admin Console</p>
        </div>
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-0.5">
          {TABS.map(([k, icon, label]) => (
            <button key={k} onClick={() => { setTab(k); setNav(false); }}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-[13px] font-medium flex items-center gap-3 transition-all duration-150 ${
                tab === k
                  ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-600/30'
                  : 'hover:bg-white/5 text-slate-400 hover:text-white'
              }`}>
              <span className="text-base w-6 text-center">{icon}</span>
              <span className="flex-1">{label}</span>
              {k === 'queue' && total > 0 && <span className="bg-red-500 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse">{total}</span>}
            </button>
          ))}
        </div>
        <div className="p-4 border-t border-white/10 space-y-1">
          <Link href="/" className="flex items-center gap-2 text-sm text-slate-400 hover:text-white transition px-2 py-1.5 rounded-lg hover:bg-white/5">
            <span>←</span> <span>View Website</span>
          </Link>
          <button onClick={() => { logout(); router.push('/'); }} className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 transition px-2 py-1.5 rounded-lg hover:bg-red-500/10 w-full">
            <span>⏻</span> <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0">
        {/* Top bar */}
        <header className="bg-white/80 backdrop-blur-md border-b border-slate-200/50 px-6 md:px-10 py-5 flex items-center gap-5 sticky top-0 z-20 shadow-[0_4px_20px_-10px_rgba(0,0,0,0.05)]">
          <button className="md:hidden w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition" onClick={() => setNav(true)}>
            <span className="text-lg">☰</span>
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-black text-slate-800 flex items-center gap-2">
              <span className="text-xl">{currentTab?.[1]}</span> {currentTab?.[2]}
            </h1>
            <p className="text-xs text-slate-400 hidden md:block">Welcome back, Admin • {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</p>
          </div>
          <div className="flex items-center gap-3">
            {total > 0 && <button onClick={() => setTab('queue')} className="relative bg-red-50 text-red-600 px-3 py-2 rounded-xl text-xs font-bold hover:bg-red-100 transition">
              🔔 {total} Pending
            </button>}
            <div className="w-9 h-9 bg-gradient-to-br from-slate-700 to-slate-800 rounded-full flex items-center justify-center text-white text-sm font-bold">A</div>
          </div>
        </header>

        <div className="p-4 md:p-8">
          {tab === 'overview' && <Overview />}
          {tab === 'queue' && <Queue q={queue} />}
          {tab === 'businesses' && <Businesses />}
          {tab === 'users' && <Users />}
          {tab === 'ads' && <Ads />}
          {tab === 'categories' && <Categories />}
          {tab === 'content' && <Content />}
          {tab === 'settings' && <Settings />}
          {tab === 'legal' && <Legal />}
          {tab === 'enquiries' && <Enquiries />}
          {tab === 'payments' && <Payments />}
          {tab === 'logs' && <Logs />}
        </div>
      </main>
    </div>
  );
}

/* ─── Overview ─── */
function Overview() {
  const { data: d } = useFetch<any>('/admin/overview');
  if (!d) return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5 animate-pulse">
      {[...Array(8)].map((_, i) => <div key={i} className="bg-white rounded-[20px] p-6 border border-slate-200/60 shadow-sm"><div className="h-5 bg-slate-100 rounded-lg w-1/3 mb-5" /><div className="h-10 bg-slate-100 rounded-xl w-2/3" /></div>)}
    </div>
  );

  const cards = [
    { label: 'Revenue', value: '₹' + d.revenue.toLocaleString('en-IN'), icon: '💰', color: 'text-emerald-600', bg: 'bg-emerald-50', border: 'border-emerald-100/50' },
    { label: 'Premium', value: d.premium, icon: '⭐', color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-100/50' },
    { label: 'Free', value: d.free, icon: '🆓', color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-100/50' },
    { label: 'Live Listings', value: d.live, icon: '🟢', color: 'text-teal-600', bg: 'bg-teal-50', border: 'border-teal-100/50' },
    { label: 'Suspended', value: d.suspended, icon: '⛔', color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-100/50' },
    { label: 'Total Users', value: d.users, icon: '👥', color: 'text-indigo-600', bg: 'bg-indigo-50', border: 'border-indigo-100/50' },
    { label: 'Leads Generated', value: d.leads, icon: '📞', color: 'text-purple-600', bg: 'bg-purple-50', border: 'border-purple-100/50' },
    { label: 'Pending Approval', value: Object.values(d.queue).reduce((a: any, b: any) => a + b, 0), icon: '⏳', color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-100/50' },
  ];

  return (
    <div className="space-y-8 animate-[fadeIn_0.3s_ease-out]">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5">
        {cards.map((c, i) => (
          <div key={i} className="bg-white rounded-[20px] p-6 border border-slate-200/60 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_30px_-6px_rgba(0,0,0,0.08)] transition-all duration-300 relative overflow-hidden group hover:-translate-y-0.5">
            <div className={'absolute top-0 left-0 right-0 h-1 ' + c.bg + ' opacity-0 group-hover:opacity-100 transition-opacity'}></div>
            <div className="flex items-center gap-3.5 mb-5">
              <div className={'w-11 h-11 rounded-2xl border flex items-center justify-center text-xl group-hover:scale-110 transition-transform shadow-sm ' + c.bg + ' ' + c.border + ' ' + c.color}>
                {c.icon}
              </div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.15em]">{c.label}</p>
            </div>
            <p className="text-4xl font-black text-slate-800 tracking-tight">{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6 md:gap-8">
        <div className="bg-white rounded-[24px] p-7 md:p-8 border border-slate-200/60 shadow-[0_4px_24px_-4px_rgba(0,0,0,0.02)] relative overflow-hidden">
          <div className="absolute -top-6 -right-6 p-8 opacity-[0.03] text-8xl pointer-events-none rotate-12">📥</div>
          <h3 className="font-bold text-slate-800 text-xl mb-6 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shadow-sm">📥</span> 
            Approval Queue
          </h3>
          <div className="space-y-2 relative z-10">
            {Object.entries(d.queue).map(([k, v]: any) => (
              <div key={k} className="flex justify-between items-center p-3.5 rounded-[14px] hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-colors cursor-default">
                <span className="text-sm text-slate-600 capitalize font-semibold tracking-wide">{k}</span>
                <span className={'text-xs font-bold px-3 py-1.5 rounded-lg ' + (v > 0 ? 'bg-amber-100 text-amber-700 shadow-sm' : 'bg-slate-100 text-slate-400')}>
                  {v} Pending
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-[24px] p-7 md:p-8 border border-slate-200/60 shadow-[0_4px_24px_-4px_rgba(0,0,0,0.02)] relative overflow-hidden">
          <div className="absolute -top-6 -right-6 p-8 opacity-[0.03] text-8xl pointer-events-none rotate-12">📈</div>
          <h3 className="font-bold text-slate-800 text-xl mb-6 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center shadow-sm">📈</span> 
            Search Demand
          </h3>
          <div className="space-y-2 relative z-10">
            {Object.entries(d.searchStats).length === 0 && <p className="text-sm text-slate-400 py-4 text-center font-medium bg-slate-50 rounded-2xl border border-slate-100">No search data yet</p>}
            {Object.entries(d.searchStats).sort((a: any, b: any) => b[1] - a[1]).slice(0, 5).map(([k, v]: any) => (
              <div key={k} className="flex justify-between items-center p-3.5 rounded-[14px] hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-colors cursor-default group">
                <span className="text-sm text-slate-700 font-medium group-hover:text-blue-600 transition-colors capitalize">{k.replace(/-/g, ' ')}</span>
                <div className="flex items-center gap-3">
                  <div className="w-20 h-1.5 bg-slate-100 rounded-full overflow-hidden hidden sm:block shadow-inner">
                    <div className="h-full bg-blue-500 rounded-full" style={{ width: Math.min((v / 20) * 100, 100) + '%' }}></div>
                  </div>
                  <span className="text-xs font-bold text-slate-600 bg-white shadow-sm border border-slate-200/60 px-2.5 py-1 rounded-md min-w-[2.5rem] text-center">{v}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Diff({ b }: { b: any }) {
  const u = b.pendingUpdates || {};
  const show = (v: any) => (v == null ? '—' : typeof v === 'object' ? JSON.stringify(v) : String(v));
  return (
    <div className="mt-3 rounded-xl border border-slate-200 overflow-hidden">
      <table className="w-full text-xs">
        <thead className="bg-slate-50"><tr><th className="p-2.5 text-left font-semibold text-slate-500">Field</th><th className="text-left font-semibold text-slate-500">Current</th><th className="text-left font-semibold text-slate-500">Requested</th></tr></thead>
        <tbody>{Object.keys(u).map((k) => (
          <tr key={k} className="border-t border-slate-100 align-top"><td className="p-2.5 font-semibold text-slate-700">{k}</td><td className="text-slate-400 break-all p-2.5">{show(b[k])}</td>
            <td className={`break-all p-2.5 ${show(b[k]) !== show(u[k]) ? 'bg-amber-50 font-semibold text-amber-800' : ''}`}>{k === 'documents' && u[k]?.file ? <a className="text-blue-600 underline" target="_blank" href={privateFile(u[k].file)}>View document</a> : show(u[k])}</td></tr>
        ))}</tbody>
      </table>
    </div>
  );
}

/* ─── Approval Queue ─── */
function Queue({ q }: { q: any }) {
  const [sub, setSub] = useState('listings'); const [reason, setReason] = useState('');
  const [viewBiz, setViewBiz] = useState<any>(null);
  const d = q.data || {};
  const act = async (path: string, body?: any) => { try { await api(path, { method: 'PUT', body: body || {} }); q.reload(); } catch (e: any) { alert(e.message); } };
  const reject = (id: string) => { const r = prompt('Reason for rejection?', reason || 'Documents unclear'); if (r !== null) { setReason(r); act(`/admin/listings/${id}/reject`, { reason: r }); } };
  const L = (b: any, edit = false) => (
    <div key={b._id} className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-md transition">
      <div className="flex flex-wrap gap-3 justify-between">
        <div className="flex gap-4">
          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-slate-50 to-slate-100 overflow-hidden flex items-center justify-center shadow-sm">{b.profileImage ? <img src={img(b.profileImage)} alt="" className="w-full h-full object-cover" /> : <span className="text-2xl">🏪</span>}</div>
          <div>
            <div className="flex items-center gap-2"><b className="text-slate-800">{b.name}</b> {b.plan === 'premium' && <Badge s="premium" />}</div>
            <p className="text-xs text-slate-400 mt-0.5">{b.category} › {b.subCategory} · {b.city}</p>
            <p className="text-xs text-slate-500 mt-1">👤 {b.owner?.name} · +91 {b.owner?.phone} {b.owner?.status === 'pending' && <Badge s="pending" />}</p>
          </div>
        </div>
        <div className="flex gap-2 items-start">
          <button onClick={() => setViewBiz(b)} className="bg-blue-50 hover:bg-blue-100 text-blue-600 px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm">👁 View</button>
          {b.documents?.file && <a href={privateFile(b.documents.file)} target="_blank" className="bg-slate-50 text-slate-600 px-3 py-2 rounded-xl text-xs font-medium hover:bg-slate-100 transition">📄 {b.documents.type}</a>}
          <button onClick={() => act(`/admin/listings/${b._id}/approve`)} className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm shadow-emerald-500/20">✔ Approve</button>
          <button onClick={() => reject(b._id)} className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-xl text-xs font-bold transition shadow-sm shadow-red-500/20">✕ Reject</button>
        </div>
      </div>
      {b.documents && <p className="text-xs text-slate-400 mt-2">Certificate: {b.documents.number || '—'} · Expiry: {b.documents.expiry || '—'}</p>}
      {edit ? <Diff b={b} /> : <p className="text-xs text-slate-500 mt-3 bg-slate-50 p-3 rounded-xl">{b.description}</p>}
    </div>
  );
  return (<div>
    <ViewBusiness b={viewBiz} onClose={() => setViewBiz(null)} />
    <p className="text-sm text-slate-500 mb-4 bg-blue-50 text-blue-700 p-3 rounded-xl font-medium">🛡️ Section 79 Safety Queue — Nothing goes live without your approval.</p>
    <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
      {[['listings', 'New Listings'], ['edits', 'Edit Requests'], ['vendors', 'Vendor Signups'], ['ads', 'Banner Ads'], ['claims', 'Claims'], ['reviews', 'Reviews']].map(([k, l]) => (
        <button key={k} onClick={() => setSub(k)} className={`px-4 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${sub === k ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'bg-white text-slate-500 border border-slate-200 hover:border-blue-300'}`}>{l} ({d.counts?.[k] || 0})</button>
      ))}
    </div>
    <div className="space-y-3">
      {sub === 'listings' && d.listings?.map((b: any) => L(b))}
      {sub === 'edits' && d.edits?.map((b: any) => L(b, true))}
      {sub === 'vendors' && d.vendors?.map((u: any) => (
        <div key={u._id} className="bg-white rounded-2xl p-5 flex justify-between items-center border border-slate-100"><div><b className="text-slate-800">{u.name || 'Vendor'}</b><p className="text-xs text-slate-400 mt-1">+91 {u.phone} · joined {new Date(u.createdAt).toLocaleDateString()}</p></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/users/${u._id}`, { status: 'approved' })} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Approve</button><button onClick={() => act(`/admin/users/${u._id}`, { status: 'rejected' })} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div></div>
      ))}
      {sub === 'ads' && d.ads?.map((a: any) => (
        <div key={a._id} className="bg-white rounded-2xl p-5 flex flex-wrap gap-3 justify-between items-center border border-slate-100">
          <div className="flex gap-3 items-center">{a.image && <img src={img(a.image)} alt="" className="h-12 rounded-xl" />}<div><b className="text-slate-800">{a.title}</b> <Badge s={a.paymentStatus} /><p className="text-xs text-slate-400 mt-1">{a.type} · {a.days} days · ₹{a.amount}</p></div></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/ads/${a._id}`, { status: 'approved' })} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Approve</button><button onClick={() => act(`/admin/ads/${a._id}`, { status: 'rejected' })} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div>
        </div>
      ))}
      {sub === 'claims' && d.claims?.map((c: any) => (
        <div key={c._id} className="bg-white rounded-2xl p-5 flex justify-between items-center border border-slate-100"><div><b className="text-slate-800">{c.businessName}</b><p className="text-xs text-slate-400 mt-1">Claimed by {c.name} +91 {c.phone}</p><a href={privateFile(c.document)} target="_blank" className="text-xs text-blue-600 underline">View proof</a></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/claims/${c._id}/approve`)} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Approve</button><button onClick={() => act(`/admin/claims/${c._id}/reject`)} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div></div>
      ))}
      {sub === 'reviews' && d.reviews?.map((r: any) => (
        <div key={r._id} className="bg-white rounded-2xl p-5 flex flex-wrap gap-3 justify-between items-center border border-slate-100">
          <div><b className="text-slate-800">{r.businessName}</b> <span className="text-amber-500 font-bold ml-1">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span>
            <p className="text-sm text-slate-600 mt-1">“{r.text || '—'}”</p><p className="text-xs text-slate-400 mt-1">by {r.name} +91 {r.phone}</p></div>
          <div className="flex gap-2"><button onClick={() => act(`/admin/reviews/${r._id}/approve`)} className="bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Publish</button><button onClick={() => act(`/admin/reviews/${r._id}/reject`)} className="bg-red-500 text-white px-4 py-2 rounded-xl text-xs font-bold">Reject</button></div>
        </div>
      ))}
      {!d[sub]?.length && <div className="bg-white rounded-2xl p-10 text-center border border-slate-100"><span className="text-4xl">🎉</span><p className="text-slate-500 mt-3 font-medium">All clear! Nothing pending here.</p></div>}
    </div>
  </div>);
}

/* ─── Businesses ─── */
function Businesses() {
  const list = useFetch<any[]>('/admin/businesses'); const { data: cats } = useFetch<any[]>('/categories');
  const [q, setQ] = useState(''); const [form, setForm] = useState<any>(null);
  const [viewBiz, setViewBiz] = useState<any>(null);
  const act = async (p: string, method = 'PUT', body: any = {}) => { try { await api(p, { method, body }); list.reload(); } catch (e: any) { alert(e.message); } };
  const save = async (e: React.FormEvent) => {
    e.preventDefault(); const fd = new FormData(e.target as HTMLFormElement);
    fd.set('contact', JSON.stringify({ phone: fd.get('phone'), whatsapp: fd.get('whatsapp') })); fd.delete('phone'); fd.delete('whatsapp');
    fd.set('unclaimed', fd.get('unclaimed') ? 'true' : 'false');
    ['profileImage'].forEach((k) => { const f = fd.get(k) as File; if (!f?.size) fd.delete(k); });
    try { await api(form._id ? `/admin/businesses/${form._id}` : '/admin/businesses', { method: form._id ? 'PUT' : 'POST', form: fd }); setForm(null); list.reload(); } catch (e: any) { alert(e.message); }
  };
  const rows = (list.data || []).filter((b) => !q || JSON.stringify([b.name, b.city, b.category, b.contact?.phone]).toLowerCase().includes(q.toLowerCase()));
  return (<div>
    <ViewBusiness b={viewBiz} onClose={() => setViewBiz(null)} />
    <div className="flex gap-3 mb-5">
      <div className="flex-1 relative">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">🔍</span>
        <input className="w-full bg-white border border-slate-200 rounded-xl pl-11 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 transition" placeholder="Search name, city, phone…" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <button onClick={() => setForm({ unclaimed: true, plan: 'free' })} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-5 py-3 rounded-xl text-sm font-bold shadow-lg shadow-blue-600/20 hover:shadow-xl transition shrink-0">+ Pre-load Business</button>
    </div>
    {form && (
      <form onSubmit={save} className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 mb-5 border border-blue-200 shadow-lg shadow-blue-500/5">
        <input name="name" required defaultValue={form.name} placeholder="Business Name" className="input" />
        <select name="category" required defaultValue={form.category} className="input"><option value="">Select Category</option>{cats?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select>
        <input name="subCategory" defaultValue={form.subCategory} placeholder="Sub-category" className="input" list="subs" />
        <datalist id="subs">{cats?.flatMap((c) => c.subs).map((s: string) => <option key={s} value={s} />)}</datalist>
        <input name="city" defaultValue={form.city || 'Udupi'} placeholder="City" className="input" />
        <input name="address" defaultValue={form.address} placeholder="Address" className="input" />
        <input name="phone" defaultValue={form.contact?.phone} placeholder="Phone" className="input" />
        <input name="whatsapp" defaultValue={form.contact?.whatsapp} placeholder="WhatsApp" className="input" />
        <select name="plan" defaultValue={form.plan} className="input"><option value="free">Free</option><option value="premium">Premium</option></select>
        <input name="planExpiry" type="date" defaultValue={form.planExpiry?.slice(0, 10)} className="input" title="Plan expiry" />
        <input name="rating" defaultValue={form.rating} placeholder="Rating (e.g. 4.5)" className="input" />
        <input name="reviews" defaultValue={form.reviews} placeholder="No. of ratings" className="input" />
        <input name="profileImage" type="file" accept="image/*" className="input" />
        <textarea name="description" defaultValue={form.description} placeholder="Description" className="input md:col-span-3" />
        <label className="text-sm flex gap-2 items-center text-slate-600"><input type="checkbox" name="unclaimed" defaultChecked={form.unclaimed} className="rounded" /> Unclaimed (show "Claim it now")</label>
        <div className="md:col-span-2 flex gap-2 justify-end"><button type="button" onClick={() => setForm(null)} className="px-5 py-2.5 rounded-xl text-sm text-slate-500 hover:bg-slate-50 transition">Cancel</button><button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-sm">Save</button></div>
      </form>
    )}
    <div className="bg-white rounded-2xl overflow-hidden border border-slate-100"><table className="w-full text-sm"><thead className="bg-slate-50/80 text-left"><tr><th className="p-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Business</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">City</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Plan</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Status</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Views</th><th className="text-right pr-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Actions</th></tr></thead>
      <tbody>{rows.map((b) => (
        <tr key={b._id} className="border-t border-slate-100 hover:bg-blue-50/30 transition"><td className="p-4"><b className="text-slate-800">{b.name}</b>{b.unclaimed && <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-full ml-2">UNCLAIMED</span>}{b.pendingUpdates && <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-full ml-1">EDIT</span>}<br /><span className="text-xs text-slate-400">{b.subCategory}</span></td>
          <td className="text-slate-600">{b.city}</td><td><span className="text-xs font-medium">{b.plan}</span>{b.planExpiry && <div className="text-[10px] text-slate-400">till {new Date(b.planExpiry).toLocaleDateString()}</div>}</td><td><Badge s={b.status} /></td><td className="text-slate-600">{b.views || 0}</td>
          <td className="text-right pr-4 whitespace-nowrap space-x-1">
            <button onClick={() => setViewBiz(b)} className="text-blue-600 hover:bg-blue-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">View</button>
            <button onClick={() => setForm(b)} className="text-blue-600 hover:bg-blue-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Edit</button>
            {b.status === 'approved' ? <button onClick={() => act(`/admin/listings/${b._id}/suspend`)} className="text-amber-600 hover:bg-amber-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Suspend</button> : <button onClick={() => act(`/admin/listings/${b._id}/approve`)} className="text-emerald-600 hover:bg-emerald-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Approve</button>}
            <button onClick={() => confirm('Delete permanently?') && act(`/admin/businesses/${b._id}`, 'DELETE')} className="text-red-500 hover:bg-red-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Delete</button>
          </td></tr>
      ))}</tbody></table></div>
  </div>);
}

/* ─── Users ─── */
function Users() {
  const u = useFetch<any[]>('/admin/users');
  const upd = async (id: string, body: any) => { await api(`/admin/users/${id}`, { method: 'PUT', body }); u.reload(); };
  return (<div className="bg-white rounded-2xl overflow-hidden border border-slate-100"><table className="w-full text-sm"><thead className="bg-slate-50/80 text-left"><tr><th className="p-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Name</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Phone</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Role</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Status</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Actions</th></tr></thead>
    <tbody>{u.data?.map((x) => <tr key={x._id} className="border-t border-slate-100 hover:bg-blue-50/30 transition"><td className="p-4 font-medium text-slate-800">{x.name || '—'}</td><td className="text-slate-600">+91 {x.phone}</td>
      <td><select value={x.role} onChange={(e) => upd(x._id, { role: e.target.value })} className="bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 text-xs font-medium"><option>user</option><option>vendor</option><option>admin</option></select></td>
      <td><Badge s={x.blocked ? 'blocked' : x.status} /></td>
      <td className="space-x-1">{x.status !== 'approved' && <button onClick={() => upd(x._id, { status: 'approved' })} className="text-emerald-600 hover:bg-emerald-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">Approve</button>}
        <button onClick={() => upd(x._id, { blocked: !x.blocked })} className="text-amber-600 hover:bg-amber-50 px-2.5 py-1.5 rounded-lg text-xs font-medium transition">{x.blocked ? 'Unblock' : 'Block'}</button></td></tr>)}</tbody></table></div>);
}

/* ─── Ads ─── */
function Ads() {
  const ads = useFetch<any[]>('/admin/ads'); const [f, setF] = useState<any>(null);
  const save = async (e: React.FormEvent) => {
    e.preventDefault(); const fd = new FormData(e.target as HTMLFormElement); const im = fd.get('image') as File; if (!im?.size) fd.delete('image');
    try { await api(f._id ? `/admin/ads/${f._id}` : '/admin/ads', { method: f._id ? 'PUT' : 'POST', form: fd }); setF(null); ads.reload(); } catch (e: any) { alert(e.message); }
  };
  const upd = async (id: string, body: any, method = 'PUT') => { await api(`/admin/ads/${id}`, { method, body }); ads.reload(); };
  return (<div>
    <button onClick={() => setF({ type: 'top_banner' })} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-5 py-3 rounded-xl text-sm font-bold shadow-lg shadow-blue-600/20 mb-5">+ New Ad / Banner</button>
    {f && (
      <form onSubmit={save} className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 mb-5 border border-blue-200">
        <select name="type" defaultValue={f.type} className="input"><option value="top_banner">Top banner (970×90)</option><option value="middle_banner">Middle banner</option><option value="promo">Promotional widget</option><option value="hero_video">Hero video ad</option></select>
        <input name="title" defaultValue={f.title} placeholder="Title" className="input" />
        <input name="subtitle" defaultValue={f.subtitle} placeholder="Subtitle" className="input" />
        <input name="cta" defaultValue={f.cta} placeholder="Button text" className="input" />
        <input name="link" defaultValue={f.link} placeholder="Link URL" className="input" />
        <input name="youtubeUrl" defaultValue={f.youtubeUrl} placeholder="YouTube URL" className="input" />
        <input name="bg" defaultValue={f.bg} placeholder="Background CSS" className="input" />
        <input name="imageUrl" defaultValue={f.image?.startsWith('http') ? f.image : ''} placeholder="Image URL" className="input" />
        <input name="image" type="file" accept="image/*" className="input" />
        <label className="text-xs text-slate-500 font-medium">Start Date<input name="startDate" type="date" defaultValue={f.startDate?.slice(0, 10)} className="input mt-1" /></label>
        <label className="text-xs text-slate-500 font-medium">End Date<input name="endDate" type="date" defaultValue={f.endDate?.slice(0, 10)} className="input mt-1" /></label>
        <div className="flex gap-2 items-end justify-end"><button type="button" onClick={() => setF(null)} className="px-4 py-2 text-slate-500 hover:bg-slate-50 rounded-xl text-sm transition">Cancel</button><button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold">Save</button></div>
      </form>
    )}
    <div className="grid md:grid-cols-2 gap-4">{ads.data?.map((a) => (
      <div key={a._id} className="bg-white rounded-2xl p-5 border border-slate-100 hover:shadow-md transition">
        <div className="flex justify-between items-start"><b className="text-slate-800">{a.title}</b><Badge s={a.status} /></div>
        <p className="text-xs text-slate-400 mt-1">{a.type} · by {a.createdBy} {a.amount ? `· ₹${a.amount} (${a.paymentStatus})` : ''} {a.endDate ? `· till ${new Date(a.endDate).toLocaleDateString()}` : ''}</p>
        <div className="flex gap-1 mt-3">
          <button onClick={() => setF(a)} className="text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Edit</button>
          {a.status !== 'approved' ? <button onClick={() => upd(a._id, { status: 'approved' })} className="text-emerald-600 hover:bg-emerald-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Activate</button> : <button onClick={() => upd(a._id, { status: 'paused' })} className="text-amber-600 hover:bg-amber-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Pause</button>}
          <button onClick={() => confirm('Delete?') && upd(a._id, {}, 'DELETE')} className="text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Delete</button>
        </div>
      </div>
    ))}</div>
  </div>);
}

/* ─── Categories ─── */
function Categories() {
  const cats = useFetch<any[]>('/categories');
  const save = async (c: any) => { try { await api(c._id ? `/admin/categories/${c._id}` : '/admin/categories', { method: c._id ? 'PUT' : 'POST', body: c }); cats.reload(); } catch (e: any) { alert(e.message); } };
  const [n, setN] = useState<any>({ name: '', icon: '📁', subs: '', color: '#0055FF' });
  return (<div className="space-y-3">
    {cats.data?.map((c) => <CatRow key={c._id} c={c} onSave={save} onDel={async () => { if (confirm('Delete category?')) { await api(`/admin/categories/${c._id}`, { method: 'DELETE' }); cats.reload(); } }} />)}
    <div className="bg-white rounded-2xl p-5 grid md:grid-cols-5 gap-3 border-2 border-dashed border-blue-200">
      <input className="input" placeholder="Icon" value={n.icon} onChange={(e) => setN({ ...n, icon: e.target.value })} />
      <input className="input" placeholder="Category Name" value={n.name} onChange={(e) => setN({ ...n, name: e.target.value })} />
      <input className="input md:col-span-2" placeholder="Sub-categories (comma separated)" value={n.subs} onChange={(e) => setN({ ...n, subs: e.target.value })} />
      <button onClick={() => { save(n); setN({ name: '', icon: '📁', subs: '', color: '#0055FF' }); }} className="bg-blue-600 text-white px-4 py-2.5 rounded-xl text-sm font-bold">+ Add Category</button>
    </div>
  </div>);
}
function CatRow({ c, onSave, onDel }: any) {
  const [v, setV] = useState({ ...c, subs: c.subs.join(', ') });
  return (<div className="bg-white rounded-2xl p-4 grid md:grid-cols-12 gap-3 items-center border border-slate-100 hover:shadow-sm transition">
    <input className="input md:col-span-1 text-center text-xl" value={v.icon} onChange={(e) => setV({ ...v, icon: e.target.value })} />
    <input className="input md:col-span-3 font-medium" value={v.name} onChange={(e) => setV({ ...v, name: e.target.value })} />
    <input className="input md:col-span-5 text-xs" value={v.subs} onChange={(e) => setV({ ...v, subs: e.target.value })} />
    <input className="input md:col-span-1" type="number" value={v.order} onChange={(e) => setV({ ...v, order: Number(e.target.value) })} title="Order" />
    <div className="md:col-span-2 flex gap-2"><button onClick={() => onSave({ _id: c._id, name: v.name, icon: v.icon, subs: v.subs, order: v.order })} className="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex-1">Save</button><button onClick={onDel} className="text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg text-xs font-medium">Del</button></div>
  </div>);
}

/* ─── Content ─── */
function Content() {
  const [kind, setKind] = useState('offers');
  const list = useFetch<any[]>(`/admin/${kind}`);
  const FIELDS: Record<string, string[]> = { offers: ['title', 'subtitle', 'businessName', 'city', 'code', 'expiry'], blogs: ['title', 'excerpt', 'body', 'image'], videos: ['title', 'url', 'category'] };
  const [f, setF] = useState<any>({});
  const save = async () => { try { await api(f._id ? `/admin/${kind}/${f._id}` : `/admin/${kind}`, { method: f._id ? 'PUT' : 'POST', body: f }); setF({}); list.reload(); } catch (e: any) { alert(e.message); } };
  return (<div>
    <div className="flex gap-2 mb-5">{['offers', 'blogs', 'videos'].map((k) => <button key={k} onClick={() => { setKind(k); setF({}); }} className={`px-5 py-2.5 rounded-xl text-xs font-bold capitalize transition ${kind === k ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'bg-white text-slate-500 border border-slate-200 hover:border-blue-300'}`}>{k}</button>)}</div>
    <div className="bg-white rounded-2xl p-5 grid md:grid-cols-3 gap-3 mb-5 border border-slate-100">
      {FIELDS[kind].map((k) => k === 'body' ? <textarea key={k} rows={4} className="input md:col-span-3" placeholder={k} value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />
        : <input key={k} className="input" placeholder={k === 'url' ? 'YouTube / video URL' : k} value={f[k] || ''} onChange={(e) => setF({ ...f, [k]: e.target.value })} />)}
      <div className="flex gap-2"><button onClick={save} className="bg-blue-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold">{f._id ? 'Update' : '+ Add'}</button>{f._id && <button onClick={() => setF({})} className="px-4 py-2 text-slate-500 hover:bg-slate-50 rounded-xl text-sm">Cancel</button>}</div>
    </div>
    <div className="space-y-2">{list.data?.map((x) => (
      <div key={x._id} className="bg-white rounded-2xl p-4 flex justify-between items-center text-sm border border-slate-100 hover:shadow-sm transition"><div><b className="text-slate-800">{x.title}</b><p className="text-xs text-slate-400 mt-0.5">{x.subtitle || x.excerpt || x.url}</p></div>
        <div className="flex gap-1"><button onClick={() => setF(x)} className="text-blue-600 hover:bg-blue-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Edit</button>
          <button onClick={async () => { if (confirm('Delete?')) { await api(`/admin/${kind}/${x._id}`, { method: 'DELETE' }); list.reload(); } }} className="text-red-500 hover:bg-red-50 px-3 py-1.5 rounded-lg text-xs font-medium transition">Delete</button></div></div>
    ))}</div>
  </div>);
}

/* ─── Settings ─── */
function useSettings() {
  const s = useFetch<any>('/admin/settings');
  const save = async (patch: any) => { try { await api('/admin/settings', { method: 'PUT', body: patch }); s.reload(); alert('Saved'); } catch (e: any) { alert(e.message); } };
  return { s: s.data, save };
}
function Settings() {
  const { s, save } = useSettings(); const [v, setV] = useState<any>(null);
  useEffect(() => { if (s) setV(JSON.parse(JSON.stringify(s))); }, [s]);
  if (!v) return <div className="flex items-center justify-center py-20"><div className="animate-spin w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full" /></div>;
  const F = (path: string, label: string, area = false) => {
    const [a, b] = path.split('.'); const val = b ? v[a]?.[b] : v[a];
    const on = (e: any) => setV(b ? { ...v, [a]: { ...(v[a] || {}), [b]: e.target.value } } : { ...v, [a]: e.target.value });
    return <div key={path}><label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">{label}</label>{area ? <textarea className="input" rows={2} value={val || ''} onChange={on} /> : <input className="input" value={val || ''} onChange={on} />}</div>;
  };
  return (<div className="space-y-5">
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-2 gap-4 border border-slate-100"><h3 className="md:col-span-2 font-bold text-slate-800 text-lg">🎯 Hero Section</h3>{F('hero.title', 'Hero Title')}{F('hero.subtitle', 'Hero Subtitle')}
      <div className="md:col-span-2"><label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1.5">Popular Searches</label><input className="input" value={(v.popularSearches || []).join(', ')} onChange={(e) => setV({ ...v, popularSearches: e.target.value.split(',').map((x: string) => x.trim()).filter(Boolean) })} /></div></div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-4 gap-4 border border-slate-100"><h3 className="md:col-span-4 font-bold text-slate-800 text-lg">📊 Trust Counters</h3>{F('stats.businesses', 'Businesses')}{F('stats.customers', 'Customers')}{F('stats.verified', 'Verified Label')}{F('stats.support', 'Support Label')}</div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 border border-slate-100"><h3 className="md:col-span-3 font-bold text-slate-800 text-lg">📍 Location Banner</h3>{F('locationBanner.title', 'Title')}{F('locationBanner.subtitle', 'Subtitle')}{F('locationBanner.image', 'Image URL')}</div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-2 gap-4 border border-slate-100"><h3 className="md:col-span-2 font-bold text-slate-800 text-lg">📢 CTA Boxes</h3>{F('cta.vendorTitle', 'Vendor CTA Title')}{F('cta.vendorText', 'Vendor CTA Text')}{F('cta.advertiseTitle', 'Advertise Title')}{F('cta.advertiseText', 'Advertise Text')}</div>
    <div className="bg-white rounded-2xl p-6 grid md:grid-cols-3 gap-4 border border-slate-100"><h3 className="md:col-span-3 font-bold text-slate-800 text-lg">🔗 Social & Apps</h3>{F('social.facebook', 'Facebook')}{F('social.instagram', 'Instagram')}{F('social.youtube', 'YouTube')}{F('social.linkedin', 'LinkedIn')}{F('apps.android', 'Play Store URL')}{F('apps.ios', 'App Store URL')}</div>
    <button onClick={() => { const { pages, searchStats, ...rest } = v; save(rest); }} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-blue-600/20 hover:shadow-xl transition">💾 Save Homepage Settings</button>
  </div>);
}

/* ─── Legal ─── */
function Legal() {
  const { s, save } = useSettings(); const [pages, setPages] = useState<any>(null);
  useEffect(() => { if (s) setPages(s.pages || {}); }, [s]);
  if (!pages) return <div className="flex items-center justify-center py-20"><div className="animate-spin w-8 h-8 border-4 border-blue-200 border-t-blue-600 rounded-full" /></div>;
  return (<div className="space-y-4">{Object.entries(pages).map(([k, p]: any) => (
    <div key={k} className="bg-white rounded-2xl p-6 border border-slate-100"><input className="input font-bold mb-3 text-lg" value={p.title} onChange={(e) => setPages({ ...pages, [k]: { ...p, title: e.target.value } })} />
      <textarea className="input" rows={8} value={p.body} onChange={(e) => setPages({ ...pages, [k]: { ...p, body: e.target.value } })} /><p className="text-xs text-slate-400 mt-2">🔗 URL: /legal/{k}</p></div>
  ))}<button onClick={() => save({ pages })} className="bg-gradient-to-r from-blue-600 to-blue-500 text-white px-8 py-3 rounded-xl font-bold shadow-lg shadow-blue-600/20">💾 Save Legal Pages</button></div>);
}

/* ─── Payments ─── */
function Payments() {
  const p = useFetch<any[]>('/admin/payments');
  return (<div className="bg-white rounded-2xl overflow-hidden border border-slate-100"><table className="w-full text-sm"><thead className="bg-slate-50/80 text-left"><tr><th className="p-4 font-semibold text-slate-500 text-xs uppercase tracking-wider">Date</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Purpose</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Amount</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Razorpay ID</th><th className="font-semibold text-slate-500 text-xs uppercase tracking-wider">Status</th></tr></thead>
    <tbody>{p.data?.map((x) => <tr key={x._id} className="border-t border-slate-100 hover:bg-blue-50/30 transition"><td className="p-4 text-slate-600">{new Date(x.createdAt).toLocaleString()}</td><td className="text-slate-800 font-medium">{x.purpose}{x.mock && <span className="text-[10px] bg-amber-50 text-amber-600 px-1.5 py-0.5 rounded-full ml-1">TEST</span>}</td><td className="font-bold text-slate-800">₹{x.amount}</td><td className="text-xs text-slate-400 font-mono">{x.razorpayPaymentId || x.orderId}</td><td><Badge s={x.status} /></td></tr>)}</tbody></table></div>);
}

/* ─── Logs ─── */
function Logs() {
  const n = useFetch<any[]>('/admin/notifications'); const a = useFetch<any[]>('/admin/audit');
  const run = async () => { const r = await api('/admin/run-expiry-job', { body: {} }); alert(JSON.stringify(r)); n.reload(); };
  return (<div className="grid md:grid-cols-2 gap-6">
    <div>
      <div className="flex justify-between items-center mb-4"><h3 className="font-bold text-slate-800 text-lg">🔔 Notifications</h3><button onClick={run} className="bg-amber-50 text-amber-700 px-4 py-2 rounded-xl text-xs font-bold hover:bg-amber-100 transition">Run Expiry Check</button></div>
      <div className="space-y-2">{n.data?.map((x) => <div key={x._id} className="bg-white rounded-2xl p-4 text-xs border border-slate-100"><div className="flex justify-between"><b className="text-slate-800">{x.title}</b><span className="text-slate-400">[{x.channel}]</span></div><p className="text-slate-500 mt-1">{x.message}</p><p className="text-slate-400 mt-2">{new Date(x.createdAt).toLocaleString()}</p></div>)}</div></div>
    <div>
      <h3 className="font-bold text-slate-800 text-lg mb-4">📋 Audit Log</h3>
      <div className="space-y-2">{a.data?.map((x) => <div key={x._id} className="bg-white rounded-2xl p-4 text-xs border border-slate-100"><b className="text-slate-800">{x.action}</b> <span className="text-slate-400 font-mono">{JSON.stringify(x.meta)}</span><p className="text-slate-400 mt-2">{new Date(x.createdAt).toLocaleString()}</p></div>)}</div></div>
  </div>);
}

/* ─── Enquiries & Reviews ─── */
function Enquiries() {
  const e = useFetch<any[]>('/admin/enquiries'); const r = useFetch<any[]>('/admin/reviews');
  const del = async (id: string) => { if (confirm('Delete review?')) { await api(`/admin/reviews/${id}`, { method: 'DELETE' }); r.reload(); } };
  return (<div className="grid lg:grid-cols-2 gap-6">
    <div><h3 className="font-bold text-slate-800 mb-3">📨 Customer enquiries ({e.data?.length || 0})</h3>
      <div className="space-y-2">{e.data?.map((x) => (
        <div key={x._id} className="bg-white rounded-2xl p-4 border border-slate-100 text-sm">
          <div className="flex justify-between"><b>{x.businessName}</b><Badge s={x.status} /></div>
          <p className="text-slate-600 mt-1">{x.message || '—'}</p>
          <p className="text-xs text-slate-400 mt-1">{x.name} · +91 {x.phone} · {new Date(x.createdAt).toLocaleString('en-IN')}</p>
        </div>))}{!e.data?.length && <p className="text-slate-400 text-sm">No enquiries yet.</p>}</div></div>
    <div><h3 className="font-bold text-slate-800 mb-3">⭐ All reviews ({r.data?.length || 0})</h3>
      <div className="space-y-2">{r.data?.map((x) => (
        <div key={x._id} className="bg-white rounded-2xl p-4 border border-slate-100 text-sm">
          <div className="flex justify-between items-center"><b>{x.businessName}</b><div className="flex gap-2 items-center"><Badge s={x.status} /><button onClick={() => del(x._id)} className="text-red-500 text-xs">Delete</button></div></div>
          <p className="text-amber-500">{'★'.repeat(x.rating)}{'☆'.repeat(5 - x.rating)}</p><p className="text-slate-600">{x.text}</p>
          <p className="text-xs text-slate-400">{x.name} · {new Date(x.createdAt).toLocaleDateString('en-IN')}</p>
        </div>))}</div></div>
  </div>);
}

