'use client';
import { useEffect, useMemo, useState } from 'react';
import { useFetch, getCity } from '@/lib/api';
import BizCard from './BizCard';

// Shared results grid with city / sort / filter controls
export default function Listing({ query, title, subs, sub, onSub }: { query: string; title: string; subs?: string[]; sub?: string; onSub?: (s: string) => void }) {
  const [city, setCity] = useState('');
  useEffect(() => { setCity(getCity()); }, []);
  const [allCities, setAll] = useState(false);
  const [sort, setSort] = useState('relevance');
  const [only, setOnly] = useState({ verified: false, premium: false, rated: false });
  const qs = query + (city && !allCities ? `&city=${city}` : '');
  const { data, loading } = useFetch<any[]>(city ? `/businesses?${qs}` : null, []);
  const list = useMemo(() => {
    let l = [...(data || [])];
    if (only.verified) l = l.filter((b) => b.verified);
    if (only.premium) l = l.filter((b) => b.plan === 'premium');
    if (only.rated) l = l.filter((b) => b.rating >= 4);
    if (sort === 'rating') l.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    if (sort === 'reviews') l.sort((a, b) => (b.reviews || 0) - (a.reviews || 0));
    if (sort === 'name') l.sort((a, b) => a.name.localeCompare(b.name));
    return l;
  }, [data, only, sort]);
  const chip = (on: boolean) => `shrink-0 rounded-full border px-3 py-1.5 text-xs font-medium transition ${on ? 'bg-brand text-white border-brand' : 'bg-white hover:border-brand'}`;

  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4 py-5">
      <div className="flex flex-wrap justify-between items-end gap-2 mb-3">
        <div><h1 className="text-xl md:text-2xl font-black">{title}</h1><p className="text-xs text-gray-500">{loading ? 'Searching…' : `${list.length} result${list.length === 1 ? '' : 's'}`} {!allCities && city && `in ${city}`}</p></div>
        <select value={sort} onChange={(e) => setSort(e.target.value)} className="input !w-auto !py-1.5 text-sm">
          <option value="relevance">Sort: Relevance</option><option value="rating">Top rated</option><option value="reviews">Most reviewed</option><option value="name">Name A–Z</option>
        </select>
      </div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
        <button onClick={() => setAll(!allCities)} className={chip(allCities)}>🌐 All cities</button>
        <button onClick={() => setOnly({ ...only, verified: !only.verified })} className={chip(only.verified)}>✔ Verified</button>
        <button onClick={() => setOnly({ ...only, premium: !only.premium })} className={chip(only.premium)}>★ Premium</button>
        <button onClick={() => setOnly({ ...only, rated: !only.rated })} className={chip(only.rated)}>4.0+ Rated</button>
      </div>
      {subs && (
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 mb-2">
          <button onClick={() => onSub?.('')} className={chip(!sub)}>All</button>
          {subs.map((s) => <button key={s} onClick={() => onSub?.(s)} className={chip(sub === s)}>{s}</button>)}
        </div>
      )}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">{[0, 1, 2, 3].map((i) => <div key={i} className="card h-72 animate-pulse bg-gray-100" />)}</div>
      ) : !list.length ? (
        <div className="card p-10 text-center"><div className="text-5xl">🔎</div><p className="font-semibold mt-3">No businesses found</p><p className="text-sm text-gray-500">Try “All cities”, remove filters, or search something else.</p></div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">{list.map((b) => <BizCard key={b._id} b={b} />)}</div>
      )}
    </div>
  );
}
