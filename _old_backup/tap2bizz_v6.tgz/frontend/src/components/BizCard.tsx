'use client';
import { E } from '@/components/Icon';
import Link from 'next/link';
import { api, img } from '@/lib/api';

export const track = (businessId: string, type: string) => api('/leads', { body: { businessId, type } }).catch(() => {});

export default function BizCard({ b }: { b: any }) {
  return (
    <div className="card overflow-hidden hover:shadow-lg transition flex flex-col border border-gray-200">
      <Link href={`/business/${b._id}`} className="block relative h-40 bg-gradient-to-br from-gray-100 to-gray-50">
        {(b.profileImage || b.image) ? <img src={img(b.profileImage || b.image)} alt={b.name} className="w-full h-full object-cover text-[0px]" onError={(e) => { e.currentTarget.style.display = "none"; }} /> : <div className="h-full flex items-center justify-center text-4xl opacity-50"><E c="🏪"/></div>}
        <div className="absolute top-2 left-2 flex gap-1">
          {b.badge === 'featured' && <span className="bg-yellow-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Featured</span>}
          {b.badge === 'premium' && <span className="bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Premium</span>}
          {b.badge === 'verified' && <span className="bg-green-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Verified</span>}
        </div>
        {!b.badge && b.plan === 'premium' && <span className="absolute top-2 left-2 bg-blue-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">Premium</span>}
      </Link>
      <div className="p-4 flex-1 flex flex-col">
        <Link href={`/business/${b._id}`} className="font-bold text-gray-900 text-[15px] truncate hover:text-brand">{b.name}</Link>
        <p className="text-[11px] text-gray-500 mt-0.5">{b.city} • {b.subCategory}</p>
        {b.rating > 0 && <p className="text-xs mt-2 flex items-center gap-1"><span className="bg-green-600 text-white px-1.5 py-0.5 rounded font-bold">{Number(b.rating).toFixed(1)} ★</span> <span className="text-gray-500">({b.reviews})</span></p>}
        {b.distanceKm != null && <p className="text-[11px] text-brand font-semibold mt-1"><E c="📍"/> {b.distanceKm} km away</p>}
        {b.contactLocked && <p className="text-[11px] text-gray-500 mt-1 font-mono"><E c="📞"/> XXXXXXXXXX <E c="🔒"/></p>}
        {b.unclaimed && <Link href={`/business/${b._id}#claim`} className="flash mt-2 text-[11px] font-bold text-accent"><E c="⚠"/> Claim it now!</Link>}
        <div className="mt-auto pt-4">
          {b.contact ? (
            <div className="flex gap-2">
              <a href={`tel:$Call Now`} onClick={() => track(b._id, 'call')} className="flex-1 btn btn-ghost border-green-200 text-green-700 hover:bg-green-50 hover:border-green-300 !py-2 !text-[11px] uppercase tracking-wide flex items-center justify-center gap-1.5"><svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 md:w-4 md:h-4"><path d="M20.01 15.38c-1.23 0-2.42-.2-3.53-.56a.977.977 0 00-1.01.24l-1.57 1.97c-2.83-1.35-5.48-3.9-6.89-6.83l1.95-1.66c.27-.28.35-.67.24-1.02-.37-1.11-.56-2.3-.56-3.53 0-.54-.45-.99-.99-.99H4.19C3.65 3 3 3.24 3 3.99 3 13.28 10.73 21 20.01 21c.71 0 .99-.63.99-1.18v-3.45c0-.54-.45-.99-.99-.99z"/></svg> Call</a>
              <a href={`https://wa.me/91${b.contact.whatsapp || b.contact.phone}`} target="_blank" onClick={() => track(b._id, 'whatsapp')} className="flex-1 btn !py-2 !text-[11px] uppercase tracking-wide bg-green-500 text-white hover:bg-green-600 flex items-center justify-center gap-1.5"><svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3 md:w-4 md:h-4"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg> WhatsApp</a>
            </div>
          ) : (
            <Link href={`/business/${b._id}#enquiry`} className="btn btn-brand w-full !py-2 !text-[11px] uppercase tracking-wide">Send Enquiry</Link>
          )}
        </div>
      </div>
    </div>
  );
}
