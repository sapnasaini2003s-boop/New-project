// Icon system (lucide). <E c="🏠"/> swaps a pictograph for the icon that fits its meaning; <T>text with 📞 emoji</T> does it inside strings.
import React from 'react';
import {
  Home, Search, Check, X, ArrowRight, Newspaper, Menu, Folder, Tag, Flame, Building2, Store, Megaphone, User, Users, Heart, Scale, MapPin, Phone, MessageCircle, Mail, Clock, Map as MapIcon, Star,
  Lock, Bike, ShieldCheck, CheckCircle2, TrendingUp, BarChart3, Bell, SlidersHorizontal, Server, CreditCard, Rocket, FileText, Paperclip, ClipboardList, PenLine, Clapperboard, Play, Image as ImageIcon,
  Link2, Globe, ShoppingCart, ShoppingBag, Printer, Download, QrCode, Flag, Trophy, Gem, UtensilsCrossed, Eye, Save, Palette, Target, AlertTriangle, Compass, LifeBuoy, LayoutGrid, Sparkles,
  Smartphone, Briefcase, Plus, Info, Upload, Wrench, Handshake, Bot, Inbox, ListPlus, UserCog, PartyPopper, BedDouble, Stethoscope, GraduationCap, Hammer, Car, Flower2, Landmark, Utensils, Hospital,
  type LucideIcon,
} from 'lucide-react';

// pictograph -> [icon, tailwind colour class, filled?]
const M: Record<string, [LucideIcon, string?, boolean?]> = {
  '🏠': [Home], '🔍': [Search], '🔎': [Search], '📰': [Newspaper], '☰': [Menu], '📂': [Folder], '📁': [Folder], '🏷': [Tag], '🔥': [Flame, 'text-orange-500'],
  '🏢': [Building2], '🏪': [Store], '🛍': [ShoppingBag], '📢': [Megaphone], '📣': [Megaphone], '👤': [User], '🧑': [User], '👥': [Users], '🤝': [Handshake], '❤': [Heart, 'text-red-500', true], '🤍': [Heart],
  '⚖': [Scale], '📍': [MapPin, 'text-red-500'], '📞': [Phone], '☎': [Phone], '💬': [MessageCircle], '✉': [Mail], '📨': [Inbox], '🕒': [Clock], '🗺': [MapIcon], '⭐': [Star, 'text-amber-400', true],
  '🔒': [Lock], '🛵': [Bike], '🛡': [ShieldCheck], '✅': [CheckCircle2, 'text-emerald-600'], '📈': [TrendingUp], '📊': [BarChart3], '🔔': [Bell], '🎛': [SlidersHorizontal], '🖥': [Server], '💳': [CreditCard],
  '🚀': [Rocket], '📄': [FileText], '📜': [FileText], '📎': [Paperclip], '📋': [ClipboardList], '📝': [PenLine], '✏': [PenLine], '🎬': [Clapperboard], '▶': [Play, '', true], '🖼': [ImageIcon], '🔗': [Link2], '🌐': [Globe],
  '🛒': [ShoppingCart], '🖨': [Printer], '⬇': [Download], '⬆': [Upload], '🔳': [QrCode], '🚩': [Flag, 'text-red-500'], '🏁': [Flag], '🏆': [Trophy, 'text-amber-500'], '💎': [Gem], '🍽': [UtensilsCrossed], '👁': [Eye],
  '💾': [Save], '🎨': [Palette], '🎯': [Target], '⚠': [AlertTriangle, 'text-amber-500'], '🧭': [Compass], '🛟': [LifeBuoy], '🧩': [LayoutGrid], '🎉': [Sparkles], '👋': [Sparkles], '📱': [Smartphone], '💼': [Briefcase],
  '🔧': [Wrench], '🆕': [ListPlus], '➕': [Plus], '🛠': [Wrench], '🤖': [Bot], 'ℹ': [Info], '🧑‍💼': [UserCog],
  '✔': [Check], '✓': [Check], '✕': [X], '➔': [ArrowRight],
  // category icons (stored as emoji in the DB)
  '🛏': [BedDouble], '🏥': [Hospital], '🎓': [GraduationCap], '🚗': [Car], '🌿': [Flower2],
};
// category name keywords -> icon (used when the stored emoji is unmapped or changed)
const CAT: [RegExp, LucideIcon][] = [
  [/restaurant|food|cafe|dhaba|biryani/i, Utensils], [/hotel|stay|resort|hostel|pg\b/i, BedDouble], [/health|hospital|clinic|doctor|pharm/i, Stethoscope], [/educat|school|college|coaching|tutor/i, GraduationCap],
  [/home|construct|repair|plumb|electric/i, Hammer], [/auto|transport|car|taxi|garage|bike/i, Car], [/shop|retail|store|mall/i, ShoppingBag], [/beauty|wellness|salon|spa|gym|yoga/i, Flower2],
  [/profession|service|lawyer|account|consult/i, Briefcase], [/event|entertain|wedding|photograph/i, PartyPopper], [/real estate|property|rent|flat/i, Landmark],
];
const BASE = 'inline-block shrink-0 w-[1.15em] h-[1.15em] align-[-0.2em]';
export function E({ c, className = '' }: { c: string; className?: string }) {
  const k = String(c).replace(/️/g, ''); const m = M[k];
  if (!m) return <>{c}</>;
  const I = m[0];
  return <I aria-hidden="true" strokeWidth={2} fill={m[2] ? 'currentColor' : 'none'} className={`${BASE} ${m[1] || ''} ${className}`} />;
}
export const hasIcon = (c: string) => !!M[String(c).replace(/️/g, '')];
// Category icon: matches by category name first, then by stored emoji; falls back to the emoji itself.
export function CatIcon({ icon, name, className = '' }: { icon?: string; name?: string; className?: string }) {
  const k = String(icon || '').replace(/️/g, ''); let I: LucideIcon | undefined = name ? CAT.find(([r]) => r.test(name))?.[1] : undefined;
  if (!I) I = M[k]?.[0];
  if (!I) return <>{icon || <Folder className={`${BASE} ${className}`} />}</>;
  return <I aria-hidden="true" strokeWidth={2} className={`${BASE} ${className}`} />;
}
const RX = new RegExp('(' + Object.keys(M).sort((a, b) => b.length - a.length).map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')\\uFE0F?', 'g');
// Renders a string, swapping any known pictograph in it for its icon.
export function T({ children }: { children?: React.ReactNode }) {
  if (typeof children !== 'string') return <>{children}</>;
  const out: React.ReactNode[] = []; let last = 0; let m: RegExpExecArray | null; RX.lastIndex = 0;
  while ((m = RX.exec(children))) { if (m.index > last) out.push(children.slice(last, m.index)); out.push(<E key={m.index} c={m[1]} />); last = m.index + m[0].length; }
  if (!out.length) return <>{children}</>;
  if (last < children.length) out.push(children.slice(last));
  return <>{out}</>;
}
