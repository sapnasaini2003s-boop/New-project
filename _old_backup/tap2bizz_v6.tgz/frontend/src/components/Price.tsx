export const pct = (price: number, mrp: number) => (mrp > price && price > 0 ? Math.round((1 - price / mrp) * 100) : 0);
// Slanted corner ribbon (top-right). Parent must be `relative`.
export function Ribbon({ off, label }: { off: number; label?: string }) {
  if (!(off > 0) && !label) return null;
  return (<div className="absolute top-0 right-0 w-[92px] h-[92px] overflow-hidden pointer-events-none rounded-tr-[inherit] z-[1]">
    <div className="absolute top-[18px] -right-[30px] w-[130px] rotate-45 bg-gradient-to-r from-green-600 to-emerald-500 text-white text-center text-[10px] font-black tracking-wide py-1 shadow-md">{label || `${off}% OFF`}</div>
  </div>);
}
export function Price({ price, mrp, unit, big = 'text-3xl', badge = true }: { price: number | string; mrp?: number; unit?: string; big?: string; badge?: boolean }) {
  const p = Number(price) || 0; const off = pct(p, mrp || 0);
  return (<div>
    {off > 0 && <div className="flex items-center gap-2 text-xs"><s className="text-gray-500">₹{Number(mrp).toLocaleString('en-IN')}{unit}</s>{badge && <span className="bg-green-600 text-white font-bold px-1.5 rounded">{off}% off</span>}</div>}
    <p className={`${big} font-black leading-tight`}>₹{p.toLocaleString('en-IN')}<span className="text-sm font-semibold text-gray-600">{unit}</span></p>
  </div>);
}
