'use client';
import { Logo } from '@/components/Logo';
import { E } from '@/components/Icon';
// Site-wide chrome: footer, mobile bottom app bar, right-edge sticky tabs
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState } from 'react';

import { useConfig } from '@/lib/api';

// Announcement / maintenance strip (Admin + Feature Controls)
export function TopBar() {
  const p = usePathname(); const { cfg, f } = useConfig();
  if (p.startsWith('/admin')) return null;
  if (f.maintenance) return <div className="bg-red-600 text-white text-center text-xs md:text-sm py-2 px-3 font-medium"><E c="⚠"/> We're doing scheduled maintenance - browsing works, new submissions are paused for a while.</div>;
  if (cfg?.announcement) return <div className="bg-accent text-white text-center text-xs md:text-sm py-2 px-3 font-medium">{cfg.announcement}</div>;
  return null;
}

export function StickyTabs() {
  const p = usePathname(); if (p.startsWith('/admin')) return null;
  return (
    <div className="hidden md:flex fixed right-0 top-1/3 z-30 flex-col gap-1">
      <Link href="/advertise" className="bg-accent text-white text-xs font-bold px-2 py-4 rounded-l-lg shadow-lg [writing-mode:vertical-rl] rotate-180 hover:pr-3 transition-all">Advertise</Link>
      <Link href="/register-business" className="bg-brand text-white text-xs font-bold px-2 py-4 rounded-l-lg shadow-lg [writing-mode:vertical-rl] rotate-180 hover:pr-3 transition-all">Free Listing</Link>
    </div>
  );
}

export function BottomBar() {
  const p = usePathname(); const [more, setMore] = useState(false);
  if (p.startsWith('/admin') || p.startsWith('/business/')) return null; // business pages have their own sticky Call / Order / WhatsApp bar
  const items = [['🏠', 'Home', '/'], ['🔍', 'Search/B2B', '/search'], ['📰', 'News/Feed', '/blogs']];
  return (
    <>
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t grid grid-cols-4 text-[11px] font-medium shadow-[0_-2px_8px_rgba(0,0,0,.06)]">
        {items.map(([i, n, h]) => (
          <Link key={n} href={h} className={`flex flex-col items-center py-2 ${p === h ? 'text-brand' : 'text-gray-600'}`}><span className="text-xl leading-none mb-1"><E c={i as string} /></span>{n}</Link>
        ))}
        <button onClick={() => setMore(true)} className="flex flex-col items-center py-2 text-gray-600"><span className="text-lg"><E c="☰"/></span>More</button>
      </nav>
      {more && (
        <div className="md:hidden fixed inset-0 z-50 bg-black/40" onClick={() => setMore(false)}>
          <div className="absolute bottom-0 inset-x-0 bg-white rounded-t-2xl p-4 slideup grid grid-cols-3 gap-3 text-sm" onClick={(e) => e.stopPropagation()}>
            {[['📂', 'Categories', '/categories'], ['🏷️', 'Offers', '/offers'], ['🔥', 'Trending', '/trending'], ['▶️', 'Videos', '/videos'], ['🏢', 'Free Listing', '/register-business'], ['📢', 'Advertise', '/advertise'], ['👤', 'My Account', '/vendor/dashboard'], ['❤️', 'Saved', '/favorites'], ['⚖️', 'Legal', '/legal/disclaimer']].map(([i, n, h]) => (
              <Link key={n} href={h} onClick={() => setMore(false)} className="flex flex-col items-center gap-1 p-3 rounded-xl border hover:border-brand"><span className="text-2xl"><E c={i} /></span>{n}</Link>
            ))}
          </div>
        </div>
      )}
    </>
  );
}

export function Footer() {
  const { cfg } = useConfig();
  const p = usePathname(); if (p.startsWith('/admin')) return null;
  return (
    <footer className="bg-[#0b1b3f] text-gray-300 mt-10 pb-20 md:pb-0">
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-2 md:grid-cols-5 gap-8 text-sm">
        <div className="col-span-2 md:col-span-2">
          <div className="inline-block bg-white rounded-2xl px-4 py-2.5 mb-3 shadow-lg"><Logo className="h-10 md:h-12" /></div>
          <p className="text-sm text-gray-300 font-medium">Tap <span className="text-accent">•</span> Find <span className="text-accent">•</span> Connect <span className="text-accent">•</span> Grow</p>
          <p className="text-xs text-gray-400 mt-1">Udupi | Manipal | Malpe | Mangaluru — Our Local. Your Global.</p>
          <div className="flex gap-3 mt-6">
            {/* Facebook */}
            <a href={cfg?.social?.facebook || "#"} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-brand hover:text-white transition-colors" aria-label="Facebook">
              <svg fill="currentColor" viewBox="0 0 24 24" className="w-5 h-5"><path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z" /></svg>
            </a>
            {/* Instagram */}
            <a href={cfg?.social?.instagram || "#"} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-pink-600 hover:text-white transition-colors" aria-label="Instagram">
              <svg fill="currentColor" viewBox="0 0 24 24" className="w-5 h-5"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" /></svg>
            </a>
            {/* LinkedIn */}
            <a href={cfg?.social?.linkedin || "#"} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-colors" aria-label="LinkedIn">
               <svg fill="currentColor" viewBox="0 0 24 24" className="w-5 h-5"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
            </a>
            {/* YouTube */}
            <a href={cfg?.social?.youtube || "#"} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-red-600 hover:text-white transition-colors" aria-label="YouTube">
              <svg fill="currentColor" viewBox="0 0 24 24" className="w-5 h-5"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.5 12 3.5 12 3.5s-7.505 0-9.377.55a3.016 3.016 0 0 0-2.122 2.136C0 8.07 0 12 0 12s0 3.93.498 5.814a3.016 3.016 0 0 0 2.122 2.136C3.995 20.5 11.5 20.5 11.5 20.5s7.505 0 9.377-.55a3.016 3.016 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.498-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
            </a>
          </div>
        </div>
        <div className="col-span-1">
          <h4 className="text-white font-semibold mb-4 text-lg">Company</h4>
          <ul className="space-y-2.5">
            <li><Link href="/legal/about" className="hover:text-white transition-colors">About Us</Link></li>
            <li><Link href="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
            <li><Link href="/advertise" className="hover:text-white transition-colors">Advertise With Us</Link></li>
            <li><Link href="/blogs" className="hover:text-white transition-colors">Blogs</Link></li>
          </ul>
        </div>
        <div className="col-span-1">
          <h4 className="text-white font-semibold mb-4 text-lg">Legal</h4>
          <ul className="space-y-2.5">
            <li><Link href="/legal/terms" className="hover:text-white transition-colors">Terms & Conditions</Link></li>
            <li><Link href="/legal/privacy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
            <li><Link href="/legal/refund" className="hover:text-white transition-colors">Refund & Cancellation</Link></li>
            <li><Link href="/legal/grievance" className="hover:text-white transition-colors">Grievance Redressal</Link></li>
            <li><Link href="/legal/disclaimer" className="hover:text-white transition-colors">Website Disclaimer</Link></li>
          </ul>
        </div>
        <div className="col-span-2 md:col-span-1">
          <h4 className="text-white font-semibold mb-4 text-lg">Download Our App</h4>
          <div className="flex flex-col gap-3 w-44">
            <a href={cfg?.apps?.android || "#"} target="_blank" rel="noopener noreferrer" className="border border-white/20 rounded-xl px-4 py-3 hover:bg-white/10 transition-colors flex items-center gap-2">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6"><path d="M3 20.5v-17c0-.83.67-1.5 1.5-1.5.38 0 .74.15 1.01.41l9.98 9.98-9.98 9.98A1.447 1.447 0 014.5 22 1.5 1.5 0 013 20.5z" opacity="0.8"/><path d="M15.49 12.39L20.46 7.4c.59-.59.59-1.54 0-2.12-.59-.59-1.54-.59-2.12 0l-4.97 4.97c-.39.39-1.02.39-1.41 0L6.99 5.28c-.59-.59-1.54-.59-2.12 0-.59.59-.59 1.54 0 2.12l4.97 4.97c.39.39.39 1.02 0 1.41l-4.97 4.97c-.59.59-.59 1.54 0 2.12.59.59 1.54.59 2.12 0l4.97-4.97c.39-.39 1.02-.39 1.41 0l4.97 4.97c.59.59 1.54.59 2.12 0 .59-.59.59-1.54 0-2.12l-4.97-4.97c-.39-.39-.39-1.02 0-1.41z"/></svg>
              <div>
                <div className="text-[10px] leading-none text-gray-400">GET IT ON</div>
                <div className="text-sm font-semibold text-white">Google Play</div>
              </div>
            </a>
            <a href={cfg?.apps?.ios || "#"} target="_blank" rel="noopener noreferrer" className="border border-white/20 rounded-xl px-4 py-3 hover:bg-white/10 transition-colors flex items-center gap-2">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-6 h-6"><path d="M12 2C6.477 2 2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12c0-5.523-4.477-10-10-10z"/></svg>
              <div>
                <div className="text-[10px] leading-none text-gray-400">Download on the</div>
                <div className="text-sm font-semibold text-white">App Store</div>
              </div>
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 text-center text-xs py-5 text-gray-400 bg-black/20">
        © {new Date().getFullYear()} Tap2Bizz. All Rights Reserved. | Made for Our Local Community <E c="❤"/>
      </div>
    </footer>
  );
}
