// Tap2Bizz brand: full lockup (pin + store + tap hand + wordmark) as image; compact mark for dark backgrounds.
export function Logo({ className = 'h-9 md:h-11' }: { className?: string }) {
  // eslint-disable-next-line @next/next/no-img-element
  return <img src="/logo.png" alt="Tap2Bizz" className={`${className} w-auto select-none`} draggable={false} />;
}
export function LogoMark({ className = 'w-9 h-9' }: { className?: string }) {
  // eslint-disable-next-line @next/next/no-img-element
  return <img src="/icon-192.png" alt="Tap2Bizz" className={`${className} rounded-xl select-none`} draggable={false} />;
}
export const Word = ({ className = '' }: { className?: string }) => <span className={`font-display font-black tracking-tight ${className}`}>Tap<span className="text-accent">2</span>Bizz</span>;
