'use client';
import { E } from '@/components/Icon';
import { Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import Listing from '@/components/Listing';
import { useFetch } from '@/lib/api';
import BizCard from '@/components/BizCard';

function Featured() {
  const { data } = useFetch<any[]>('/featured');
  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4 py-5">
      <h1 className="text-2xl font-black mb-4"><E c="⭐"/> Featured Premium Businesses</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">{(data || []).map((b) => <BizCard key={b._id} b={b} />)}</div>
    </div>
  );
}
function Inner() {
  const sp = useSearchParams();
  if (sp.get('featured')) return <Featured />;
  const q = sp.get('q') || '';
  return <Listing key={q} query={`q=${encodeURIComponent(q)}`} title={q ? `Results for “${q}”` : 'All Businesses'} />;
}
export default function Page() { return <Suspense><Inner /></Suspense>; }
