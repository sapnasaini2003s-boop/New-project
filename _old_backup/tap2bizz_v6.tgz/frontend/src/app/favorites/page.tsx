'use client';
import { E } from '@/components/Icon';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { api, localFavs, useUser } from '@/lib/api';
import BizCard from '@/components/BizCard';

// Logged-in users: saved on server. Guests: saved in this browser.
export default function Favorites() {
  const { user, ready } = useUser();
  const [data, setData] = useState<any[] | null>(null);
  useEffect(() => {
    if (!ready) return;
    if (user) { api<any[]>('/favorites').then(setData).catch(() => setData([])); return; }
    const ids = localFavs();
    if (!ids.length) { setData([]); return; }
    api<any[]>(`/businesses?ids=${ids.join(',')}`).then(setData).catch(() => setData([]));
  }, [ready, user]);
  return (<div className="max-w-7xl mx-auto px-3 md:px-4 py-6">
    <h1 className="text-2xl font-black"><E c="❤"/> Saved Businesses</h1>
    {!user && <p className="text-xs text-gray-500 mb-4">Saved on this device.</p>}
    {data && !data.length && <div className="card p-10 text-center text-gray-500 mt-4"><div className="text-5xl mb-2"><E c="🤍"/></div>Nothing saved yet. Tap “Save” on any business. <Link href="/" className="text-brand font-semibold block mt-2">Explore businesses →</Link></div>}
    {!data && <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mt-4">{[0, 1, 2, 3].map((i) => <div key={i} className="card h-72 animate-pulse bg-gray-100" />)}</div>}
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mt-4">{data?.map((b) => <BizCard key={b._id} b={b} />)}</div></div>);
}
