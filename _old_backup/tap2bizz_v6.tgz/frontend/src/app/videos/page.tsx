'use client';
import { E } from '@/components/Icon';
import { useState } from 'react';
import { useFetch, ytThumb } from '@/lib/api';
import VideoModal from '@/components/VideoModal';
import PageHero from '@/components/PageHero';
export default function Videos() {
  const { data } = useFetch<any[]>('/videos'); const [v, setV] = useState<string | null>(null);
  const [first, ...rest] = data || [];
  return (<div>
    <PageHero title="Videos" icon="🎬" tone="dark" subtitle="Explore Udupi, Manipal & Mangaluru — local guides, businesses and events." />
    <div className="max-w-7xl mx-auto px-4 py-8">
      {first && <button onClick={() => setV(first.url)} className="relative w-full aspect-[21/9] rounded-3xl overflow-hidden bg-slate-900 mb-6 group text-left">
        {ytThumb(first.url) && <img src={ytThumb(first.url)} alt="" className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:scale-105 transition duration-700" />}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20" />
        <span className="absolute inset-0 flex items-center justify-center"><span className="w-20 h-20 rounded-full bg-white/90 text-brand text-3xl flex items-center justify-center pl-1 shadow-2xl group-hover:scale-110 transition"><E c="▶"/></span></span>
        <div className="absolute bottom-0 p-6 md:p-10 text-white"><span className="text-xs font-bold bg-accent px-2 py-1 rounded">FEATURED</span><h2 className="text-2xl md:text-4xl font-black mt-2">{first.title}</h2></div>
      </button>}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{rest.map((x) => (
        <button key={x._id} onClick={() => setV(x.url)} className="text-left group">
          <div className="relative aspect-video rounded-2xl overflow-hidden bg-slate-200">{ytThumb(x.url) && <img src={ytThumb(x.url)} alt="" className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />}
            <span className="absolute inset-0 flex items-center justify-center bg-black/10 group-hover:bg-black/30 transition"><span className="w-12 h-12 rounded-full bg-white/90 text-brand flex items-center justify-center pl-0.5"><E c="▶"/></span></span></div>
          <p className="mt-2 text-sm font-bold text-gray-800 group-hover:text-brand line-clamp-2">{x.title}</p>{x.category && <p className="text-xs text-gray-400">{x.category}</p>}
        </button>))}</div>
    </div><VideoModal url={v} onClose={() => setV(null)} />
  </div>);
}
