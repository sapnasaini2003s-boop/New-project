import type { Metadata, Viewport } from 'next';
import '@fontsource-variable/inter';
import '@fontsource/poppins/500.css';
import '@fontsource/poppins/600.css';
import '@fontsource/poppins/700.css';
import '@fontsource/poppins/800.css';
import './globals.css';
import Header from '@/components/Header';
import Consent from '@/components/Consent';
import { Footer, BottomBar, StickyTabs, TopBar } from '@/components/Chrome';

export const metadata: Metadata = {
  title: 'Tap2Bizz – Tap. Find. Connect. Grow. | Udupi & Mangaluru Local Business Directory',
  applicationName: 'Tap2Bizz',
  description: 'Find verified restaurants, PGs, doctors, rentals and services in Udupi, Manipal, Malpe and Mangaluru.',
};
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#0055FF' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="antialiased">
      <body className="min-h-screen flex flex-col font-sans">
        <TopBar />
        <Header />
        <main className="flex-1 pb-16 md:pb-0">{children}</main>
        <StickyTabs />
        <Footer />
        <BottomBar />
        <Consent />
      </body>
    </html>
  );
}
