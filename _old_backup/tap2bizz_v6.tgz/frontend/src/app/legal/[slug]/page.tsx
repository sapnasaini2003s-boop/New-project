'use client';
import { E } from '@/components/Icon';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useState } from 'react';
import { api, useConfig, useFetch, useUser } from '@/lib/api';
import PageHero from '@/components/PageHero';
const PAGES = [['about', 'About us', 'ℹ️'], ['disclaimer', 'Disclaimer', '⚠️'], ['privacy', 'Privacy Policy', '🔒'], ['terms', 'Business Terms', '📜'], ['grievance', 'Grievance Officer', '⚖️']];
function GrievanceForm() {
  const { user } = useUser(); const [f, setF] = useState({ subject: '', details: '' }); const [msg, setMsg] = useState('');
  const send = async (e: React.FormEvent) => { e.preventDefault(); try { setMsg((await api('/grievances', { body: { kind: 'grievance', details: f.subject + ' — ' + f.details } })).message); setF({ subject: '', details: '' }); } catch (er: any) { setMsg(er.message); } };
  if (!user) return <div className="card p-6 mt-6 text-center"><h3 className="font-bold mb-1">Submit a grievance</h3><p className="text-sm text-gray-500 mb-3">Please log in to submit a grievance.</p><Link href="/login?intent=user&next=/legal/grievance" className="btn btn-primary">Login</Link></div>;
  return (
    <form onSubmit={send} className="card p-6 md:p-8 mt-6 max-w-2xl shadow-sm border border-gray-200">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-900">Submit a Grievance</h3>
        <p className="text-sm text-gray-500 mt-1">Please provide the details of your issue. As per IT Rules 2021, we will acknowledge this within 24 hours.</p>
      </div>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">Subject</label>
          <input required minLength={5} maxLength={100} className="input w-full bg-gray-50 focus:bg-white" placeholder="e.g., Fake listing, Harassment, Refund issue" value={f.subject} onChange={(e) => setF({ ...f, subject: e.target.value })} />
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1">Description</label>
          <textarea required minLength={15} maxLength={1000} rows={5} className="input w-full bg-gray-50 focus:bg-white resize-none" placeholder="Please describe your issue in detail. If it is about a specific business, include their name or link here." value={f.details} onChange={(e) => setF({ ...f, details: e.target.value })} />
          <p className="text-xs text-gray-400 mt-1 flex justify-end">{f.details.length}/1000</p>
        </div>
        {msg && (
          <div className={`p-3 rounded-lg text-sm font-medium ${msg.includes('Submitted') ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-600 border border-red-200'}`}>
            <E c={msg.includes('Submitted') ? '✅' : '⚠'} /> {msg}
          </div>
        )}
        <button type="submit" disabled={!f.subject || f.details.length < 15} className="btn btn-brand w-full md:w-auto px-8 py-3 text-base font-bold shadow-md disabled:opacity-50">Submit Grievance</button>
      </div>
    </form>
  );
}
export default function LegalPage() {
  const { slug } = useParams<{ slug: string }>(); const { f } = useConfig(); const { data, error } = useFetch<any>(`/pages/${slug}`);
  const cur = PAGES.find((p) => p[0] === slug);
  return (<div>
    <PageHero title={data?.title || cur?.[1] || 'Legal'} icon={cur?.[2]} tone="dark" crumb="Legal" subtitle={data?.updatedAt ? `Last updated ${new Date(data.updatedAt).toLocaleDateString('en-IN')}` : undefined} />
    <div className="max-w-6xl mx-auto px-4 py-8 grid md:grid-cols-[240px_1fr] gap-6 items-start">
      <nav className="card p-2 md:sticky md:top-32 flex md:flex-col gap-1 overflow-x-auto no-scrollbar">{PAGES.map(([k, l, i]) => (
        <Link key={k} href={`/legal/${k}`} className={`shrink-0 flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm font-medium ${k === slug ? 'bg-brand text-white' : 'text-gray-600 hover:bg-gray-50'}`}><span><E c={i} /></span>{l}</Link>))}</nav>
      {error ? <div className="card p-10 text-center text-gray-500">Page not found</div> : !data ? <div className="card p-8 animate-pulse h-64" /> :
        <article className="card p-6 md:p-10"><div className="whitespace-pre-line text-[15px] leading-8 text-gray-800">{data.body}</div>
          <div className="mt-8 pt-6 border-t text-sm text-gray-500">Questions? Write to <a className="text-brand font-semibold" href="mailto:suhantudupi@gmail.com">suhantudupi@gmail.com</a></div></article>}
      {slug === 'grievance' && (f.grievanceForm !== false ? <div className="md:col-start-2"><GrievanceForm /></div> : <div className="md:col-start-2 card p-5 mt-6 text-sm text-gray-600">Online grievance submission is currently unavailable. Please write to the Grievance Officer by email using the address given above.</div>)}
    </div>
  </div>);
}
