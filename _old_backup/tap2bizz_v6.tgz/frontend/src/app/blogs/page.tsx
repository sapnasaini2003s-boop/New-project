'use client';
import { E } from '@/components/Icon';
import Link from 'next/link';
import { useState } from 'react';
import { img, useFetch } from '@/lib/api';
import PageHero from '@/components/PageHero';
const date = (d: string) => new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
export default function Blogs() {
  const all = useFetch<any[]>('/blogs').data; const cats = useFetch<string[]>('/blog-categories').data || []; const [cat, setCat] = useState('All');
  const used = cats.filter((c) => (all || []).some((b) => b.category === c));
  const data = all && (cat === 'All' ? all : all.filter((b) => b.category === cat)); const [first, ...rest] = data || [];
  const Tag = ({ c }: any) => <span className="inline-block text-[10px] font-bold uppercase tracking-wider bg-blue-50 text-brand px-2 py-0.5 rounded-full">{c || 'General'}</span>;
  const Cover = ({ b, h }: any) => b.image ? <img src={img(b.image)} alt="" className={`w-full ${h} object-cover`} /> : <div className={`w-full ${h} bg-gradient-to-br from-blue-100 via-indigo-50 to-orange-100 flex items-center justify-center text-5xl`}><E c="📰"/></div>;
  return (<div>
    <PageHero title="News & Local Guides" icon="📰" subtitle="Tips, guides and stories from coastal Karnataka." />
    <div className="max-w-6xl mx-auto px-4 py-8">
      {used.length > 0 && <div className="flex gap-2 overflow-x-auto pb-3 mb-5 -mx-4 px-4">{['All', ...used].map((c) => <button key={c} onClick={() => setCat(c)} className={`shrink-0 px-4 py-2 rounded-full text-xs font-bold border transition ${cat === c ? 'bg-brand text-white border-brand' : 'bg-white text-gray-600 border-gray-200 hover:border-brand'}`}>{c}</button>)}</div>}
      {first && <Link href={first.externalLink || `/blogs/${first._id}`} target={first.externalLink ? '_blank' : undefined} className="card overflow-hidden grid md:grid-cols-2 hover:shadow-xl transition mb-8 group">
        <Cover b={first} h="h-56 md:h-full" />
        <div className="p-6 md:p-10 flex flex-col justify-center"><div className="flex gap-2 items-center"><span className="text-xs font-bold text-accent uppercase tracking-wider">Latest</span><Tag c={first.category} /></div>
          <h2 className="text-2xl md:text-3xl font-black mt-2 group-hover:text-brand">{first.title}</h2><p className="text-gray-600 mt-3">{first.excerpt}</p>
          <p className="text-xs text-gray-400 mt-4">{date(first.createdAt)} · Read more →</p></div>
      </Link>}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">{rest.map((b) => (
        <Link key={b._id} href={b.externalLink || `/blogs/${b._id}`} target={b.externalLink ? '_blank' : undefined} className="card overflow-hidden hover:shadow-lg transition group"><Cover b={b} h="h-44" />
          <div className="p-5"><Tag c={b.category} /><h3 className="font-bold text-lg mt-2 group-hover:text-brand line-clamp-2">{b.title}</h3><p className="text-sm text-gray-600 mt-1 line-clamp-2">{b.excerpt}</p><p className="text-xs text-gray-400 mt-3">{date(b.createdAt)}</p></div></Link>))}</div>
      {data && !data.length && <div className="card p-12 text-center text-gray-500">No articles yet.</div>}
    </div>
  </div>);
}
