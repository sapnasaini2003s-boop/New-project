'use client';
import { E, CatIcon } from '@/components/Icon';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useFetch, img, ytThumb, getCity } from '@/lib/api';
import BizCard from '@/components/BizCard';
import VideoModal from '@/components/VideoModal';

function Banner({ ads, h = 'min-h-24 md:min-h-28' }: { ads: any[]; h?: string }) {
  const [i, setI] = useState(0);
  useEffect(() => { if (ads.length < 2) return; const t = setInterval(() => setI((x) => (x + 1) % ads.length), 4000); return () => clearInterval(t); }, [ads.length]);
  if (!ads.length) return (
    <Link href="/advertise" className={`${h} rounded-xl border-2 border-dashed border-accent/50 bg-orange-50 flex items-center justify-center text-accent font-bold`}>Ad Space 970×90 — Book this slot</Link>
  );
  const a = ads[i % ads.length];
  return (
    <div className="relative">
      <Link href={a.link || '#'} className={`${h} rounded-xl overflow-hidden flex items-center justify-between px-4 md:px-10 py-3 pb-5 gap-3 text-white shadow`}
        style={{ background: a.image ? `url(${img(a.image)}) center/cover` : a.bg || 'linear-gradient(90deg,#0033aa,#0055FF)' }}>
        <div className={`min-w-0 ${a.image ? 'bg-black/40 p-2 rounded' : ''}`}>
          <h3 className="font-black text-base md:text-2xl tracking-wide line-clamp-2" style={{ color: a.bg?.includes('#eff6ff') ? '#0b1b3f' : undefined }}>{a.title}</h3>
          <p className="text-xs md:text-sm opacity-90 line-clamp-2" style={{ color: a.bg?.includes('#eff6ff') ? '#0055FF' : undefined }}>{a.subtitle}</p>
        </div>
        {!a.image && a.thumb && <img src={img(a.thumb)} alt="" loading="lazy" className="ml-auto w-20 h-14 md:w-44 md:h-20 rounded-lg object-cover shadow-md border border-white/40 shrink-0" onError={(e) => { e.currentTarget.style.display = 'none'; }} />}
        {a.cta && <span className="btn btn-accent !text-xs md:!text-sm shrink-0">{a.cta}</span>}
      </Link>
      {ads.length > 1 && <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 flex gap-1">{ads.map((_, k) => <span key={k} className={`w-1.5 h-1.5 rounded-full ${k === i % ads.length ? 'bg-white' : 'bg-white/50'}`} />)}</div>}
    </div>
  );
}


function PromoCarousel({ ads }: { ads: any[] }) {
  const [i, setI] = useState(0);
  useEffect(() => { if (ads.length < 2) return; const t = setInterval(() => setI((x) => (x + 1) % ads.length), 4000); return () => clearInterval(t); }, [ads.length]);
  if (!ads.length) return <Link href="/advertise" className="rounded-2xl min-h-[200px] p-6 flex flex-col justify-end bg-gradient-to-br from-[#0b3bd1] to-[#3b82f6] text-white"><b className="text-xl">Promote your business here</b><span className="text-sm text-blue-100">Promo widget · book from dashboard</span><span className="btn bg-white text-brand w-fit mt-3 !text-xs">Advertise</span></Link>;
  const a = ads[i % ads.length];
  return (
    <div className="relative h-full min-h-[200px]">
      <Link href={a.link || '#'} className="absolute inset-0 rounded-2xl overflow-hidden bg-gradient-to-br from-[#0b3bd1] to-[#2f6bff] text-white p-6 flex flex-col justify-center">
        {a.image && <img src={img(a.image)} alt="" className="absolute right-0 top-0 h-full w-3/5 object-cover [mask-image:linear-gradient(to_right,transparent,black_45%)]" />}
        <div className="relative z-10 max-w-[62%]">
          <h3 className="text-xl md:text-2xl font-black leading-tight line-clamp-2">{a.title}</h3>
          <p className="text-xs md:text-sm text-blue-100 line-clamp-2 mt-1.5">{a.subtitle}</p>
          <span className="btn btn-accent w-fit mt-4 !text-xs">{a.cta || 'EXPLORE NOW'}</span>
        </div>
      </Link>
      {ads.length > 1 && <div className="absolute bottom-3 left-6 flex gap-1 z-20">{ads.map((_, k) => <span key={k} className={`w-1.5 h-1.5 rounded-full ${k === i % ads.length ? 'bg-white' : 'bg-white/40'}`} />)}</div>}
    </div>
  );
}

export default function Home() {
  const router = useRouter();
  const [city, setCity] = useState('Udupi');
  useEffect(() => { setCity(getCity()); const f = () => setCity(getCity()); window.addEventListener('pvrs-city', f); return () => window.removeEventListener('pvrs-city', f); }, []);
  const { data: home } = useFetch<any>('/home');
  const { data: cats } = useFetch<any[]>('/categories');
  const { data: featured } = useFetch<any[]>('/featured');
  const [tab, setTab] = useState('Businesses');
  const [q, setQ] = useState('');
  const [video, setVideo] = useState<string | null>(null);
  const s = home?.settings || {}; const ads = home?.ads || {};
  const heroVid = ads.heroVideo?.[0];
  const cityList: string[] = (home?.settings?.cities as string[] | undefined)?.length ? home!.settings.cities : ['Udupi', 'Manipal', 'Malpe', 'Mangaluru', 'Kundapura', 'Karkala'];
  const setCityTo = (ct: string) => { try { localStorage.setItem('pvrs_city', ct); } catch { /* ignore */ } window.dispatchEvent(new Event('pvrs-city')); };
  const go = (e: React.FormEvent) => { e.preventDefault(); router.push(`/search?q=${encodeURIComponent(q)}&city=${city}&type=${tab}`); };
  const heroTitle: string = s.hero?.title || 'Find Local Businesses Near You'; const tm = heroTitle.match(/^(.*?)(\s*\S+\s+\S+)$/); const t1 = tm ? tm[1] : heroTitle; const t2 = tm ? tm[2].trim() : '';
  const pills = (cats || []).flatMap((c: any) => c.subs.slice(0, 2).map((sub: string) => ({ sub, c })));

  return (
    <div className="max-w-7xl mx-auto px-3 md:px-4">
      {/* Mobile sticky category ribbon */}
      <div className="md:hidden sticky top-[104px] z-30 bg-[#f5f7fb] -mx-3 px-3 py-2 flex gap-3 overflow-x-auto no-scrollbar">
        {(cats || []).map((c: any) => (
          <a key={c._id} href={`#cat-${c.slug}`} className="flex flex-col items-center min-w-[64px] text-[10px] font-medium text-gray-700">
            <span className="w-11 h-11 rounded-xl bg-white border flex items-center justify-center text-xl" style={{ color: c.color }}><CatIcon icon={c.icon} name={c.name} /></span>
            <span className="text-center leading-tight mt-1">{c.name.split(' ')[0]}</span>
          </a>
        ))}
      </div>

      {/* 2. Top banner carousel */}
      <section className="mt-3 md:hidden"><Banner ads={ads.top || []} /></section>

      {/* Hero — background image editable from Admin → Settings → Hero (separate desktop & mobile image) */}
      {(() => {
        const bgD = s.hero?.bgDesktop ? img(s.hero.bgDesktop) : ''; const bgM = s.hero?.bgMobile ? img(s.hero.bgMobile) : bgD;
        const kicker: string = s.hero?.kicker || `${cityList.slice(0, 3).join(' · ')} · Nearby`;
        const Title = <>{t1}{t2 && <><br /><span className="text-brand">{t2}</span></>}</>;
        const heroCats = (cats || []).slice(0, 4);
        return (<>
          {/* Mobile */}
          <section className="md:hidden mt-3 rounded-2xl overflow-hidden relative border border-blue-100 bg-gradient-to-br from-white via-[#eef4ff] to-[#d9e6ff]">
            {bgM && <img src={bgM} alt="" className="absolute inset-0 w-full h-full object-cover" />}
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/85 to-white/10" />
            <div className="relative p-4">
              <p className="text-[10px] font-semibold tracking-[.18em] uppercase text-brand flex items-center gap-1"><E c="📍" /> {kicker}</p>
              <h1 className="font-display text-[26px] !font-semibold leading-[1.12] tracking-tight text-[#0b1b3f] mt-2 max-w-[75%]">{Title}</h1>
              <p className="text-slate-600 mt-1.5 text-xs leading-snug max-w-[240px]">{s.hero?.subtitle || 'Discover local businesses. Compare options. Connect directly.'}</p>
              <form onSubmit={go} className="mt-3 bg-white rounded-xl p-1 flex items-center gap-1 shadow-lg shadow-blue-900/10 border border-blue-50"><span className="pl-2 text-slate-400"><E c="🔍" /></span><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="What are you looking for?" className="flex-1 min-w-0 text-sm text-slate-800 outline-none px-1 py-2" /><button className="bg-brand text-white px-3.5 py-2 rounded-lg text-sm font-bold">Explore →</button></form>
              {heroVid && <button onClick={() => setVideo(heroVid.youtubeUrl)} className="mt-2.5 text-[11px] font-bold text-brand inline-flex items-center gap-1.5 bg-white/80 rounded-full px-3 py-1"><E c="▶" /> Watch video</button>}
            </div>
          </section>
          {/* Desktop */}
          <section className="hidden md:block mt-5 rounded-3xl overflow-hidden relative bg-gradient-to-br from-white via-[#eef4ff] to-[#d9e6ff] border border-blue-100 shadow-sm">
            {bgD && <img src={bgD} alt="" className="absolute inset-0 w-full h-full object-cover object-right" />}
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/90 to-transparent" />
            <div className="relative px-8 py-9 lg:px-12 lg:py-11 max-w-[760px]">
              <p className="text-[11px] font-semibold tracking-[.22em] uppercase text-brand flex items-center gap-1.5"><E c="📍" /> {kicker}</p>
              <h1 className="font-display text-4xl lg:text-[52px] !font-bold leading-[1.08] tracking-tight text-[#0b1b3f] mt-3">{Title}</h1>
              <p className="text-slate-600 mt-3 text-base lg:text-lg">{s.hero?.subtitle || 'Discover local businesses. Compare options. Connect directly.'}</p>
              <form onSubmit={go} className="mt-6 bg-white rounded-2xl p-2 flex items-center gap-2 shadow-xl shadow-blue-900/10 border border-blue-50 max-w-[640px]">
                <span className="pl-3 text-slate-400"><E c="🔍" /></span>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="What are you looking for?" className="flex-1 min-w-0 px-2 py-2.5 outline-none text-slate-800 placeholder:text-slate-400" />
                <span className="w-px h-8 bg-slate-200" />
                <label className="flex items-center gap-1.5 px-3 text-slate-700 font-medium text-sm"><span className="text-brand"><E c="📍" /></span><select value={city} onChange={(e) => setCityTo(e.target.value)} className="bg-transparent outline-none cursor-pointer">{cityList.map((ct) => <option key={ct}>{ct}</option>)}</select></label>
                <button className="bg-brand hover:bg-brand-dark text-white px-6 py-3 rounded-xl font-bold transition shadow-lg shadow-blue-600/25">Explore Nearby →</button>
              </form>
              <div className="mt-5 flex gap-3">{heroCats.map((c: any) => (
                <Link key={c._id} href={`/category/${c.slug}`} className="w-[118px] bg-white/95 rounded-2xl border border-slate-100 shadow-sm py-3 flex flex-col items-center gap-2 hover:shadow-lg hover:-translate-y-0.5 transition">
                  <span className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ background: c.color + '18', color: c.color }}><CatIcon icon={c.icon} name={c.name} /></span>
                  <span className="text-[13px] font-semibold text-slate-700 text-center leading-tight px-1 line-clamp-1">{c.name.split(/[ &]/)[0]}</span></Link>))}</div>
            </div>
            {heroVid && <button onClick={() => setVideo(heroVid.youtubeUrl)} className="absolute right-6 bottom-6 text-xs font-bold text-white bg-black/55 backdrop-blur rounded-full px-4 py-2 flex items-center gap-2 hover:bg-brand transition"><E c="▶" /> {heroVid.title || 'Watch video'}</button>}
          </section>
        </>);
      })()}
      {!!(ads.top || []).length && <section className="hidden md:block mt-5"><Banner ads={ads.top} /></section>}

      {/* 5. Top categories — tile grid */}
      <section className="mt-6">
        <div className="flex justify-between items-end mb-3">
          <div><h2 className="font-black text-lg md:text-xl text-[#0b1b3f]">Browse Categories</h2><p className="text-xs text-gray-500">Trusted local services in {city}</p></div>
          <Link href="/categories" className="text-brand text-sm font-bold hover:underline">View all →</Link>
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-2 md:gap-3">
          {(cats || []).map((c: any) => (
            <Link key={c._id} href={`/category/${c.slug}`} className="group bg-white rounded-2xl border border-gray-100 shadow-sm p-2.5 md:p-3 flex flex-col items-center text-center hover:border-brand/40 hover:shadow-lg hover:-translate-y-0.5 transition">
              <span className="w-11 h-11 md:w-14 md:h-14 rounded-xl flex items-center justify-center text-2xl md:text-3xl" style={{ background: c.color + '14', color: c.color }}><CatIcon icon={c.icon} name={c.name} /></span>
              <span className="text-xs md:text-sm font-semibold mt-2 leading-tight text-gray-700 group-hover:text-brand line-clamp-2">{c.name}</span>
            </Link>
          ))}
          <Link href="/categories" className="group bg-white rounded-xl border border-dashed border-gray-300 p-2.5 md:p-3 flex flex-col items-center justify-center text-center hover:border-brand">
            <span className="w-11 h-11 md:w-14 md:h-14 rounded-xl flex items-center justify-center text-xl bg-gray-50 text-gray-500">•••</span>
            <span className="text-xs md:text-sm font-semibold mt-2 text-gray-600 group-hover:text-brand">More</span>
          </Link>
        </div>
        {/* Mobile: 2-column capsule pills (spec) */}
        <div className="md:hidden grid grid-cols-2 gap-2 mt-3">
          {pills.slice(0, 10).map(({ sub, c }: any) => (
            <Link key={c.slug + sub} href={`/category/${c.slug}?sub=${encodeURIComponent(sub)}`} className="flex items-center gap-2 rounded-full border border-gray-200 bg-white px-3 py-2 text-xs font-medium text-gray-700">
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: c.color }} /><span className="truncate">{sub}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* 6. Promo ad + 7. Featured videos */}
      <section className="grid md:grid-cols-3 gap-4 mt-5">
        <PromoCarousel ads={ads.promo || []} />
        <div className="card p-4 md:col-span-2 min-w-0">
          <div className="flex justify-between mb-3"><h2 className="font-bold">Featured Videos</h2><Link href="/videos" className="text-brand text-sm font-semibold">View All →</Link></div>
          <div className="flex md:grid md:grid-cols-4 gap-3 md:gap-4 overflow-x-auto no-scrollbar snap-x snap-mandatory items-start scroll-px-0">
            {(home?.videos || []).map((v: any) => (
              <button key={v._id} onClick={() => setVideo(v.url)} className="w-[170px] md:w-auto md:nth-[n+5]:hidden shrink-0 snap-start text-left group">
                <div className="relative aspect-video rounded-xl overflow-hidden bg-gray-200">
                  {ytThumb(v.url) && <img src={ytThumb(v.url)} alt="" className="w-full h-full object-cover" />}
                  <span className="absolute inset-0 bg-black/25 group-hover:bg-black/10 transition" /><span className="absolute inset-0 flex items-center justify-center"><span className="w-11 h-11 rounded-full bg-black/60 text-white flex items-center justify-center pl-0.5 text-lg ring-2 ring-white/60"><E c="▶"/></span></span>
                </div>
                <p className="text-xs md:text-[13px] font-semibold mt-1.5 line-clamp-2 text-gray-800">{v.title}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Stats + 9. location banner */}
      <section className="grid md:grid-cols-3 gap-4 mt-5">
        <div className="card p-4 md:col-span-2 flex md:grid md:grid-cols-4 gap-3 overflow-x-auto no-scrollbar snap-x text-center min-w-0 md:divide-x divide-gray-100">
          {[['🏪', home?.stats?.businesses, 'Local Businesses'], ['👥', home?.stats?.customers, 'Happy Customers'], ['✅', home?.stats?.verified, 'Businesses'], ['❤️', home?.stats?.support, 'Local']].map(([i, v, l]) => (
            <div key={l} className="min-w-[120px] md:min-w-0 flex-1 shrink-0 snap-start flex flex-col items-center justify-center"><div className="text-2xl"><E c={i} /></div><div className="font-black text-sm md:text-xl">{v}</div><div className="text-[10px] md:text-xs text-gray-500">{l}</div></div>
          ))}
        </div>
        <div className="rounded-xl p-5 text-white min-h-[110px] flex flex-col justify-center" style={{ background: `linear-gradient(90deg,#0033aacc,#0055ff55), url(${img(s.locationBanner?.image)}) center/cover` }}>
          <h3 className="font-black text-xl">{s.locationBanner?.title}</h3><p className="text-sm">{s.locationBanner?.subtitle}</p>
        </div>
      </section>

      {/* 10. Featured (premium only, behaviour-ranked) */}
      <section className="mt-6">
        <div className="flex justify-between items-end mb-3">
          <div><h2 className="font-bold text-lg">Featured Businesses</h2><p className="text-xs text-gray-500">Premium verified businesses trending right now</p></div>
          <Link href="/search?featured=1" className="text-brand text-sm font-semibold">View All →</Link>
        </div>
        <div className="flex md:grid md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 overflow-x-auto no-scrollbar snap-x snap-mandatory items-stretch pb-1">
          {(featured || []).map((b: any) => <div key={b._id} className="w-[250px] md:w-auto shrink-0 snap-start flex"><BizCard b={b} /></div>)}
          {featured && !featured.length && <p className="text-sm text-gray-500">No featured businesses yet.</p>}
        </div>
      </section>

      {/* 11. Middle banner + vendor CTA */}
      <section className="grid md:grid-cols-5 gap-4 mt-6 items-stretch">
        <div className="md:col-span-2 min-w-0"><Banner ads={ads.middle || []} h="h-full min-h-[120px] md:min-h-[150px]" /></div>
        <div className="md:col-span-3 rounded-2xl p-6 md:p-7 bg-gradient-to-r from-brand to-[#3b82f6] text-white flex flex-col justify-center relative overflow-hidden">
          <div className="absolute -right-10 -bottom-10 w-52 h-52 rounded-full bg-white/10" />
          <h3 className="text-xl md:text-2xl font-black relative">{s.cta?.vendorTitle}</h3>
          <p className="text-sm text-blue-100 mt-1 relative max-w-md">{s.cta?.vendorText}</p>
          <Link href="/login?intent=vendor&next=/register-business" className="btn bg-white text-brand mt-4 w-fit relative">List Your Business – It&apos;s Free!</Link>
        </div>
      </section>

      {/* Business directory — Yellow-Pages style text index */}
      <section className="card mt-8 p-5 md:p-7">
        <div className="flex flex-wrap items-end justify-between gap-2 mb-5 pb-4 border-b">
          <div><h2 className="font-black text-lg md:text-xl text-[#0b1b3f]">Business Directory — {city}</h2><p className="text-xs text-gray-500">Browse every service by category</p></div>
          <div className="flex flex-wrap gap-1.5 text-xs">{((home?.settings?.cities as string[] | undefined)?.length ? home!.settings.cities : ['Udupi', 'Manipal', 'Malpe', 'Mangaluru', 'Kundapura', 'Karkala']).map((ct: string) => (
            <button key={ct} onClick={() => { localStorage.setItem('pvrs_city', ct); window.dispatchEvent(new Event('pvrs-city')); }} className={`px-3 py-1 rounded-full border ${ct === city ? 'bg-brand text-white border-brand' : 'bg-white text-gray-600 hover:border-brand'}`}>{ct}</button>))}</div>
        </div>
        <div className="columns-1 sm:columns-2 lg:columns-4 xl:columns-5 gap-8">
          {(cats || []).map((c: any) => (
            <div key={c._id} id={`cat-${c.slug}`} className="break-inside-avoid mb-6 scroll-mt-40">
              <Link href={`/category/${c.slug}`} className="flex items-center gap-2 font-bold text-gray-900 hover:text-brand mb-2">
                <span className="w-7 h-7 rounded-lg flex items-center justify-center text-base" style={{ background: c.color + '18', color: c.color }}><CatIcon icon={c.icon} name={c.name} /></span>{c.name}
              </Link>
              <ul className="space-y-1 pl-9">
                {c.subs.slice(0, 7).map((sub: string) => (
                  <li key={sub}><Link href={`/category/${c.slug}?sub=${encodeURIComponent(sub)}`} className="text-[13px] text-gray-600 hover:text-brand hover:underline">{sub}</Link></li>
                ))}
                {c.subs.length > 7 && <li><Link href={`/category/${c.slug}`} className="text-[13px] font-semibold text-brand">View all {c.subs.length} →</Link></li>}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* Advertise strip */}
      <section className="mt-6 mb-8 rounded-2xl p-6 bg-orange-50 border border-orange-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div><h3 className="text-xl md:text-2xl font-black text-accent">{s.cta?.advertiseTitle}</h3><p className="text-sm text-gray-600 mt-1">{s.cta?.advertiseText}</p></div>
        <Link href="/advertise" className="btn btn-accent shrink-0">Explore Advertising Options</Link>
      </section>
      <VideoModal url={video} onClose={() => setVideo(null)} />
    </div>
  );
}
