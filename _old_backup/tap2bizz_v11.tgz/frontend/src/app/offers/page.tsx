'use client';
import { T } from '@/components/Icon';
import { E } from '@/components/Icon';
import { useState } from 'react';
import Link from 'next/link';
import { useFetch } from '@/lib/api';
import PageHero from '@/components/PageHero';
const TONES = [['#FF6600', '#ff8a3d'], ['#0055FF', '#3b82f6'], ['#059669', '#34d399'], ['#7c3aed', '#a78bfa']];
export default function Offers() {
  const { data } = useFetch<any[]>('/offers'); const [copied, setCopied] = useState('');
  const copy = (c: string) => { navigator.clipboard?.writeText(c); setCopied(c); setTimeout(() => setCopied(''), 1500); };
  return (<div>
    <PageHero title="Local Offers & Deals" icon="🏷️" tone="accent" subtitle="Exclusive discounts from verified businesses near you." />
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">{data?.map((o, i) => { const [a, b] = TONES[i % TONES.length]; return (
        <div key={o._id} className="rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition bg-white border">
          <div className="p-6 text-white relative" style={{ background: `linear-gradient(135deg, ${a}, ${b})` }}>
            <div className="absolute right-4 top-4 text-5xl opacity-20">%</div>
            <p className="text-xs uppercase tracking-wider opacity-90">{o.businessName}</p>
            <h3 className="text-3xl font-black mt-1">{o.title}</h3><p className="text-sm opacity-90">{o.subtitle}</p>
          </div>
          <div className="relative border-t-2 border-dashed border-gray-200 p-5 flex items-center justify-between">
            <span className="absolute -left-3 -top-3 w-6 h-6 rounded-full bg-[#f5f7fb]" /><span className="absolute -right-3 -top-3 w-6 h-6 rounded-full bg-[#f5f7fb]" />
            <div><p className="text-[11px] text-gray-400"><E c="📍"/> {o.city} · {o.expiry}</p>{o.code && <p className="font-mono font-black text-lg tracking-widest text-gray-900">{o.code}</p>}{o.discountType && <p className="text-[11px] font-bold text-emerald-600">{o.discountType === 'percent' ? `${o.discountValue}% OFF` : `₹${o.discountValue} OFF`}{o.minOrder > 0 ? ` · min ₹${o.minOrder}` : ''} · applies at checkout</p>}</div>
            {o.businessId && <Link href={`/business/${o.businessId}?tab=menu`} className="btn btn-accent !text-xs mr-2">Order now</Link>}{o.code && <button onClick={() => copy(o.code)} className="btn btn-ghost !text-xs">{copied === o.code ? <T>✓ Copied</T> : 'Copy code'}</button>}
          </div>
        </div>); })}</div>
      {data && !data.length && <div className="card p-12 text-center text-gray-500"><div className="text-5xl mb-2"><E c="🏷"/></div>No offers right now — check back soon.</div>}
    </div>
  </div>);
}
